package com.oddswatch.mobile;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
public final class GradientDrawableCompat {
    public static void bg(View v,int color,int radiusDp){GradientDrawable g=new GradientDrawable();g.setColor(color);float d=v.getResources().getDisplayMetrics().density;g.setCornerRadius(radiusDp*d);v.setBackground(g);}
    private GradientDrawableCompat(){}
}
