package com.oddswatch.mobile;
import java.util.*;
public final class AppState {
    public static volatile List<Signal> signals=new ArrayList<>();
    public static volatile long lastScan=0;
    public static volatile int textChars=0, oddsSeen=0, payloads=0, pages=0;
    public static volatile int matchesAnalyzed=0, wins=0, losses=0;
    public static volatile String currentSport="", currentUrl="", lastError="", debug="Esperando la página de Hard Rock…", screenshot="";
    public static synchronized void setSignals(List<Signal> x){signals=new ArrayList<>(x);lastScan=System.currentTimeMillis();}
    private AppState(){}
}
