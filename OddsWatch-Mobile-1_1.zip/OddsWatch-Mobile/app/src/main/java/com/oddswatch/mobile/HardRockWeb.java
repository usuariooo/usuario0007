package com.oddswatch.mobile;

import android.annotation.SuppressLint;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.webkit.*;
import java.io.*;

public final class HardRockWeb {
    public interface Listener { void onUpdate(); }
    private final Context c;private final WebView web;private final Listener listener;private int sportIndex=0;
    // Used when the user disables the ping-pong-only focus and wants full sport coverage.
    private static final String[] SPORTS={"Table Tennis","eSports","eBasketball","eSoccer","eFootball","Live","Basketball","Baseball","Football","Soccer","Tennis","Hockey","MMA","Boxing","Golf","Volleyball","Darts"};
    // Default focus cycle: Table Tennis appears 3 out of every 4 turns, eSports fills the rest
    // so the scanner still occasionally checks nearby fast-odds markets without drifting away
    // from ping pong.
    private static final String[] FOCUS_SPORTS={"Table Tennis","Table Tennis","eSports","Table Tennis"};

    @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"})
    public HardRockWeb(Context c,WebView web,Listener l){this.c=c;this.web=web;this.listener=l;configure();}
    @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"}) private void configure(){
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setGeolocationEnabled(true);s.setLoadWithOverviewMode(true);s.setUseWideViewPort(true);s.setUserAgentString(s.getUserAgentString()+" OddsWatchFree/3.0");
        CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.addJavascriptInterface(new Bridge(),"OddsWatchBridge");
        web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String u){AppState.pages++;AppState.currentUrl=u;inject();if(Prefs.pingPongOnly(c)){AppState.currentSport="Table Tennis";web.postDelayed(()->clickNav("Table Tennis"),900);}if(listener!=null)listener.onUpdate();}});
        web.setWebChromeClient(new WebChromeClient(){@Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback cb){cb.invoke(origin,true,false);}});
    }
    public void load(String u){web.loadUrl(u);}
    public void scan(){inject();String js="(function(){try{var t=(document.body&&document.body.innerText)||'';OddsWatchBridge.onText(location.href,document.title,t);try{var as=[].slice.call(document.querySelectorAll('a[href]'));var out=[];for(var i=0;i<as.length&&out.length<260;i++){var tx=(as[i].innerText||as[i].textContent||'').trim();if(tx&&tx.length>1&&tx.length<140){out.push({t:tx,h:as[i].getAttribute('href')});}}OddsWatchBridge.onLinks(JSON.stringify(out));}catch(e){}if("+Prefs.autoSweep(c)+"){var h=document.documentElement.scrollHeight||document.body.scrollHeight;var y=window.scrollY||0;var step=Math.max(500,Math.floor(window.innerHeight*.75));if(y+window.innerHeight<h-80)window.scrollBy(0,step);else window.scrollTo(0,0);}return 'ok';}catch(e){return String(e)}})();";web.evaluateJavascript(js,null);}
    public void nextSport(){String[] pool=Prefs.pingPongOnly(c)?FOCUS_SPORTS:SPORTS;String name=pool[sportIndex++%pool.length];clickNav(name);AppState.currentSport=name;}
    public void clickNav(String name){String q=JSONObjectQuote.quote(name);String js="(function(){var n="+q+".toLowerCase();var es=[].slice.call(document.querySelectorAll('a,[role=tab],[role=link]'));for(var i=0;i<es.length;i++){var t=(es[i].innerText||es[i].textContent||'').trim().toLowerCase();if(t===n){es[i].click();return 'clicked '+t;}}return 'not found '+n;})()";web.evaluateJavascript(js,null);}
    public void inject(){String js="(function(){if(window.__ow3)return 'already';window.__ow3=true;try{var of=window.fetch;if(of){window.fetch=async function(){var r=await of.apply(this,arguments);try{var c=r.clone();var t=await c.text();if(t&&t.length<350000)OddsWatchBridge.onPayload(String(arguments[0]),t);}catch(e){}return r;};}var XO=XMLHttpRequest.prototype.open,XS=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__owu=u;return XO.apply(this,arguments)};XMLHttpRequest.prototype.send=function(){this.addEventListener('load',function(){try{var t=this.responseText;if(t&&t.length<350000)OddsWatchBridge.onPayload(String(this.__owu||''),t);}catch(e){}});return XS.apply(this,arguments)};}catch(e){}return 'patched';})()";web.evaluateJavascript(js,null);}
    public void screenshot(){try{if(web.getWidth()<=0||web.getHeight()<=0){web.measure(ViewMeasure.exact(1080),ViewMeasure.exact(1920));web.layout(0,0,1080,1920);}Bitmap b=Bitmap.createBitmap(Math.max(1,web.getWidth()),Math.max(1,web.getHeight()),Bitmap.Config.ARGB_8888);Canvas cv=new Canvas(b);web.draw(cv);File f=new File(c.getFilesDir(),"hardrock_last.png");try(FileOutputStream out=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.PNG,80,out);}AppState.screenshot=f.getAbsolutePath();}catch(Exception ignored){}}
    public WebView web(){return web;}
    private final class Bridge {
        @JavascriptInterface public void onText(String url,String title,String text){SignalEngine.ingestText(text,url);AppState.debug="Página: "+title+"\nURL: "+url+"\nCaracteres de texto visible: "+(text==null?0:text.length())+"\nValores tipo-cuota: "+AppState.oddsSeen+"\nSeñales guardadas: "+AppState.signals.size()+"\nPayloads de red vistos: "+AppState.payloads;web.post(()->{screenshot();if(listener!=null)listener.onUpdate();});}
        @JavascriptInterface public void onPayload(String url,String body){SignalEngine.ingestPayload(body,url);SignalEngine.snapshotNow();if(listener!=null)web.post(listener::onUpdate);}
        @JavascriptInterface public void onLinks(String json){SignalEngine.ingestLinks(json);}
    }
    private static final class JSONObjectQuote {static String quote(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}}
    private static final class ViewMeasure {static int exact(int x){return android.view.View.MeasureSpec.makeMeasureSpec(x,android.view.View.MeasureSpec.EXACTLY);}}
}
