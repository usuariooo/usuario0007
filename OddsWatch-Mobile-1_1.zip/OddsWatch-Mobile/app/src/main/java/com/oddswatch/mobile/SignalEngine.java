package com.oddswatch.mobile;

import org.json.*;
import java.util.*;
import java.util.regex.*;

public final class SignalEngine {
    private static final Pattern AM=Pattern.compile("(?<!\\d)([+-][1-9]\\d{2,3})(?!\\d)");
    private static final Pattern DEC=Pattern.compile("(?<!\\d)(1\\.[0-9]{2,3}|[2-9]\\.[0-9]{2,3})(?!\\d)");
    private static final Map<String,Double> LAST=new HashMap<>();
    private static final Map<String,Long> LAST_AT=new HashMap<>();
    private static final LinkedHashMap<String,Signal> BEST=new LinkedHashMap<>();
    // Real anchor links captured straight from the Hard Rock page DOM (text -> href).
    // Used only to send the user to the exact match page they saw; never auto-clicked.
    private static final List<String[]> LINKS=new ArrayList<>();
    private static final String[] SPORTS={"table tennis","ping pong","esports","e-sports","ebasketball","esoccer","efootball","basketball","baseball","football","soccer","tennis","hockey","mma","boxing","golf","auto racing","nascar","ufc","volleyball","handball","cricket","rugby","lacrosse","darts"};
    private static final String[] MARKETS={"match winner","winner","moneyline","set winner","game winner","map winner","round winner","total points","set total","game total","total games","total","over","under","handicap","spread","correct score","first to","player props","game props"};

    public static synchronized void ingestLinks(String json){
        if(json==null||json.isEmpty())return;
        try{
            JSONArray a=new JSONArray(json);List<String[]> next=new ArrayList<>();
            for(int i=0;i<a.length()&&i<300;i++){
                JSONObject o=a.optJSONObject(i);if(o==null)continue;
                String t=o.optString("t","");String h=o.optString("h","");
                if(t.isEmpty()||h.isEmpty())continue;
                next.add(new String[]{t.toLowerCase(Locale.US),h});
            }
            LINKS.clear();LINKS.addAll(next);
        }catch(Exception ignored){}
    }

    public static synchronized List<Signal> ingestText(String text,String url){
        if(text==null)text=""; AppState.textChars=text.length();AppState.currentUrl=url==null?"":url;
        String[] raw=text.replace("\r","").split("\n");List<String> lines=new ArrayList<>();
        for(String r:raw){String s=r.trim().replaceAll("\\s+"," ");if(!s.isEmpty()&&s.length()<180)lines.add(s);}
        int seen=0;String currentSport=findSport(text);
        for(int i=0;i<lines.size();i++){
            String line=lines.get(i);Matcher m=AM.matcher(line);
            while(m.find()){
                seen++;String odds=m.group(1);int ai=parseAmerican(odds);if(ai==0)continue;
                String context=context(lines,i,8);String market=findMarket(context);String sport=findSport(context);if("Unknown".equals(sport))sport=currentSport;
                String selection=selection(lines,i,odds);String event=event(lines,i,selection,market);
                add(makeSignal(sport,event,market,selection,odds,ai,url,"visible page"));
            }
            if(!AM.matcher(line).find()){
                Matcher d=DEC.matcher(line);while(d.find()){
                    double dec=parseDouble(d.group(1));if(dec<1.01||dec>20)continue;seen++;int ai=decimalToAmerican(dec);String odds=formatAmerican(ai);
                    String context=context(lines,i,8);String market=findMarket(context);String sport=findSport(context);if("Unknown".equals(sport))sport=currentSport;
                    String selection=selection(lines,i,d.group(1));String event=event(lines,i,selection,market);
                    add(makeSignal(sport,event,market,selection,odds,ai,url,"visible page"));
                }
            }
        }
        AppState.oddsSeen=seen;return snapshot();
    }

    public static synchronized void ingestPayload(String body,String url){
        if(body==null||body.length()<2||body.length()>350000)return;AppState.payloads++;
        try{Object o=body.trim().startsWith("[")?new JSONArray(body):new JSONObject(body);walk(o,new Ctx(),url,0);}catch(Exception ignored){}
    }
    private static void walk(Object o,Ctx c,String url,int depth){if(o==null||depth>11)return;
        if(o instanceof JSONArray){JSONArray a=(JSONArray)o;for(int i=0;i<Math.min(a.length(),900);i++)walk(a.opt(i),copy(c),url,depth+1);return;}
        if(!(o instanceof JSONObject))return;JSONObject j=(JSONObject)o;Ctx n=copy(c);Integer price=null;String oddsStr=null;
        Iterator<String> it=j.keys();while(it.hasNext()){
            String k=it.next();Object v=j.opt(k);String kl=k.toLowerCase(Locale.US);if(v instanceof String){String s=((String)v).trim();if(s.length()<150){if(kl.contains("sport")||kl.contains("category"))n.sport=clean(s);else if(kl.contains("event")||kl.contains("fixture")||kl.contains("match"))n.event=clean(s);else if(kl.contains("market")||kl.contains("bettype")||kl.equals("type"))n.market=clean(s);else if(kl.contains("selection")||kl.contains("outcome")||kl.contains("participant"))n.selection=clean(s);else if("name".equals(kl)&&n.selection.isEmpty())n.selection=clean(s);Matcher am=AM.matcher(s);if((kl.contains("odd")||kl.contains("price"))&&am.find()){oddsStr=am.group(1);price=parseAmerican(oddsStr);}}}
            if(v instanceof Number&&(kl.contains("odd")||kl.contains("price"))){double x=((Number)v).doubleValue();if(Math.abs(x)>=100&&Math.abs(x)<=10000){price=(int)Math.round(x);oddsStr=formatAmerican(price);}else if(x>1.01&&x<20){price=decimalToAmerican(x);oddsStr=formatAmerican(price);}}
        }
        if(price!=null&&!n.selection.isEmpty()&&(!n.market.isEmpty()||!n.event.isEmpty()))add(makeSignal(normalizeSport(n.sport),n.event,n.market,n.selection,oddsStr,price,url,"Hard Rock page data"));
        it=j.keys();while(it.hasNext()){Object v=j.opt(it.next());if(v instanceof JSONObject||v instanceof JSONArray)walk(v,n,url,depth+1);}
    }

    private static Signal makeSignal(String sport,String event,String market,String selection,String odds,int american,String url,String source){
        Signal s=new Signal();s.sport=normalizeSport(sport);s.event=clean(event);s.market=clean(market);if(s.market.isEmpty())s.market="Market";s.selection=clean(selection);s.odds=odds;s.url=url==null?"":url;s.source=source;
        String all=(s.sport+" "+s.event+" "+s.market+" "+s.selection).toLowerCase(Locale.US);s.live=all.contains("live")||all.contains("in play")||all.contains("in-play");
        s.impliedPct=implied(american)*100.0;s.id=(s.sport+"|"+s.event+"|"+s.market+"|"+s.selection).toLowerCase(Locale.US);
        Double prev=LAST.get(s.id);Long pa=LAST_AT.get(s.id);s.movementPp=prev==null?0:s.impliedPct-prev;long now=System.currentTimeMillis();
        LAST.put(s.id,s.impliedPct);LAST_AT.put(s.id,now);
        boolean ping=all.contains("table tennis")||all.contains("ping pong")||all.matches(".*\\btt\\b.*");boolean esport=all.contains("esport")||all.contains("ebasketball")||all.contains("esoccer")||all.contains("efootball");
        // Table tennis is the primary focus of this build: it gets the largest score bonus.
        // Other esports (ebasketball/esoccer/efootball/generic esports) are kept as a
        // secondary, lower-priority category instead of near-parity with table tennis.
        int score=30+("Hard Rock page data".equals(source)?10:0)+(ping?34:0)+(esport&&!ping?8:0)+(s.live?10:0);
        String ml=s.market.toLowerCase(Locale.US);if(ml.contains("set")||ml.contains("game")||ml.contains("total")||ml.contains("winner")||ml.contains("handicap")||ml.contains("spread"))score+=8;
        if(prev!=null&&pa!=null&&now-pa<10*60*1000){if(s.movementPp>=1.0)score+=Math.min(25,(int)Math.round(s.movementPp*5));else if(s.movementPp<=-1.5)score-=8;}
        int actionThreshold=ping?58:72;
        s.actionable=prev!=null&&s.movementPp>=1.2&&score>=actionThreshold;s.score=Math.max(0,Math.min(99,score));
        String matched=matchLink(s.event);if(matched==null)matched=matchLink(s.selection);
        if(matched!=null){String resolved=resolveUrl(matched,url);if(resolved!=null){s.url=resolved;s.matchedLink=true;}}
        if(prev==null)s.reason="Baseline collected. Waiting for a second price snapshot before suggesting a tap.";
        else if(s.actionable)s.reason="Market support increased by "+String.format(Locale.US,"%.1f",s.movementPp)+" probability points. This is a movement signal, not a guaranteed edge.";
        else if(s.movementPp<0)s.reason="Price moved against this selection by "+String.format(Locale.US,"%.1f",Math.abs(s.movementPp))+" probability points; watch rather than chase.";
        else s.reason="Tracked from Hard Rock locally. Signal is below the action threshold for now.";
        return s;
    }
    private static String matchLink(String query){
        if(query==null)return null;String q=query.toLowerCase(Locale.US).trim();
        if(q.isEmpty()||"hard rock event".equals(q)||"selection".equals(q))return null;
        String best=null;int bestScore=0;
        for(String[] pair:LINKS){
            String t=pair[0];int score=0;
            if(t.equals(q))score=100;
            else if(t.contains(q))score=70+Math.min(20,q.length());
            else if(q.contains(t)&&t.length()>=4)score=60+Math.min(15,t.length());
            if(score>bestScore){bestScore=score;best=pair[1];}
        }
        return bestScore>=60?best:null;
    }
    private static String resolveUrl(String href,String pageUrl){
        if(href==null||href.isEmpty())return null;
        if(href.startsWith("http://")||href.startsWith("https://"))return href;
        try{java.net.URL base=new java.net.URL(pageUrl==null||pageUrl.isEmpty()?"https://www.hardrock.bet/":pageUrl);return new java.net.URL(base,href).toString();}catch(Exception e){return null;}
    }
    private static void add(Signal s){if(s.selection.isEmpty()||s.odds.isEmpty())return;Signal old=BEST.get(s.id);if(old==null||s.score>=old.score||s.at>old.at)BEST.put(s.id,s);while(BEST.size()>350){String k=BEST.keySet().iterator().next();BEST.remove(k);}}
    private static List<Signal> snapshot(){List<Signal>x=new ArrayList<>(BEST.values());x.sort((a,b)->{int q=Boolean.compare(b.actionable,a.actionable);if(q!=0)return q;q=Integer.compare(b.score,a.score);if(q!=0)return q;return Long.compare(b.at,a.at);});if(x.size()>80)x=new ArrayList<>(x.subList(0,80));AppState.setSignals(x);return x;}
    public static synchronized List<Signal> snapshotNow(){return snapshot();}

    private static String context(List<String>l,int i,int n){StringBuilder b=new StringBuilder();for(int k=Math.max(0,i-n);k<=Math.min(l.size()-1,i+2);k++)b.append(l.get(k)).append(" | ");return b.toString();}
    private static String selection(List<String>l,int i,String odds){String line=l.get(i).replace(odds,"").trim();if(line.length()>1&&!looksGeneric(line))return line;for(int k=i-1;k>=Math.max(0,i-4);k--){String s=l.get(k);if(!looksGeneric(s)&&!AM.matcher(s).find()&&s.length()<70)return s;}return "Selection";}
    private static String event(List<String>l,int i,String sel,String market){for(int k=i-2;k>=Math.max(0,i-8);k--){String s=l.get(k);String sl=s.toLowerCase(Locale.US);if(s.equals(sel)||s.equalsIgnoreCase(market)||findMarket(s).length()>0||isSportWord(sl)||looksGeneric(s)||AM.matcher(s).find())continue;if(s.length()>=4&&s.length()<100)return s;}return "Hard Rock event";}
    private static boolean looksGeneric(String s){String x=s.toLowerCase(Locale.US);return x.equals("live")||x.equals("sports")||x.equals("more")||x.equals("all")||x.equals("bets")||x.equals("bet")||x.contains("sign up")||x.contains("log in")||x.contains("cash out")||x.length()<2;}
    private static String findMarket(String x){String l=x.toLowerCase(Locale.US);for(String m:MARKETS)if(l.contains(m))return title(m);return "";}
    private static String findSport(String x){String l=x.toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong"))return "Table Tennis";if(l.contains("ebasketball"))return "eBasketball";if(l.contains("esoccer"))return "eSoccer";if(l.contains("efootball"))return "eFootball";if(l.contains("esports")||l.contains("e-sports"))return "eSports";for(String s:SPORTS)if(l.contains(s))return title(s);return "Unknown";}
    private static boolean isSportWord(String l){for(String s:SPORTS)if(l.equals(s))return true;return false;}
    private static String normalizeSport(String s){if(s==null||s.trim().isEmpty())return "Unknown";return findSport(s).equals("Unknown")?clean(s):findSport(s);}
    private static double implied(int a){return a<0?(-a)/(double)((-a)+100):100.0/(a+100.0);}
    private static int parseAmerican(String s){try{int x=Integer.parseInt(s.replace("+",""));return Math.abs(x)>=100?x:0;}catch(Exception e){return 0;}}
    private static int decimalToAmerican(double d){if(d>=2)return (int)Math.round((d-1)*100);return (int)Math.round(-100/(d-1));}
    private static String formatAmerican(int a){return a>0?"+"+a:String.valueOf(a);}
    private static double parseDouble(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
    private static String clean(String s){return s==null?"":s.trim().replaceAll("\\s+"," ");}
    private static String title(String s){StringBuilder b=new StringBuilder();for(String p:s.split(" ")){if(p.isEmpty())continue;if(b.length()>0)b.append(' ');b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));}return b.toString();}
    private static Ctx copy(Ctx x){Ctx y=new Ctx();y.sport=x.sport;y.event=x.event;y.market=x.market;y.selection=x.selection;return y;}
    private static class Ctx{String sport="",event="",market="",selection="";}
    private SignalEngine(){}
}
