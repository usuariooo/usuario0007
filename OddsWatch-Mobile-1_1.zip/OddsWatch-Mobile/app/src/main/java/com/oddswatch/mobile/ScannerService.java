package com.oddswatch.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import android.webkit.WebView;
import java.util.*;

public class ScannerService extends Service {
    public static final String ACTION="com.oddswatch.free.UPDATE";
    private Handler h;private WebView web;private HardRockWeb hr;private int tick=0;private String lastNotified="";
    @Override public void onCreate(){super.onCreate();channel();startForeground(31,baseNotification("Iniciando el lector gratuito de Hard Rock…"));h=new Handler(Looper.getMainLooper());
        web=new WebView(this);web.measure(android.view.View.MeasureSpec.makeMeasureSpec(1080,android.view.View.MeasureSpec.EXACTLY),android.view.View.MeasureSpec.makeMeasureSpec(1920,android.view.View.MeasureSpec.EXACTLY));web.layout(0,0,1080,1920);
        hr=new HardRockWeb(this,web,this::updated);hr.load(Prefs.url(this));h.postDelayed(loop,5000);
    }
    private final Runnable loop=new Runnable(){public void run(){if(!Prefs.running(ScannerService.this)){stopSelf();return;}try{hr.scan();if(Prefs.allSports(ScannerService.this)&&tick++%3==0)hr.nextSport();}catch(Exception e){AppState.lastError=e.getMessage();}h.postDelayed(this,Prefs.interval(ScannerService.this)*1000L);}};
    private void updated(){sendBroadcast(new Intent(ACTION).setPackage(getPackageName()));List<Signal>x=AppState.signals;if(x!=null&&!x.isEmpty()){Signal s=x.get(0);if(s.actionable&&!s.id.equals(lastNotified)&&s.score>=Prefs.threshold(this)){lastNotified=s.id;notifySignal(s);}}}
    private void channel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("owfree","Señales de OddsWatch",NotificationManager.IMPORTANCE_HIGH);getSystemService(NotificationManager.class).createNotificationChannel(ch);}}
    private Notification baseNotification(String t){return new Notification.Builder(this,"owfree").setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat).setContentTitle("Escáner OddsWatch").setContentText(t).setOngoing(true).build();}
    private void notifySignal(Signal s){Intent i=new Intent(this,MainActivity.class);i.putExtra("tab","detected");PendingIntent p=PendingIntent.getActivity(this,3,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(this,"owfree").setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat).setContentTitle("Señal "+s.score+"/100 • "+s.sport).setContentText("TOCAR: "+s.selection+" "+s.odds).setStyle(new Notification.BigTextStyle().bigText(s.event+"\n"+s.market+"\nTOCAR: "+s.selection+" "+s.odds+"\n"+s.reason)).setContentIntent(p).setAutoCancel(true).build();getSystemService(NotificationManager.class).notify(1000+(s.id.hashCode()&0x7fff),n);}
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public void onDestroy(){if(h!=null)h.removeCallbacksAndMessages(null);if(web!=null)web.destroy();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
