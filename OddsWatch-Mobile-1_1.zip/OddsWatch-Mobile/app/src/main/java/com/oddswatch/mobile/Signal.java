package com.oddswatch.mobile;
import java.util.Locale;
public class Signal {
    public String id="", sport="Unknown", event="", market="", selection="", odds="", url="", reason="", source="", screenshot="";
    public int score=0;
    public boolean live=false, actionable=false, matchedLink=false;
    // "", "WON" or "LOST" — set only by the user tapping the buttons in DETECTED.
    // OddsWatch has no way to know the real outcome of a bet, so this is a personal log, not a verified result.
    public String outcome="";
    public double impliedPct=Double.NaN, movementPp=0;
    public long at=System.currentTimeMillis();
    public String probability(){return Double.isNaN(impliedPct)?"—":String.format(Locale.US,"%.1f%%",impliedPct);}
    public String move(){return String.format(Locale.US,"%+.1f pp",movementPp);}
    public String share(){return "Señal OddsWatch\n"+(live?"EN VIVO":"PRE-PARTIDO")+" • "+sport+"\n"+event+"\n"+market+"\nTOCAR: "+selection+" "+odds+"\nImplícita: "+probability()+" • movimiento "+move()+" • señal "+score+"/100\n"+reason;}
}
