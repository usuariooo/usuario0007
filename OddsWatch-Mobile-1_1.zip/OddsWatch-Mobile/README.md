# OddsWatch Ping Pong 3.1

No paid odds API. No Twilio. No embedded secrets.

## What it does
- Loads Hard Rock Bet in an Android WebView and reads what the page itself renders.
- **Focused on Table Tennis / Ping Pong by default.** On page load it auto-clicks into the Table Tennis section, and the automatic sport-cycling is biased so Table Tennis is checked 3 out of every 4 cycles (eSports fills the rest). A "Focus on Table Tennis / Ping Pong only" switch on the SCAN tab is ON by default; turn it off to go back to scanning all sports evenly.
- Captures visible text plus JSON/XHR/fetch responses that the Hard Rock page exposes to its own browser session.
- Generic market parser: Match Winner, Set/Game Winner, totals, points, spreads/handicaps, correct score, props and other odds-like values.
- Table Tennis signals get the largest score bonus and a lower `TOCAR` action threshold than other sports, so real ping pong movement surfaces faster. Other sports/eSports are still tracked as a lower-priority secondary check.
- The `DETECTED` tab is filtered to Table Tennis only while focus mode is on.
- While scanning, OddsWatch also reads the real `<a href>` links already present on the Hard Rock page and matches them to the event/selection it detected. When a confident match is found, `OPEN HARD ROCK` takes you straight to that match's page instead of the sportsbook homepage — you still tap and confirm the bet yourself inside Hard Rock; OddsWatch never clicks a bet/odds button or fills the slip for you.
- Each detected card shows a large, clearly highlighted box with exactly what to look for: the selection name and the odds, so it's obvious what to tap once you're on Hard Rock.
- Stores price history locally and waits for a second snapshot before showing a green `TOCAR` signal. First sightings are baseline/watch only.
- `DETECTED` tab shows the selection, odds, implied probability, movement, score, reason, and the latest Hard Rock page capture.
- Local Android notifications only. `SHARE` can send the signal through WhatsApp manually without a paid API.
- Does not log credentials, does not click bet/odds buttons, and does not place wagers.

## Important limitation
Hard Rock does not publish a free official developer odds feed. This app uses a local browser-reader approach. Website changes, login/geolocation requirements, or anti-automation behavior can break extraction. The DEBUG screen explicitly reports what was actually read instead of silently returning zero.

## Build using your existing GitHub workflow
The ZIP can be named `OddsWatch-Mobile-1.1.zip` and its project folder is `OddsWatch-Mobile`, so the v1.1 GitHub Action already used in this repository can compile it without changing the workflow.
