package com.oddswatch.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Pantalla de presentación estilo GOAT / deporte premium.
 * Colores: navy profundo, teal vivo, oro.
 */
public class SplashActivity extends Activity {
    private static final int BG = Color.rgb(4, 14, 29);
    private static final int TEAL = Color.rgb(49, 211, 195);
    private static final int GOLD = Color.rgb(255, 189, 74);
    private static final int WHITE = Color.rgb(247, 250, 255);
    private static final int MUTED = Color.rgb(157, 179, 203);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        cp.gravity = Gravity.CENTER;
        center.setLayoutParams(cp);
        center.setPadding(dp(28), 0, dp(28), 0);

        // Logo mark (radar rings with gold core)
        View logo = buildLogoMark();
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(dp(112), dp(112));
        lpLogo.bottomMargin = dp(28);
        logo.setLayoutParams(lpLogo);
        center.addView(logo);

        // App name
        TextView name = label("ODDSWATCH", 34, true, WHITE);
        name.setLetterSpacing(0.12f);
        center.addView(name);

        // Tagline
        TextView tag = label("VISION  •  LIVE EDGE", 14, true, TEAL);
        tag.setPadding(0, dp(10), 0, 0);
        tag.setLetterSpacing(0.18f);
        center.addView(tag);

        // Divider gold line
        View line = new View(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(GOLD);
        gd.setCornerRadius(dp(2));
        line.setBackground(gd);
        LinearLayout.LayoutParams lpLine = new LinearLayout.LayoutParams(dp(56), dp(3));
        lpLine.topMargin = dp(22);
        lpLine.bottomMargin = dp(18);
        lpLine.gravity = Gravity.CENTER_HORIZONTAL;
        line.setLayoutParams(lpLine);
        center.addView(line);

        // GOAT sports vibe
        TextView goat = label("PARA LOS QUE VEN EL MOVIMIENTO", 12, true, GOLD);
        goat.setLetterSpacing(0.08f);
        center.addView(goat);

        TextView sub = label("Noche Virtual  ·  Paper Testing  ·  $0 real", 13, false, MUTED);
        sub.setPadding(0, dp(10), 0, 0);
        sub.setGravity(Gravity.CENTER);
        center.addView(sub);

        // Bottom brand strip
        TextView bottom = label("TENIS DE MESA  ·  ESPORTS  ·  LIVE", 11, true, Color.rgb(90, 120, 150));
        bottom.setLetterSpacing(0.14f);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        bp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        bp.bottomMargin = dp(36);
        bottom.setLayoutParams(bp);
        bottom.setGravity(Gravity.CENTER);

        root.addView(center);
        root.addView(bottom);

        // Fade-in
        AlphaAnimation fade = new AlphaAnimation(0f, 1f);
        fade.setDuration(700);
        fade.setInterpolator(new DecelerateInterpolator());
        center.startAnimation(fade);
        bottom.startAnimation(fade);

        // Go to main
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent i = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(i);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 2200);
    }

    /** Simple geometric radar / target mark drawn with nested views */
    private View buildLogoMark() {
        FrameLayout box = new FrameLayout(this);

        // outer teal ring
        View outer = ring(TEAL, 4);
        box.addView(outer, match());

        // gold ring
        View mid = ring(GOLD, 3);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(78), dp(78));
        mp.gravity = Gravity.CENTER;
        box.addView(mid, mp);

        // teal core disc
        View core = new View(this);
        GradientDrawable coreBg = new GradientDrawable();
        coreBg.setShape(GradientDrawable.OVAL);
        coreBg.setColor(TEAL);
        core.setBackground(coreBg);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(28), dp(28));
        cp.gravity = Gravity.CENTER;
        box.addView(core, cp);

        // center navy dot
        View dot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(BG);
        dot.setBackground(dotBg);
        FrameLayout.LayoutParams dpLp = new FrameLayout.LayoutParams(dp(10), dp(10));
        dpLp.gravity = Gravity.CENTER;
        box.addView(dot, dpLp);

        return box;
    }

    private View ring(int color, int strokeDp) {
        View v = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Color.TRANSPARENT);
        g.setStroke(dp(strokeDp), color);
        v.setBackground(g);
        return v;
    }

    private FrameLayout.LayoutParams match() {
        return new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
    }

    private TextView label(String text, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        else t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        return t;
    }

    private int dp(int x) {
        return Math.round(x * getResources().getDisplayMetrics().density);
    }
}
