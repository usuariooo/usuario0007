package com.oddswatch.mobile;

import java.util.Locale;

public class MarketAlert {
    public String id="", sport="", event="", market="", selection="", hardRockPrice="", detail="";
    public double evPct=Double.NaN;
    public double hardRockImpliedPct=Double.NaN;
    public double fairProbPct=Double.NaN;
    public double probGapPct=Double.NaN;
    public double lineGap=0;
    public double hardRockLine=Double.NaN;
    public double consensusLine=Double.NaN;
    public double staleMinutes=0;
    public int score=0, peers=0;
    public boolean live=false;
    public long hardRockUpdatedAt=0;

    public String marketLabel(){
        if ("h2h".equals(market)) return "Moneyline";
        if ("spreads".equals(market)) return "Spread";
        if ("totals".equals(market)) return "Total";
        return market;
    }

    public String probabilityLine(){
        String hr=Double.isNaN(hardRockImpliedPct)?"—":String.format(Locale.US,"%.1f%%",hardRockImpliedPct);
        String fair=Double.isNaN(fairProbPct)?"—":String.format(Locale.US,"%.1f%%",fairProbPct);
        String gap=Double.isNaN(probGapPct)?"—":String.format(Locale.US,"%+.1f pp",probGapPct);
        return "Hard Rock implied "+hr+" • consensus fair "+fair+" • gap "+gap;
    }

    public String metricsLine(){
        String edge=Double.isNaN(evPct)?"—":String.format(Locale.US,"%+.1f%% EV",evPct);
        String line=lineGap>0.0001?" • line gap "+String.format(Locale.US,"%.1f",lineGap):"";
        String stale=staleMinutes>=0.5?" • HR stale +"+String.format(Locale.US,"%.1fm",staleMinutes):"";
        return "Anomaly "+score+"/100 • "+edge+line+stale+" • "+peers+" peers";
    }

    public String oneLine(){
        return (live?"LIVE":"PRE")+" • "+sport+" • "+event+" • "+selection+" "+hardRockPrice+
                " • "+metricsLine();
    }

    public String whatsappPart1(){
        String s=(live?"LIVE":"PRE")+" "+sport+" "+event+" "+selection+" "+hardRockPrice;
        return cut(s,150);
    }

    public String whatsappPart2(){
        String s="score "+score+"/100; "+probabilityLine()+"; "+metricsLine();
        return cut(s.replace("•","|"),220);
    }

    private static String cut(String s,int max){return s.length()<=max?s:s.substring(0,max-1)+"…";}
}
