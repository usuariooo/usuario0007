package com.oddswatch.mobile;

import android.content.Context;
import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;

/**
 * Real-data-only analyzer. Target book: Hard Rock Bet Florida (hardrockbet_fl).
 * Consensus is built from other books. It detects price, line and freshness discrepancies.
 */
public final class OddsAnalyzer {
    private static final String API="https://api.the-odds-api.com/v4";
    private static final String HR="hardrockbet_fl";
    private static final String BOOKS="hardrockbet_fl,draftkings,fanduel,betmgm,betrivers,espnbet";
    private static final Set<String> MAJOR=new LinkedHashSet<>(Arrays.asList(
            "baseball_mlb","basketball_nba","basketball_wnba","basketball_ncaab",
            "americanfootball_nfl","americanfootball_ncaaf","icehockey_nhl",
            "soccer_usa_mls","soccer_epl","soccer_uefa_champs_league"
    ));

    public static ScanResult scan(Context c) throws Exception {
        String key=Prefs.apiKey(c).trim();
        if(key.isEmpty()) throw new IllegalStateException("REAL DATA requires a The Odds API key. Add it in Settings first.");

        ScanResult result=new ScanResult();
        List<String> active=fetchActiveSports(key,result);
        List<String> sports=new ArrayList<>();
        if(Prefs.allSports(c)){
            sports.addAll(active);
            // Guard against accidentally exhausting a small plan in one scan.
            if(sports.size()>30) sports=new ArrayList<>(sports.subList(0,30));
        }else{
            for(String s:active) if(MAJOR.contains(s)) sports.add(s);
        }
        if(sports.isEmpty()) throw new IllegalStateException("No selected sports are active right now.");

        for(String sport:sports){
            if(result.quotaRemaining>=0 && result.quotaRemaining<=Prefs.quotaReserve(c)) break;
            try{
                result.alerts.addAll(fetchSport(c,key,sport,result));
                result.scannedSports++;
            }catch(Exception e){
                // One sport failing should not kill the entire 24/7 scanner.
                AppState.error="Last sport error ("+sport+"): "+e.getMessage();
            }
        }
        result.alerts.sort((a,b)->Integer.compare(b.score,a.score));
        if(result.alerts.size()>60) result.alerts.subList(60,result.alerts.size()).clear();
        result.completedAt=System.currentTimeMillis();
        return result;
    }

    public static String testApi(Context c) throws Exception {
        String key=Prefs.apiKey(c).trim();
        if(key.isEmpty()) throw new IllegalStateException("Enter your The Odds API key first.");
        ScanResult r=new ScanResult();
        List<String> a=fetchActiveSports(key,r);
        String q=r.quotaRemaining>=0?String.valueOf(r.quotaRemaining):"unknown";
        return "API connected • "+a.size()+" active sports • remaining requests: "+q;
    }

    private static List<String> fetchActiveSports(String key,ScanResult result) throws Exception {
        HttpResult h=get(API+"/sports?apiKey="+enc(key)); updateQuota(h,result);
        JSONArray a=new JSONArray(h.body); List<String> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i); if(x==null)continue;
            if(x.optBoolean("active",true)){String k=x.optString("key");if(!k.isEmpty())out.add(k);}
        }
        return out;
    }

    private static List<MarketAlert> fetchSport(Context c,String key,String sport,ScanResult result) throws Exception {
        String u=API+"/sports/"+enc(sport)+"/odds?apiKey="+enc(key)+
                "&bookmakers="+enc(BOOKS)+"&markets=h2h,spreads,totals&oddsFormat=american&dateFormat=iso";
        HttpResult h=get(u); updateQuota(h,result);
        JSONArray games=new JSONArray(h.body); result.gamesSeen+=games.length();
        List<MarketAlert> out=new ArrayList<>(); long now=System.currentTimeMillis();

        for(int gi=0;gi<games.length();gi++){
            JSONObject g=games.optJSONObject(gi); if(g==null)continue;
            long start=parseTime(g.optString("commence_time"));
            boolean live=start>0 && start<=now && now-start<12L*60*60*1000;
            if(live&&!Prefs.includeLive(c))continue;
            if(!live&&!Prefs.includePre(c))continue;
            String event=g.optString("away_team")+" @ "+g.optString("home_team");
            JSONArray books=g.optJSONArray("bookmakers"); if(books==null)continue;
            JSONObject hard=null; List<JSONObject> peers=new ArrayList<>();
            for(int bi=0;bi<books.length();bi++){
                JSONObject b=books.optJSONObject(bi); if(b==null)continue;
                if(HR.equals(b.optString("key")))hard=b; else peers.add(b);
            }
            if(hard==null)continue; result.hardRockGames++;
            long hrUpdated=parseTime(hard.optString("last_update"));
            JSONArray hm=hard.optJSONArray("markets"); if(hm==null)continue;

            for(int mi=0;mi<hm.length();mi++){
                JSONObject market=hm.optJSONObject(mi); if(market==null)continue;
                String mk=market.optString("key");
                JSONArray outcomes=market.optJSONArray("outcomes"); if(outcomes==null)continue;

                for(int oi=0;oi<outcomes.length();oi++){
                    JSONObject ho=outcomes.optJSONObject(oi); if(ho==null)continue;
                    String name=ho.optString("name");
                    double point=ho.has("point")?ho.optDouble("point",Double.NaN):Double.NaN;
                    int price=ho.optInt("price",0); if(price==0)continue;

                    List<Double> fairPs=new ArrayList<>();
                    List<Double> peerPoints=new ArrayList<>();
                    List<Long> peerUpdates=new ArrayList<>();
                    int peerMatches=0;

                    for(JSONObject pb:peers){
                        JSONObject pm=findMarket(pb,mk); if(pm==null)continue;
                        JSONArray po=pm.optJSONArray("outcomes"); if(po==null)continue;
                        JSONObject match=findOutcomeByName(po,name); if(match==null)continue;
                        peerMatches++;
                        long pu=parseTime(pb.optString("last_update")); if(pu>0)peerUpdates.add(pu);
                        if(match.has("point"))peerPoints.add(match.optDouble("point"));

                        boolean comparable="h2h".equals(mk) || (samePoint(point,match));
                        if(comparable){
                            Map<String,Double> nv=noVig(po);
                            String k=outcomeKey(match);
                            if(nv.containsKey(k))fairPs.add(nv.get(k));
                        }
                    }
                    if(peerMatches<2)continue;

                    double implied=implied(price)*100.0;
                    double fair= fairPs.size()>=2 ? median(fairPs) : Double.NaN;
                    double fairPct=Double.isNaN(fair)?Double.NaN:fair*100.0;
                    double probGap=Double.isNaN(fair)?Double.NaN:fairPct-implied;
                    double ev=Double.isNaN(fair)?Double.NaN:(fair*americanToDecimal(price)-1.0)*100.0;
                    double consensusLine=(!Double.isNaN(point)&&!peerPoints.isEmpty())?median(peerPoints):Double.NaN;
                    double lineGap=(!Double.isNaN(point)&&!Double.isNaN(consensusLine))?Math.abs(point-consensusLine):0;
                    double stale=staleMinutes(hrUpdated,peerUpdates);

                    boolean priceSignal=!Double.isNaN(ev) && ev>=Prefs.minEdge(c);
                    boolean probSignal=!Double.isNaN(probGap) && probGap>=2.0;
                    boolean lineSignal=!"h2h".equals(mk) && lineGap>=0.5;
                    boolean staleSignal=stale>=2.0 && !Double.isNaN(ev) && ev>=0.5;
                    if(!(priceSignal||probSignal||lineSignal||staleSignal))continue;

                    int score=35;
                    if(!Double.isNaN(ev))score+=clamp((int)Math.round(Math.max(0,ev)*4.0),0,28);
                    if(!Double.isNaN(probGap))score+=clamp((int)Math.round(Math.max(0,probGap)*2.0),0,12);
                    score+=clamp((int)Math.round(lineGap*12.0),0,18);
                    score+=clamp((int)Math.round(stale*2.0),0,10);
                    score+=clamp(peerMatches*2,0,10); score=clamp(score,0,99);
                    if(score<Prefs.threshold(c))continue;

                    MarketAlert a=new MarketAlert();
                    a.id=g.optString("id")+"|"+mk+"|"+name+"|"+point+"|"+price;
                    a.sport=g.optString("sport_title",sport); a.event=event; a.market=mk;
                    a.selection=name+(Double.isNaN(point)?"":" "+fmtPoint(point));
                    a.hardRockPrice=formatAmerican(price); a.live=live; a.peers=peerMatches; a.score=score;
                    a.evPct=ev; a.hardRockImpliedPct=implied; a.fairProbPct=fairPct; a.probGapPct=probGap;
                    a.lineGap=lineGap; a.hardRockLine=point; a.consensusLine=consensusLine; a.staleMinutes=stale; a.hardRockUpdatedAt=hrUpdated;
                    a.detail=detail(a,fairPs.size());
                    out.add(a);
                }
            }
        }
        return out;
    }

    private static String detail(MarketAlert a,int fairBooks){
        List<String> p=new ArrayList<>();
        if(!Double.isNaN(a.fairProbPct))p.add("fair probability from "+fairBooks+" same-line peer books");
        if(a.lineGap>0.0001&&!Double.isNaN(a.consensusLine))p.add("peer median line "+fmtPoint(a.consensusLine)+" vs HR "+fmtPoint(a.hardRockLine));
        if(a.staleMinutes>=0.5)p.add("Hard Rock quote is ~"+String.format(Locale.US,"%.1f min",a.staleMinutes)+" older than peer median");
        p.add("market discrepancy only; not a guaranteed outcome");
        return join(p,"; ")+".";
    }

    private static double staleMinutes(long hr,List<Long> peers){
        if(hr<=0||peers.isEmpty())return 0; List<Double>x=new ArrayList<>();for(Long v:peers)x.add(v.doubleValue());
        long med=(long)median(x); return Math.max(0,(med-hr)/60000.0);
    }
    private static boolean samePoint(double hr,JSONObject peer){
        if(Double.isNaN(hr))return !peer.has("point");
        return peer.has("point")&&Math.abs(peer.optDouble("point")-hr)<0.001;
    }
    private static JSONObject findMarket(JSONObject book,String key){JSONArray a=book.optJSONArray("markets");if(a==null)return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&key.equals(x.optString("key")))return x;}return null;}
    private static JSONObject findOutcomeByName(JSONArray a,String name){for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&name.equals(x.optString("name")))return x;}return null;}
    private static String outcomeKey(JSONObject o){return o.optString("name")+"|"+(o.has("point")?o.optDouble("point"):"-");}
    private static Map<String,Double> noVig(JSONArray a){Map<String,Double> raw=new HashMap<>();double sum=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;int p=o.optInt("price",0);if(p==0)continue;double q=implied(p);raw.put(outcomeKey(o),q);sum+=q;}if(sum>0){for(String k:new ArrayList<>(raw.keySet()))raw.put(k,raw.get(k)/sum);}return raw;}
    private static double implied(int a){return a<0?(-a)/(double)((-a)+100):100.0/(a+100.0);}
    private static double americanToDecimal(int a){return a>0?1+a/100.0:1+100.0/(-a);}
    private static String formatAmerican(int a){return a>0?"+"+a:String.valueOf(a);}
    private static String fmtPoint(double p){if(Double.isNaN(p))return "—";return (p>0?"+":"")+(Math.rint(p)==p?String.format(Locale.US,"%.0f",p):String.format(Locale.US,"%.1f",p));}
    private static double median(List<Double>x){Collections.sort(x);int n=x.size();return n%2==1?x.get(n/2):(x.get(n/2-1)+x.get(n/2))/2.0;}
    private static long parseTime(String s){try{return Instant.parse(s).toEpochMilli();}catch(Exception e){return 0;}}
    private static int clamp(int v,int lo,int hi){return Math.max(lo,Math.min(hi,v));}
    private static String join(List<String>x,String sep){StringBuilder b=new StringBuilder();for(String s:x){if(b.length()>0)b.append(sep);b.append(s);}return b.toString();}
    private static String enc(String s)throws Exception{return URLEncoder.encode(s==null?"":s,"UTF-8");}

    private static class HttpResult{String body="";int remaining=-1,used=-1,last=-1;}
    private static HttpResult get(String url)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection(); h.setConnectTimeout(12000);h.setReadTimeout(18000);
        h.setRequestProperty("User-Agent","OddsWatch-Final/2.0"); int code=h.getResponseCode();
        InputStream in=(code>=200&&code<300)?h.getInputStream():h.getErrorStream(); String text=read(in);
        if(code<200||code>=300)throw new IOException("Odds API HTTP "+code+": "+shorten(text,320));
        HttpResult r=new HttpResult();r.body=text;r.remaining=parseHeader(h,"x-requests-remaining");r.used=parseHeader(h,"x-requests-used");r.last=parseHeader(h,"x-requests-last");return r;
    }
    private static int parseHeader(HttpURLConnection h,String k){try{String v=h.getHeaderField(k);return v==null?-1:(int)Math.floor(Double.parseDouble(v));}catch(Exception e){return -1;}}
    private static void updateQuota(HttpResult h,ScanResult r){if(h.remaining>=0)r.quotaRemaining=h.remaining;if(h.used>=0)r.quotaUsed=h.used;if(h.last>=0)r.lastRequestCost=h.last;}
    private static String read(InputStream in)throws Exception{if(in==null)return"";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[4096];int n;while((n=in.read(z))>0)b.write(z,0,n);return b.toString(StandardCharsets.UTF_8.name());}
    private static String shorten(String s,int max){if(s==null)return"";s=s.replace('\n',' ').replace('\r',' ');return s.length()<=max?s:s.substring(0,max)+"…";}
    private OddsAnalyzer(){}
}
