package com.oddswatch.mobile;
import android.graphics.Rect;
public class OcrLine {
    public final String text; public final Rect box;
    public OcrLine(String t,Rect b){text=t==null?"":t.trim();box=b==null?new Rect():b;}
    public int cx(){return box.centerX();} public int cy(){return box.centerY();}
}
