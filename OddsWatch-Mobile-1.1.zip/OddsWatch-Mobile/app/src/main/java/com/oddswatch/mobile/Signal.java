package com.oddswatch.mobile;

import org.json.JSONObject;

public class Signal {
    public String id="", sport="", event="", market="", selection="", odds="", screenshot="", reason="", status="PENDIENTE";
    public double implied=0, movement=0, score=0, simulatedProfit=0;
    public long createdAt=0, updatedAt=0, resolvedAt=0;

    public JSONObject toJson(){
        JSONObject o=new JSONObject();
        try{
            o.put("id",id);o.put("sport",sport);o.put("event",event);o.put("market",market);o.put("selection",selection);
            o.put("odds",odds);o.put("screenshot",screenshot);o.put("reason",reason);o.put("status",status);
            o.put("implied",implied);o.put("movement",movement);o.put("score",score);o.put("simulatedProfit",simulatedProfit);
            o.put("createdAt",createdAt);o.put("updatedAt",updatedAt);o.put("resolvedAt",resolvedAt);
        }catch(Exception ignored){}
        return o;
    }
    public static Signal fromJson(JSONObject o){
        Signal s=new Signal();
        s.id=o.optString("id");s.sport=o.optString("sport");s.event=o.optString("event");s.market=o.optString("market");s.selection=o.optString("selection");
        s.odds=o.optString("odds");s.screenshot=o.optString("screenshot");s.reason=o.optString("reason");s.status=o.optString("status","PENDIENTE");
        s.implied=o.optDouble("implied");s.movement=o.optDouble("movement");s.score=o.optDouble("score");s.simulatedProfit=o.optDouble("simulatedProfit");
        s.createdAt=o.optLong("createdAt");s.updatedAt=o.optLong("updatedAt");s.resolvedAt=o.optLong("resolvedAt");
        return s;
    }
}
