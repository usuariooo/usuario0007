package com.oddswatch.mobile;
import java.util.Locale;
public class Signal {
    public String id="", sport="Unknown", event="", market="", selection="", odds="", url="", reason="", source="", screenshot="";
    public int score=0;
    public boolean live=false, actionable=false;
    public double impliedPct=Double.NaN, movementPp=0;
    public long at=System.currentTimeMillis();
    public String probability(){return Double.isNaN(impliedPct)?"—":String.format(Locale.US,"%.1f%%",impliedPct);}
    public String move(){return String.format(Locale.US,"%+.1f pp",movementPp);}
    public String share(){return "OddsWatch signal\n"+(live?"LIVE":"PRE")+" • "+sport+"\n"+event+"\n"+market+"\nTOCAR: "+selection+" "+odds+"\nImplied: "+probability()+" • movement "+move()+" • signal "+score+"/100\n"+reason;}
}
