package com.oddswatch.mobile;

import org.json.JSONObject;

public class Signal {
    public String id="", baseId="", sessionId="", sport="", event="", market="", selection="", odds="", previousOdds="", screenState="", screenshot="", reason="", status="PENDIENTE", resultSource="";
    public double implied=0, movement=0, score=0, simulatedProfit=0, stake=0, potentialProfit=0;
    public long createdAt=0, updatedAt=0, resolvedAt=0;
    public int targetX=0, targetY=0, cropTop=0, cropBottom=0, observations=0;
    public boolean paper=false, live=false;

    public JSONObject toJson(){
        JSONObject o=new JSONObject();
        try{
            o.put("id",id);o.put("baseId",baseId);o.put("sessionId",sessionId);o.put("sport",sport);o.put("event",event);o.put("market",market);o.put("selection",selection);
            o.put("odds",odds);o.put("previousOdds",previousOdds);o.put("screenState",screenState);o.put("screenshot",screenshot);o.put("reason",reason);o.put("status",status);o.put("resultSource",resultSource);
            o.put("implied",implied);o.put("movement",movement);o.put("score",score);o.put("simulatedProfit",simulatedProfit);o.put("stake",stake);o.put("potentialProfit",potentialProfit);
            o.put("createdAt",createdAt);o.put("updatedAt",updatedAt);o.put("resolvedAt",resolvedAt);o.put("targetX",targetX);o.put("targetY",targetY);o.put("cropTop",cropTop);o.put("cropBottom",cropBottom);o.put("observations",observations);o.put("paper",paper);o.put("live",live);
        }catch(Exception ignored){}
        return o;
    }
    public static Signal fromJson(JSONObject o){
        Signal s=new Signal();
        s.id=o.optString("id");s.baseId=o.optString("baseId",s.id);s.sessionId=o.optString("sessionId");s.sport=o.optString("sport");s.event=o.optString("event");s.market=o.optString("market");s.selection=o.optString("selection");
        s.odds=o.optString("odds");s.previousOdds=o.optString("previousOdds","");s.screenState=o.optString("screenState","");s.screenshot=o.optString("screenshot");s.reason=o.optString("reason");s.status=o.optString("status","PENDIENTE");s.resultSource=o.optString("resultSource","");
        s.implied=o.optDouble("implied");s.movement=o.optDouble("movement");s.score=o.optDouble("score");s.simulatedProfit=o.optDouble("simulatedProfit");s.stake=o.optDouble("stake");s.potentialProfit=o.optDouble("potentialProfit");
        s.createdAt=o.optLong("createdAt");s.updatedAt=o.optLong("updatedAt");s.resolvedAt=o.optLong("resolvedAt");s.targetX=o.optInt("targetX");s.targetY=o.optInt("targetY");s.cropTop=o.optInt("cropTop");s.cropBottom=o.optInt("cropBottom");s.observations=o.optInt("observations",0);s.paper=o.optBoolean("paper",false);s.live=o.optBoolean("live",false);
        return s;
    }
}
