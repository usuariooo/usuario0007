package com.oddswatch.mobile;

import org.json.JSONObject;

public class Signal {
    public String id="", sport="", event="", market="", selection="", odds="", url="", deepLink="", screenshot="";
    public String instruction="", source="";
    public double implied=0, modelProbability=0, edge=0, score=0, simulatedProfit=0;
    public long createdAt=0, updatedAt=0, resolvedAt=0;
    public String status="PENDIENTE";
    public String reason="";

    public JSONObject toJson(){
        JSONObject o=new JSONObject();
        try {
            o.put("id",id); o.put("sport",sport); o.put("event",event); o.put("market",market); o.put("selection",selection);
            o.put("odds",odds); o.put("url",url); o.put("deepLink",deepLink); o.put("screenshot",screenshot);
            o.put("instruction",instruction); o.put("source",source);
            o.put("implied",implied); o.put("modelProbability",modelProbability); o.put("edge",edge); o.put("score",score);
            o.put("createdAt",createdAt); o.put("updatedAt",updatedAt); o.put("resolvedAt",resolvedAt); o.put("status",status);
            o.put("reason",reason); o.put("simulatedProfit",simulatedProfit);
        } catch(Exception ignored){}
        return o;
    }

    public static Signal fromJson(JSONObject o){
        Signal s=new Signal();
        s.id=o.optString("id"); s.sport=o.optString("sport"); s.event=o.optString("event"); s.market=o.optString("market");
        s.selection=o.optString("selection"); s.odds=o.optString("odds"); s.url=o.optString("url"); s.deepLink=o.optString("deepLink");
        s.screenshot=o.optString("screenshot"); s.instruction=o.optString("instruction"); s.source=o.optString("source");
        s.implied=o.optDouble("implied"); s.modelProbability=o.optDouble("modelProbability");
        s.edge=o.optDouble("edge"); s.score=o.optDouble("score"); s.createdAt=o.optLong("createdAt"); s.updatedAt=o.optLong("updatedAt");
        s.resolvedAt=o.optLong("resolvedAt"); s.status=o.optString("status","PENDIENTE"); s.reason=o.optString("reason");
        s.simulatedProfit=o.optDouble("simulatedProfit",0);
        return s;
    }
}
