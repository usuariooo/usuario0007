package com.oddswatch.mobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(7,18,29), CARD=Color.rgb(16,36,55), CARD2=Color.rgb(21,49,73), ACC=Color.rgb(25,197,176), GOLD=Color.rgb(255,181,71), RED=Color.rgb(255,107,107), TEXT=Color.rgb(246,249,252), MUTED=Color.rgb(157,176,194);
    private Store store; private LinearLayout root, content, nav; private TextView status; private Handler ui=new Handler(Looper.getMainLooper()); private String tab="home";
    private BroadcastReceiver receiver;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); store=new Store(this); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); buildShell();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},20);
        String open=getIntent().getStringExtra("tab"); if(open!=null) tab=open; render();
        receiver=new BroadcastReceiver(){ public void onReceive(Context c,Intent i){ refreshStatus(); if(!"browser".equals(tab)) render(); }};
        IntentFilter filter=new IntentFilter(ScannerService.ACTION_UPDATE);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,filter,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,filter);
        ui.post(clock);
    }
    @Override public void onDestroy(){ try{unregisterReceiver(receiver);}catch(Exception ignored){} ui.removeCallbacksAndMessages(null); super.onDestroy(); }

    private final Runnable clock=new Runnable(){ public void run(){ refreshStatus(); if("detected".equals(tab)||"stats".equals(tab)) render(); ui.postDelayed(this,1000); }};

    private void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setPadding(dp(16),dp(10),dp(16),dp(8)); setContentView(root);
        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); root.addView(head,new LinearLayout.LayoutParams(-1,-2));
        TextView brand=txt("ODDSWATCH",30,true,TEXT); head.addView(brand); TextView sub=txt("Radar gratuito • datos visibles de Hard Rock • Español",13,false,MUTED); head.addView(sub);
        status=txt("",14,true,ACC); status.setPadding(0,dp(8),0,dp(8)); head.addView(status); refreshStatus();
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0,dp(4),0,dp(16)); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); hs.addView(nav); root.addView(hs,new LinearLayout.LayoutParams(-1,dp(56)));
        navButton("INICIO","home"); navButton("DETECTADAS","detected"); navButton("HISTORIAL","history"); navButton("ESTADÍSTICAS","stats"); navButton("HARD ROCK","browser"); navButton("AJUSTES","settings");
    }

    private void navButton(String name,String key){ Button b=button(name,false); b.setOnClickListener(v->{tab=key;render();}); nav.addView(b,new LinearLayout.LayoutParams(dp(130),dp(48))); }

    private void render(){
        if(content==null) return; content.removeAllViews();
        switch(tab){ case "detected":renderDetected();break; case "history":renderHistory();break; case "stats":renderStats();break; case "browser":renderBrowser();break; case "settings":renderSettings();break; default:renderHome(); }
    }

    private void renderHome(){
        title("Radar en tiempo real");
        LinearLayout c=card();
        c.addView(txt(store.scannerOn()?"● SCANNER ENCENDIDO":"○ SCANNER APAGADO",20,true,store.scannerOn()?ACC:MUTED));
        c.addView(txt("Lee nuevamente la página actual cada 1 segundo. Cambia de deporte automáticamente; Tenis de mesa y eSports tienen prioridad.",15,false,TEXT));
        Switch sw=new Switch(this); sw.setText("Scanner automático"); sw.setTextColor(TEXT); sw.setChecked(store.scannerOn()); sw.setOnCheckedChangeListener((x,on)->toggleScanner(on)); c.addView(sw);
        Button now=button("ESCANEAR AHORA",true); now.setOnClickListener(v->{ if(!store.scannerOn()) toggleScanner(true); Toast.makeText(this,"Scanner activado. Actualiza cada segundo.",Toast.LENGTH_SHORT).show();}); c.addView(now);
        content.addView(c);

        title("Qué está viendo"); LinearLayout d=card();
        d.addView(kv("Deporte actual",spanishSport(store.currentSport()))); d.addView(kv("Odds detectadas en último escaneo",String.valueOf(store.oddsSeen()))); d.addView(kv("Páginas / snapshots",String.valueOf(store.pages()))); d.addView(kv("Payloads de red vistos",String.valueOf(store.payloads())));
        String err=store.lastError(); if(!err.isEmpty()) d.addView(txt("ERROR REAL: "+err,14,true,RED));
        content.addView(d);

        title("Cómo decide una señal"); LinearLayout e=card();
        e.addView(txt("No crea una apuesta con el primer precio. Espera al menos dos lecturas. En tenis de mesa intenta usar el marcador visible para estimar la probabilidad del set/selección y la compara con la probabilidad implícita de la cuota.",14,false,TEXT));
        e.addView(txt("En otros deportes el modelo de marcador es experimental. El historial te permitirá comprobar si sirve o no antes de confiar en él.",14,false,GOLD)); content.addView(e);
    }

    private void renderDetected(){
        title("Detectadas ahora");
        List<Signal> all=store.loadSignals(); long now=System.currentTimeMillis(); ArrayList<Signal> a=new ArrayList<>();
        for(Signal s:all) if("PENDIENTE".equals(s.status)&&now-s.updatedAt<120000) a.add(s);
        if(a.isEmpty()){ LinearLayout c=card(); c.addView(txt("Todavía no hay una señal activa.",18,true,TEXT)); c.addView(txt("Esto ya no se queda pegado: una señal que deje de actualizarse desaparece de este menú después de 2 minutos, pero permanece en Historial para comprobar el resultado.",14,false,MUTED)); content.addView(c); return; }
        for(Signal s:a) signalCard(s,true);
    }

    private void signalCard(Signal s,boolean active){
        LinearLayout c=card();
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); TextView sport=txt(("Tenis de mesa".equals(s.sport)?"🏓 ":"🎯 ")+s.sport,14,true,ACC); top.addView(sport,new LinearLayout.LayoutParams(0,-2,1)); TextView sc=txt(Math.round(s.score)+"/99",14,true,GOLD); top.addView(sc); c.addView(top);
        c.addView(txt(s.event,19,true,TEXT));
        TextView touch=txt("TOCA EN HARD ROCK",13,true,GOLD); touch.setPadding(0,dp(8),0,dp(2)); c.addView(touch);
        c.addView(step("1", "PARTIDO", s.event)); c.addView(step("2", "MERCADO", s.market)); c.addView(step("3", "SELECCIÓN", s.selection)); c.addView(step("4", "CUOTA", s.odds));
        c.addView(txt(String.format(Locale.US,"Modelo %.1f%% • Cuota implica %.1f%% • Diferencia +%.1f pp",s.modelProbability*100,s.implied*100,s.edge*100),14,true,ACC));
        if(!s.screenshot.isEmpty() && new File(s.screenshot).exists()){
            Bitmap b=BitmapFactory.decodeFile(s.screenshot); if(b!=null){ ImageView im=new ImageView(this); im.setImageBitmap(b); im.setScaleType(ImageView.ScaleType.CENTER_CROP); c.addView(im,new LinearLayout.LayoutParams(-1,dp(180))); }
        }
        c.addView(txt(s.reason,13,false,MUTED));
        LinearLayout buttons=new LinearLayout(this); Button open=button("ABRIR PARTIDO",true); open.setOnClickListener(v->openHardRock(s)); buttons.addView(open,new LinearLayout.LayoutParams(0,dp(48),1)); Button share=button("COMPARTIR",false); share.setOnClickListener(v->share(s)); buttons.addView(share,new LinearLayout.LayoutParams(0,dp(48),1)); c.addView(buttons);
        if(!active){ c.addView(resultButtons(s)); }
        content.addView(c);
    }

    private View step(String n,String label,String value){ LinearLayout r=new LinearLayout(this); r.setPadding(0,dp(3),0,dp(3)); TextView num=txt(n,14,true,BG); num.setGravity(Gravity.CENTER); num.setBackground(pill(ACC)); r.addView(num,new LinearLayout.LayoutParams(dp(28),dp(28))); LinearLayout t=new LinearLayout(this); t.setOrientation(LinearLayout.VERTICAL); t.setPadding(dp(10),0,0,0); t.addView(txt(label,11,true,MUTED)); t.addView(txt(value,17,true,TEXT)); r.addView(t,new LinearLayout.LayoutParams(0,-2,1)); return r; }

    private View resultButtons(Signal s){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(0,dp(8),0,0);
        box.addView(txt("Resultado: "+s.status+("PENDIENTE".equals(s.status)?" • OddsWatch seguirá intentando resolverlo automáticamente":""),13,true,statusColor(s.status)));
        LinearLayout r=new LinearLayout(this); String[][] vals={{"GANADA","GANADA"},{"PERDIDA","PERDIDA"},{"PUSH","PUSH"}};
        for(String[] x:vals){ Button b=button(x[0],false); b.setOnClickListener(v->{store.setResult(s.id,x[1]);render();}); r.addView(b,new LinearLayout.LayoutParams(0,dp(44),1)); } box.addView(r); return box;
    }

    private void renderHistory(){
        title("Historial y resultados"); List<Signal> a=store.loadSignals(); if(a.isEmpty()){content.addView(txt("Aún no hay señales guardadas.",16,false,MUTED));return;}
        for(Signal s:a) signalCard(s,false);
    }

    private void renderStats(){
        title("¿Está siendo rentable?"); List<Signal> a=store.loadSignals(); int w=0,l=0,p=0,pen=0; double units=0;
        for(Signal s:a){ switch(s.status){ case "GANADA":w++;units+=s.simulatedProfit;break; case "PERDIDA":l++;units+=s.simulatedProfit;break; case "PUSH":p++;break; default:pen++; } }
        int resolved=w+l; double wr=resolved==0?0:w*100.0/resolved; double roi=resolved==0?0:units/resolved*100;
        LinearLayout c=card(); c.addView(bigStat(String.format(Locale.US,"%.1f%%",wr),"PORCENTAJE DE GANADAS",wr>=50?ACC:GOLD));
        LinearLayout row=new LinearLayout(this); row.addView(smallStat(String.valueOf(w),"Ganadas",ACC),new LinearLayout.LayoutParams(0,-2,1)); row.addView(smallStat(String.valueOf(l),"Perdidas",RED),new LinearLayout.LayoutParams(0,-2,1)); row.addView(smallStat(String.valueOf(p),"Push",GOLD),new LinearLayout.LayoutParams(0,-2,1)); row.addView(smallStat(String.valueOf(pen),"Pendientes",MUTED),new LinearLayout.LayoutParams(0,-2,1)); c.addView(row);
        c.addView(bigStat(String.format(Locale.US,"%+.2f u",units),"GANANCIA SIMULADA • 1 UNIDAD POR SEÑAL",units>=0?ACC:RED));
        c.addView(txt(String.format(Locale.US,"ROI simulado: %+.1f%%",roi),16,true,roi>=0?ACC:RED));
        c.addView(txt("Esto mide las señales guardadas, no dinero real. Si el porcentaje y el ROI no se sostienen con una muestra grande, el modelo no está demostrando rentabilidad.",13,false,MUTED)); content.addView(c);
        title("Últimas resueltas"); int n=0; for(Signal s:a){ if(!"PENDIENTE".equals(s.status)){ signalCard(s,false); if(++n>=8)break; } }
    }

    private void renderBrowser(){
        title("Hard Rock • iniciar sesión / comprobar partido"); LinearLayout note=card(); note.addView(txt("Este navegador comparte cookies con el scanner. Inicia sesión aquí si Hard Rock la pide. OddsWatch solo lee la página; no toca el botón de apostar.",14,false,TEXT)); content.addView(note);
        WebView w=new WebView(this); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(w,true); w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient()); w.loadUrl("https://www.hardrock.bet/sportsbook"); content.addView(w,new LinearLayout.LayoutParams(-1,dp(620)));
    }

    private void renderSettings(){
        title("Ajustes"); LinearLayout c=card();
        c.addView(txt("Idioma: Español",16,true,TEXT));
        Switch ping=new Switch(this); ping.setText("Prioridad máxima: tenis de mesa / ping pong"); ping.setTextColor(TEXT); ping.setChecked(store.pingPongPriority()); ping.setOnCheckedChangeListener((x,v)->store.setPingPongPriority(v)); c.addView(ping);
        Switch esp=new Switch(this); esp.setText("Prioridad: eSports"); esp.setTextColor(TEXT); esp.setChecked(store.esportsPriority()); esp.setOnCheckedChangeListener((x,v)->store.setEsportsPriority(v)); c.addView(esp);
        c.addView(txt("Actualización de cuotas: 1 segundo (fija)",14,true,ACC));
        c.addView(txt("Cambio de deporte cada (segundos, mínimo 3):",13,false,MUTED)); EditText cycle=input(String.valueOf(store.sportCycleSeconds())); c.addView(cycle); Button saveCycle=button("GUARDAR INTERVALO",false); saveCycle.setOnClickListener(v->{try{store.setSportCycleSeconds(Integer.parseInt(cycle.getText().toString()));Toast.makeText(this,"Guardado",Toast.LENGTH_SHORT).show();}catch(Exception ignored){}}); c.addView(saveCycle);
        c.addView(txt("Score mínimo para mostrar una señal (1-99):",13,false,MUTED)); EditText score=input(String.valueOf(store.minScore())); c.addView(score); Button saveScore=button("GUARDAR SCORE",false); saveScore.setOnClickListener(v->{try{store.setMinScore(Integer.parseInt(score.getText().toString()));Toast.makeText(this,"Guardado",Toast.LENGTH_SHORT).show();}catch(Exception ignored){}}); c.addView(saveScore);
        Button clear=button("BORRAR HISTORIAL",false); clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Borrar historial").setMessage("¿Borrar todas las señales y estadísticas?").setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(d,w)->{store.clearHistory();render();}).show()); c.addView(clear);
        content.addView(c);
        title("Diagnóstico"); LinearLayout d=card(); d.addView(kv("Último escaneo",fmt(store.lastScan()))); d.addView(kv("Deporte",spanishSport(store.currentSport()))); d.addView(kv("Odds visibles",String.valueOf(store.oddsSeen()))); d.addView(kv("Payloads",String.valueOf(store.payloads()))); d.addView(kv("Error",store.lastError().isEmpty()?"Ninguno":store.lastError())); content.addView(d);
    }

    private void toggleScanner(boolean on){ store.setScannerOn(on); if(on){ Intent i=new Intent(this,ScannerService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); } else stopService(new Intent(this,ScannerService.class)); refreshStatus(); render(); }

    private void openHardRock(Signal s){
        String pkg="com.hardrockdigital.client";
        ArrayList<String> tries=new ArrayList<>();
        if(s.deepLink!=null&&!s.deepLink.isEmpty()) tries.add(decodeDeep(s.deepLink));
        if(s.url!=null&&!s.url.isEmpty()) tries.add(s.url);
        for(String u:tries){
            try{ Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(u)); i.setPackage(pkg); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return; }catch(Exception ignored){}
        }
        try{ Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);return;} }catch(Exception ignored){}
        Toast.makeText(this,"No pude abrir Hard Rock Bet. Instala/actualiza la app.",Toast.LENGTH_LONG).show();
    }
    private String decodeDeep(String x){
        try{
            Uri u=Uri.parse(x); String d=u.getQueryParameter("deep_link_value"); if(d!=null&&!d.isEmpty()) return d;
        }catch(Exception ignored){} return x;
    }
    private void share(Signal s){ String x="OddsWatch\n"+s.event+"\nTOCA: "+s.selection+" "+s.odds+"\nMercado: "+s.market+"\nScore: "+Math.round(s.score)+"/99"; Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,x);startActivity(Intent.createChooser(i,"Compartir señal")); }

    private void refreshStatus(){ if(status==null)return; String t=store.scannerOn()?"● ACTUALIZANDO CADA 1 SEGUNDO • "+spanishSport(store.currentSport()):"○ SCANNER APAGADO"; status.setText(t); status.setTextColor(store.scannerOn()?ACC:MUTED); }
    private String spanishSport(String x){ if(x==null)return""; switch(x){case"Table Tennis":return"Tenis de mesa";case"Basketball":return"Baloncesto";case"Baseball":return"Béisbol";case"Soccer":return"Fútbol";case"Volleyball":return"Voleibol";case"Darts":return"Dardos";case"Boxing":return"Boxeo";case"Tennis":return"Tenis";default:return x;} }
    private String fmt(long t){ return t==0?"Nunca":new SimpleDateFormat("MMM d • h:mm:ss a",Locale.getDefault()).format(new Date(t)); }

    private void title(String s){ TextView t=txt(s,21,true,TEXT); t.setPadding(0,dp(14),0,dp(8)); content.addView(t); }
    private LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16),dp(14),dp(16),dp(14)); c.setBackground(round(CARD,18)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(10));c.setLayoutParams(p);return c; }
    private TextView txt(String s,int sp,boolean bold,int color){ TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(0,1.08f); if(bold)t.setTypeface(null,Typeface.BOLD);return t; }
    private TextView kv(String a,String b){ TextView t=txt(a+":  "+b,14,false,TEXT);t.setPadding(0,dp(3),0,dp(3));return t; }
    private Button button(String s,boolean primary){ Button b=new Button(this);b.setText(s);b.setTextColor(primary?BG:TEXT);b.setTextSize(12);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(primary?ACC:CARD2,14));return b; }
    private EditText input(String s){ EditText e=new EditText(this);e.setText(s);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setSingleLine(true);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(round(CARD2,12));return e; }
    private GradientDrawable round(int color,int radius){ GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d; }
    private GradientDrawable pill(int color){ GradientDrawable d=round(color,50);return d; }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
    private int statusColor(String s){ if("GANADA".equals(s))return ACC;if("PERDIDA".equals(s))return RED;if("PUSH".equals(s))return GOLD;return MUTED; }
    private View bigStat(String value,String label,int color){ LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(0,dp(8),0,dp(8));x.addView(txt(value,32,true,color));x.addView(txt(label,12,true,MUTED));return x; }
    private View smallStat(String value,String label,int color){ LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);x.addView(txt(value,22,true,color));x.addView(txt(label,11,false,MUTED));return x; }
}
