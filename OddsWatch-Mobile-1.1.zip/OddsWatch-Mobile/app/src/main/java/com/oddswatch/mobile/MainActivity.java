package com.oddswatch.mobile;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private LinearLayout list;
    private TextView status,lastError,meta,secretState;
    private Switch power,allSports,live,pre,wa;
    private EditText api,interval,threshold,minEdge,reserve,sid,token,from,to,contentSid;
    private final ExecutorService exec=Executors.newSingleThreadExecutor();
    private final BroadcastReceiver rx=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){refresh();}};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2);
        build();load();refresh();
    }
    @Override protected void onResume(){super.onResume();
        if(Build.VERSION.SDK_INT>=33)registerReceiver(rx,new IntentFilter(ScannerService.ACTION_UPDATED),Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(rx,new IntentFilter(ScannerService.ACTION_UPDATED));
        refresh();
    }
    @Override protected void onPause(){try{unregisterReceiver(rx);}catch(Exception ignored){}super.onPause();}

    private void build(){
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(Color.rgb(5,12,18));
        LinearLayout root=col();root.setPadding(dp(18),dp(24),dp(18),dp(60));sc.addView(root);setContentView(sc);
        root.addView(t("REAL ODDS • HARD ROCK FL",11,Color.rgb(102,135,155),true));
        root.addView(t("OddsWatch Final",31,Color.WHITE,true));
        root.addView(t("v2.0 • real-data-only anomaly scanner",13,Color.rgb(149,171,187),false));
        status=t("SCANNER OFF",13,Color.rgb(244,184,96),true);status.setPadding(0,dp(8),0,dp(12));root.addView(status);
        meta=t("No real scan yet",12,Color.rgb(122,148,166),false);root.addView(meta);

        LinearLayout hero=panel();
        hero.addView(t("24/7 market monitor",20,Color.WHITE,true));
        hero.addView(t("Targets Hard Rock Bet Florida and compares it with peer sportsbooks. Detects price gaps, fair-probability gaps, line differences and stale quotes.",14,Color.rgb(157,176,191),false));
        power=sw("Scanner ON");hero.addView(power);root.addView(hero);

        root.addView(section("REAL ODDS DATA"));
        api=input("The Odds API key (leave blank to keep saved key)",true);root.addView(api);
        secretState=t("",11,Color.rgb(100,190,150),false);root.addView(secretState);
        Button getKey=btn("GET / MANAGE ODDS API KEY");root.addView(getKey);
        allSports=sw("Scan ALL active sports (high API usage)");root.addView(allSports);
        live=sw("Include LIVE events");root.addView(live);pre=sw("Include PRE-GAME events");root.addView(pre);
        interval=input("Scan interval seconds (minimum 60)",false);interval.setInputType(InputType.TYPE_CLASS_NUMBER);root.addView(interval);
        threshold=input("Anomaly score threshold 0-99",false);threshold.setInputType(InputType.TYPE_CLASS_NUMBER);root.addView(threshold);
        minEdge=input("Minimum price EV % (example 2.0)",false);minEdge.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);root.addView(minEdge);
        reserve=input("Protect this many API requests (example 50)",false);reserve.setInputType(InputType.TYPE_CLASS_NUMBER);root.addView(reserve);

        root.addView(section("WHATSAPP ALERTS"));
        wa=sw("Send top qualifying alert to WhatsApp");root.addView(wa);
        to=input("Recipient number (E.164)",false);root.addView(to);
        from=input("Twilio WhatsApp sender",false);root.addView(from);
        sid=input("Twilio Account SID",false);root.addView(sid);
        token=input("NEW Twilio Auth Token (leave blank to keep saved token)",true);root.addView(token);
        contentSid=input("WhatsApp template Content SID (HX...)",false);root.addView(contentSid);
        root.addView(t("Twilio Trial forces approved wording and may ignore custom variable values. OddsWatch always shows the full real alert in Android notifications; full custom WhatsApp details require an eligible/upgraded Twilio sender and an approved template that accepts your variables.",11,Color.rgb(118,140,156),false));

        Button save=btn("SAVE SETTINGS");root.addView(save);
        Button testApi=btn("TEST REAL ODDS API");root.addView(testApi);
        Button scan=btn("SCAN REAL DATA NOW");root.addView(scan);
        Button testWa=btn("TEST WHATSAPP");root.addView(testWa);
        lastError=t("",12,Color.rgb(255,112,112),false);lastError.setPadding(0,dp(10),0,0);root.addView(lastError);

        root.addView(section("TOP REAL ANOMALIES"));list=col();root.addView(list);
        root.addView(t("Probabilities are derived from sportsbook prices and a no-vig peer consensus. They are estimates, not guarantees. OddsWatch does not log into Hard Rock or place wagers.",11,Color.rgb(82,101,116),false));

        getKey.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://the-odds-api.com/")));}catch(Exception e){Toast.makeText(this,"Open the-odds-api.com in your browser",Toast.LENGTH_LONG).show();}});
        save.setOnClickListener(v->{save();Toast.makeText(this,"Settings saved securely",Toast.LENGTH_SHORT).show();refreshSecretState();});
        power.setOnCheckedChangeListener((v,on)->{Prefs.p(this).edit().putBoolean("running",on).apply();if(on){save();startScanner();}else stopService(new Intent(this,ScannerService.class));refresh();});
        testApi.setOnClickListener(v->{save();testApi();});scan.setOnClickListener(v->{save();scanNow();});testWa.setOnClickListener(v->{save();testWa();});
    }

    private void load(){
        allSports.setChecked(Prefs.allSports(this));live.setChecked(Prefs.includeLive(this));pre.setChecked(Prefs.includePre(this));
        interval.setText(String.valueOf(Prefs.interval(this)));threshold.setText(String.valueOf(Prefs.threshold(this)));
        minEdge.setText(String.format(Locale.US,"%.1f",Prefs.minEdge(this)));reserve.setText(String.valueOf(Prefs.quotaReserve(this)));
        wa.setChecked(Prefs.whatsapp(this));to.setText(Prefs.waTo(this));from.setText(Prefs.twFrom(this));sid.setText(Prefs.twSid(this));contentSid.setText(Prefs.twContentSid(this));
        api.setText("");token.setText("");power.setChecked(Prefs.running(this));if(Prefs.running(this))startScanner();refreshSecretState();
    }

    private void save(){
        int sec=Math.max(60,parseInt(interval.getText().toString(),180));
        int th=Math.max(0,Math.min(99,parseInt(threshold.getText().toString(),72)));
        int qr=Math.max(0,parseInt(reserve.getText().toString(),50));
        double edge=Math.max(0,parseDouble(minEdge.getText().toString(),2.0));
        Prefs.p(this).edit().putInt("interval_sec",sec).putInt("threshold",th).putInt("quota_reserve",qr)
                .putBoolean("all_sports",allSports.isChecked()).putBoolean("include_live",live.isChecked()).putBoolean("include_pre",pre.isChecked())
                .putBoolean("whatsapp",wa.isChecked()).putString("wa_to",norm(to.getText().toString())).putString("tw_from",norm(from.getText().toString()))
                .putString("tw_sid",sid.getText().toString().trim()).putString("tw_content_sid",contentSid.getText().toString().trim()).apply();
        Prefs.setMinEdge(this,edge);
        String a=api.getText().toString().trim();if(!a.isEmpty()){Prefs.setApiKey(this,a);api.setText("");}
        String tok=token.getText().toString().trim();if(!tok.isEmpty()){Prefs.setTwToken(this,tok);token.setText("");}
    }

    private void refreshSecretState(){
        boolean a=!Prefs.apiKey(this).isEmpty(),t=!Prefs.twToken(this).isEmpty();
        secretState.setText("Odds API key: "+(a?"saved securely":"MISSING")+" • Twilio token: "+(t?"saved securely":"MISSING / ROTATE THEN ADD"));
        secretState.setTextColor(a&&t?Color.rgb(83,211,154):Color.rgb(244,184,96));
    }

    private void startScanner(){Intent i=new Intent(this,ScannerService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}

    private void testApi(){
        status.setText("TESTING API…");exec.submit(()->{try{String s=OddsAnalyzer.testApi(this);runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Real odds API OK").setMessage(s).setPositiveButton("OK",null).show());}
        catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Odds API test failed").setMessage(e.getMessage()).setPositiveButton("OK",null).show());}runOnUiThread(this::refresh);});
    }

    private void scanNow(){
        status.setText("SCANNING REAL MARKETS…");exec.submit(()->{try{ScanResult r=OddsAnalyzer.scan(this);AppState.set(r);}catch(Exception e){AppState.error=e.getMessage();}runOnUiThread(this::refresh);});
    }

    private void testWa(){
        exec.submit(()->{try{WhatsAppSender.sendTest(this);runOnUiThread(()->Toast.makeText(this,"WhatsApp request sent",Toast.LENGTH_LONG).show());}
        catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("WhatsApp test failed").setMessage(e.getMessage()).setPositiveButton("OK",null).show());}});
    }

    private void refresh(){
        boolean r=Prefs.running(this);status.setText(r?"● SCANNER RUNNING":"SCANNER OFF");status.setTextColor(r?Color.rgb(83,211,154):Color.rgb(244,184,96));
        String when=AppState.lastScanAt>0?new SimpleDateFormat("h:mm:ss a",Locale.US).format(new Date(AppState.lastScanAt)):"never";
        String q=AppState.quotaRemaining>=0?String.valueOf(AppState.quotaRemaining):"—";
        meta.setText("Last scan "+when+" • sports "+AppState.scannedSports+" • games "+AppState.gamesSeen+" • HR games "+AppState.hardRockGames+" • API remaining "+q+" • alerts "+(AppState.alerts==null?0:AppState.alerts.size()));
        lastError.setText(AppState.error==null||AppState.error.isEmpty()?"":"Last error: "+AppState.error);
        refreshSecretState();
        list.removeAllViews();List<MarketAlert>a=AppState.alerts;
        if(a==null||a.isEmpty()){list.addView(t("No qualifying REAL anomalies loaded. Add an odds API key, then tap SCAN REAL DATA NOW.",13,Color.rgb(128,148,163),false));return;}
        for(MarketAlert x:a){
            LinearLayout c=panel();
            c.addView(t((x.live?"LIVE":"PRE")+"  •  "+x.sport,12,x.live?Color.rgb(83,211,154):Color.rgb(141,161,177),true));
            c.addView(t(x.event,17,Color.WHITE,true));
            c.addView(t(x.marketLabel()+"  •  "+x.selection+"  "+x.hardRockPrice,15,Color.WHITE,true));
            c.addView(t(x.probabilityLine(),12,Color.rgb(129,196,255),true));
            c.addView(t(x.metricsLine(),12,Color.rgb(244,184,96),true));
            c.addView(t(x.detail,12,Color.rgb(157,176,191),false));list.addView(c);
        }
    }

    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout panel(){LinearLayout l=col();l.setPadding(dp(16),dp(16),dp(16),dp(16));GradientDrawableCompat.bg(l,Color.rgb(13,27,38),18);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));l.setLayoutParams(p);return l;}
    private TextView section(String s){TextView v=t(s,12,Color.rgb(111,132,149),true);v.setPadding(0,dp(18),0,dp(8));return v;}
    private TextView t(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);v.setPadding(0,dp(3),0,dp(3));if(bold)v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);return v;}
    private Switch sw(String s){Switch v=new Switch(this);v.setText(s);v.setTextColor(Color.WHITE);v.setPadding(0,dp(8),0,dp(8));return v;}
    private EditText input(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(100,120,135));e.setTextColor(Color.WHITE);e.setSingleLine(true);e.setPadding(dp(12),dp(12),dp(12),dp(12));GradientDrawableCompat.bg(e,Color.rgb(17,31,42),12);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(8));e.setLayoutParams(p);if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);GradientDrawableCompat.bg(b,Color.rgb(23,56,41),14);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(7),0,0);b.setLayoutParams(p);return b;}
    private String norm(String s){s=s==null?"":s.trim();String d=s.replaceAll("[^0-9]","");return d.isEmpty()?"":"+"+d;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private int parseInt(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
    private double parseDouble(String s,double d){try{return Double.parseDouble(s.trim());}catch(Exception e){return d;}}
    @Override protected void onDestroy(){exec.shutdownNow();super.onDestroy();}
}
