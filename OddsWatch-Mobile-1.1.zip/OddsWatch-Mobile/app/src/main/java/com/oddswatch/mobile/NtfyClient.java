package com.oddswatch.mobile;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class NtfyClient {
    public static void send(String topic,String title,String message){
        if(topic==null||topic.isEmpty())return;
        new Thread(()->{try{
            URL u=new URL("https://ntfy.sh/"+URLEncoder.encode(topic,"UTF-8"));
            HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(6000);c.setReadTimeout(6000);c.setRequestMethod("POST");c.setDoOutput(true);
            c.setRequestProperty("Title",title);c.setRequestProperty("Priority","high");c.setRequestProperty("Tags","dart");
            byte[] b=message.getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(b.length);try(OutputStream o=c.getOutputStream()){o.write(b);}c.getResponseCode();c.disconnect();
        }catch(Exception ignored){}}).start();
    }
}
