package com.oddswatch.mobile;

import java.util.*;

public class ScanResult {
    public final List<MarketAlert> alerts = new ArrayList<>();
    public int scannedSports=0;
    public int gamesSeen=0;
    public int hardRockGames=0;
    public int quotaRemaining=-1;
    public int quotaUsed=-1;
    public int lastRequestCost=-1;
    public long completedAt=System.currentTimeMillis();
}
