package com.oddswatch.mobile;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.webkit.*;
import java.io.*;

/**
 * Read-only local reader for the actual Hard Rock Bet web app (app.hardrock.bet).
 * V6 fixes the biggest V5 bug: V5 opened www.hardrock.bet/sportsbook, which is
 * primarily a marketing/education site. This class opens the actual JS sportsbook app.
 */
public class HardRockWeb {
    public interface Listener {
        void onText(String url,String title,String text,String linksJson);
        void onDom(String url,String json);
        void onPayload(String url,String payload);
        void onPage(String url);
        void onError(String error);
    }

    private final WebView web;
    private final Listener listener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private boolean hooksInjected=false;

    @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"})
    public HardRockWeb(Context c, Listener l){
        listener=l;
        web=new WebView(c);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setGeolocationEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        // Keep the normal Android WebView UA. Appending a bot-like suffix can change site behavior.
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.addJavascriptInterface(new Bridge(),"OddsWatchBridge");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback){
                callback.invoke(origin,true,false);
            }
        });
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView v,String url,Bitmap fav){
                hooksInjected=false;
                if(listener!=null) listener.onPage(url);
            }
            @Override public void onPageFinished(WebView v,String url){
                // Inject after the document exists. V5 sometimes marked hooks as injected too early.
                main.postDelayed(()->injectNetworkHooks(true),150);
                main.postDelayed(()->ensureFlorida(),450);
                main.postDelayed(()->scanNow(),900);
                if(listener!=null) listener.onPage(url);
            }
            @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError err){
                if(req.isForMainFrame()&&listener!=null) listener.onError("WebView: "+err.getDescription());
            }
        });
    }

    public WebView view(){ return web; }
    public void loadHome(){ web.loadUrl("https://app.hardrock.bet/"); }
    public void load(String url){ if(url!=null&&!url.isEmpty()) web.loadUrl(url); }
    public String url(){ return web.getUrl()==null?"":web.getUrl(); }

    /** Try to choose Florida when the actual app is showing the state picker. */
    public void ensureFlorida(){
        String js="(function(){try{"+
                "function C(x){return (x||'').replace(/\\s+/g,' ').trim().toLowerCase();}"+
                "var all=[].slice.call(document.querySelectorAll('button,[role=button],[role=option],a[href],[tabindex=\\\"0\\\"]'));"+
                "for(var i=0;i<all.length;i++){var t=C((all[i].innerText||all[i].textContent||'')+' '+(all[i].getAttribute('aria-label')||''));if(t==='florida'||t.indexOf('florida ')===0){all[i].click();return 'florida-clicked';}}"+
                "return 'no-state-picker';}catch(e){return String(e)}})()";
        web.evaluateJavascript(js,null);
    }

    public void scanNow(){
        injectNetworkHooks(false);
        // Snapshot is diagnostic/result-resolution only. Bets come from real controls / JSON.
        String snapshot="(function(){try{var t=(document.body&&document.body.innerText)||'';var a=[];var es=document.querySelectorAll('a[href]');for(var i=0;i<es.length&&i<1800;i++){var z=es[i],tx=(z.innerText||z.textContent||z.getAttribute('aria-label')||'').trim(),h=z.href||'';if(tx&&h)a.push({t:tx.substring(0,180),h:h});}OddsWatchBridge.onSnapshot(location.href,document.title,t,JSON.stringify(a));return 'ok';}catch(e){return String(e)}})();";
        web.evaluateJavascript(snapshot,null);

        // Recursive extractor: document + open shadow roots + same-origin iframes.
        // This is necessary because sportsbook SPAs often render clickable prices below component roots.
        String dom="(function(){try{"+
                "var R=/[+-](?:100|[1-9][0-9]{2,3})(?![0-9])/;"+
                "function C(x){return (x||'').replace(/\\s+/g,' ').trim();}"+
                "function roots(){var rs=[document],seen=new Set(),idx=0;while(idx<rs.length&&rs.length<250){var r=rs[idx++];var els=[];try{els=r.querySelectorAll('*')}catch(e){}for(var i=0;i<els.length;i++){var e=els[i];try{if(e.shadowRoot&&!seen.has(e.shadowRoot)){seen.add(e.shadowRoot);rs.push(e.shadowRoot)}}catch(x){}if((e.tagName||'').toLowerCase()==='iframe'){try{var d=e.contentDocument;if(d&&!seen.has(d)){seen.add(d);rs.push(d)}}catch(x){}}}}return rs;}"+
                "function bad(el){for(var p=el,n=0;p&&n<10;p=p.parentElement,n++){var tg=(p.tagName||'').toLowerCase(),cl=C((p.className||'')+' '+(p.id||'')+' '+(p.getAttribute&&p.getAttribute('data-testid')||'')).toLowerCase();if(tg==='article'||tg==='footer'||cl.indexOf('article')>=0||cl.indexOf('blog')>=0||cl.indexOf('editorial')>=0||cl.indexOf('faq')>=0||cl.indexOf('marketing')>=0||cl.indexOf('education')>=0)return true;}return false;}"+
                "function text(e){return C((e.innerText||e.textContent||'')+' '+(e.getAttribute&&e.getAttribute('aria-label')||'')+' '+(e.getAttribute&&e.getAttribute('title')||''));}"+
                "function attrs(el){var o={};for(var p=el,n=0;p&&n<8;p=p.parentElement,n++){if(!p.attributes)continue;for(var i=0;i<p.attributes.length;i++){var a=p.attributes[i],k=a.name.toLowerCase();if(k.indexOf('data-')===0||k==='id'||k==='href'||k==='aria-label'||k.indexOf('selection')>=0||k.indexOf('outcome')>=0||k.indexOf('event')>=0||k.indexOf('market')>=0){if(a.value&&a.value.length<350)o[k]=a.value;}}}return o;}"+
                "function href(el){for(var p=el,n=0;p&&n<8;p=p.parentElement,n++){try{if(p.href)return p.href;}catch(e){}}return '';}"+
                "function box(el){var p=el,b=el;for(var n=0;p&&n<10;p=p.parentElement,n++){var tx=text(p),od=(tx.match(/[+-](?:100|[1-9][0-9]{2,3})(?![0-9])/g)||[]).length;if(tx.length>4&&tx.length<2200&&od>=1)b=p;if(od>=2&&tx.length>25)break;}return b;}"+
                "var out=[],seen={};var rs=roots();"+
                "for(var rr=0;rr<rs.length&&out.length<1200;rr++){var es=[];try{es=rs[rr].querySelectorAll('button,[role=button],[role=option],[role=radio],a[href],[tabindex=\\\"0\\\"],[data-testid],[data-qa]')}catch(e){}"+
                "for(var i=0;i<es.length&&out.length<1200;i++){var e=es[i],bt=text(e);var mm=bt.match(R);if(!mm||bad(e))continue;var b=box(e),ct=text(b);if(!ct||ct.length>2200)continue;var key=bt+'|'+ct.substring(0,500);if(seen[key])continue;seen[key]=1;var pt=e.parentElement?text(e.parentElement):'',gt=e.parentElement&&e.parentElement.parentElement?text(e.parentElement.parentElement):'';out.push({button:bt,parent:pt,grand:gt,context:ct,href:href(e),attrs:attrs(e),htmlTag:(e.tagName||''),cls:C(e.className||'')});}}"+
                "OddsWatchBridge.onDom(location.href,JSON.stringify(out));return out.length;}catch(e){OddsWatchBridge.onDom(location.href,JSON.stringify({error:String(e)}));return -1;}})();";
        web.evaluateJavascript(dom,null);
    }

    /** Click real sportsbook sport tabs/categories inside the actual app. */
    public void clickSport(String sport){
        String n=quote(sport.toLowerCase());
        String js="(function(){try{var wanted="+n+";var al=[wanted];if(wanted==='table tennis')al=['table tennis','ping pong','tenis de mesa'];if(wanted==='esports')al=['esports','e-sports','esport','ebasketball','esoccer','efootball'];function C(x){return (x||'').replace(/\\s+/g,' ').trim().toLowerCase();}var es=[].slice.call(document.querySelectorAll('button,[role=tab],[role=button],[role=option],a[href],[tabindex=\\\"0\\\"]'));for(var j=0;j<al.length;j++){for(var i=0;i<es.length;i++){var t=C((es[i].innerText||es[i].textContent||'')+' '+(es[i].getAttribute('aria-label')||''));if(t===al[j]||t.indexOf(al[j]+' ')===0||t.indexOf(' '+al[j])>0){es[i].click();return 'clicked '+t;}}}return 'not-found '+wanted;}catch(e){return String(e)}})()";
        web.evaluateJavascript(js,null);
    }

    public void clickLive(){
        web.evaluateJavascript("(function(){try{function C(x){return (x||'').replace(/\\s+/g,' ').trim().toLowerCase();}var es=[].slice.call(document.querySelectorAll('button,[role=tab],[role=button],a[href]'));for(var i=0;i<es.length;i++){var t=C((es[i].innerText||es[i].textContent||'')+' '+(es[i].getAttribute('aria-label')||''));if(t==='live'||t==='en vivo'||t.indexOf('live ')===0){es[i].click();return 'live';}}return 'no-live';}catch(e){return String(e)}})()",null);
    }

    public void gentleScroll(){
        web.evaluateJavascript("(function(){try{var h=document.documentElement.scrollHeight||document.body.scrollHeight;var y=window.scrollY||0;var st=Math.max(550,Math.floor(window.innerHeight*.85));if(y+window.innerHeight<h-100)window.scrollBy(0,st);else window.scrollTo(0,0);}catch(e){}})()",null);
    }

    private void injectNetworkHooks(boolean force){
        if(hooksInjected&&!force) return;
        hooksInjected=true;
        String js="(function(){if(window.__ow6)return 'exists';window.__ow6=true;try{var of=window.fetch;if(of){window.fetch=async function(){var r=await of.apply(this,arguments);try{var c=r.clone();var t=await c.text();if(t&&t.length<1600000)OddsWatchBridge.onPayload(String(arguments[0]),t);}catch(e){}return r;};}var XO=XMLHttpRequest.prototype.open,XS=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__owu=u;return XO.apply(this,arguments)};XMLHttpRequest.prototype.send=function(){this.addEventListener('load',function(){try{var t=this.responseText;if(t&&t.length<1600000)OddsWatchBridge.onPayload(String(this.__owu||''),t);}catch(e){}});return XS.apply(this,arguments)};return 'patched';}catch(e){return String(e)}})()";
        web.evaluateJavascript(js,null);
    }

    public String capture(String id){
        try{
            int w=1080,h=1350;
            web.measure(android.view.View.MeasureSpec.makeMeasureSpec(w,android.view.View.MeasureSpec.EXACTLY),android.view.View.MeasureSpec.makeMeasureSpec(h,android.view.View.MeasureSpec.EXACTLY));
            web.layout(0,0,w,h);
            Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);web.draw(c);
            File f=new File(web.getContext().getFilesDir(),"signal_"+id+".jpg");
            try(FileOutputStream os=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.JPEG,82,os);}b.recycle();return f.getAbsolutePath();
        }catch(Exception e){if(listener!=null)listener.onError("Captura: "+e.getMessage());return "";}
    }

    public void destroy(){web.destroy();}
    private String quote(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}

    public class Bridge{
        @JavascriptInterface public void onSnapshot(String url,String title,String text,String links){main.post(()->{if(listener!=null)listener.onText(url,title,text,links);});}
        @JavascriptInterface public void onDom(String url,String json){main.post(()->{if(listener!=null)listener.onDom(url,json);});}
        @JavascriptInterface public void onPayload(String url,String payload){main.post(()->{if(listener!=null)listener.onPayload(url,payload);});}
    }
}
