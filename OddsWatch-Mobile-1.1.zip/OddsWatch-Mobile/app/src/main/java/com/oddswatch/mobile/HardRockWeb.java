package com.oddswatch.mobile;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.webkit.*;
import java.io.*;

public class HardRockWeb {
    public interface Listener { void onText(String url,String title,String text,String linksJson); void onPayload(String url,String payload); void onPage(String url); void onError(String error); }
    private final WebView web;
    private final Listener listener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private boolean patched=false;

    @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"})
    public HardRockWeb(Context c, Listener l){
        listener=l; web=new WebView(c);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true); s.setMediaPlaybackRequiresUserGesture(true); s.setUserAgentString(s.getUserAgentString()+" OddsWatch/4.0");
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.addJavascriptInterface(new Bridge(),"OddsWatchBridge");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v,String url){ patched=false; injectNetworkHooks(); if(listener!=null) listener.onPage(url); main.postDelayed(()->scanNow(),800); }
            @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError err){ if(req.isForMainFrame()&&listener!=null) listener.onError("WebView: "+err.getDescription()); }
        });
    }

    public WebView view(){ return web; }
    public void loadHome(){ web.loadUrl("https://www.hardrock.bet/sportsbook"); }
    public void load(String url){ if(url!=null&&!url.isEmpty()) web.loadUrl(url); }
    public String url(){ return web.getUrl()==null?"":web.getUrl(); }

    public void scanNow(){
        injectNetworkHooks();
        String js="(function(){try{var t=(document.body&&document.body.innerText)||'';var a=[];var es=document.querySelectorAll('a[href]');for(var i=0;i<es.length&&i<1200;i++){var z=es[i],tx=(z.innerText||z.textContent||'').trim();if(tx)a.push({t:tx.substring(0,160),h:z.href});}OddsWatchBridge.onSnapshot(location.href,document.title,t,JSON.stringify(a));return 'ok';}catch(e){return String(e)}})();";
        web.evaluateJavascript(js,null);
    }

    public void clickSport(String sport){
        String n=quote(sport.toLowerCase());
        String js="(function(){var wanted="+n+";var al=[wanted];if(wanted==='table tennis')al=['table tennis','ping pong','tenis de mesa'];if(wanted==='esports')al=['esports','e-sports','esports betting'];var es=[].slice.call(document.querySelectorAll('a,button,[role=tab],[role=link]'));for(var j=0;j<al.length;j++){for(var i=0;i<es.length;i++){var t=(es[i].innerText||es[i].textContent||'').trim().toLowerCase();if(t===al[j]||t.indexOf(al[j])===0){es[i].click();return 'clicked '+t;}}}return 'not-found '+wanted;})()";
        web.evaluateJavascript(js,null);
    }

    public void gentleScroll(){
        web.evaluateJavascript("(function(){try{var h=document.documentElement.scrollHeight||document.body.scrollHeight;var y=window.scrollY||0;var st=Math.max(450,Math.floor(window.innerHeight*.7));if(y+window.innerHeight<h-80)window.scrollBy(0,st);else window.scrollTo(0,0);}catch(e){}})()",null);
    }

    private void injectNetworkHooks(){
        if(patched) return; patched=true;
        String js="(function(){if(window.__ow4)return;window.__ow4=true;try{var of=window.fetch;if(of){window.fetch=async function(){var r=await of.apply(this,arguments);try{var c=r.clone();var t=await c.text();if(t&&t.length<500000)OddsWatchBridge.onPayload(String(arguments[0]),t);}catch(e){}return r;};}var XO=XMLHttpRequest.prototype.open,XS=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__owu=u;return XO.apply(this,arguments)};XMLHttpRequest.prototype.send=function(){this.addEventListener('load',function(){try{var t=this.responseText;if(t&&t.length<500000)OddsWatchBridge.onPayload(String(this.__owu||''),t);}catch(e){}});return XS.apply(this,arguments)};}catch(e){}})()";
        web.evaluateJavascript(js,null);
    }

    public String capture(String id){
        try{
            int w=1080, h=1350;
            web.measure(android.view.View.MeasureSpec.makeMeasureSpec(w,android.view.View.MeasureSpec.EXACTLY),android.view.View.MeasureSpec.makeMeasureSpec(h,android.view.View.MeasureSpec.EXACTLY));
            web.layout(0,0,w,h);
            Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(b); web.draw(c);
            File f=new File(web.getContext().getFilesDir(),"signal_"+id+".jpg");
            try(FileOutputStream os=new FileOutputStream(f)){ b.compress(Bitmap.CompressFormat.JPEG,82,os); }
            b.recycle(); return f.getAbsolutePath();
        }catch(Exception e){ if(listener!=null) listener.onError("Captura: "+e.getMessage()); return ""; }
    }

    public void destroy(){ web.destroy(); }
    private String quote(String s){ return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'"; }

    public class Bridge {
        @JavascriptInterface public void onSnapshot(String url,String title,String text,String links){ main.post(()->{ if(listener!=null) listener.onText(url,title,text,links); }); }
        @JavascriptInterface public void onPayload(String url,String payload){ main.post(()->{ if(listener!=null) listener.onPayload(url,payload); }); }
    }
}
