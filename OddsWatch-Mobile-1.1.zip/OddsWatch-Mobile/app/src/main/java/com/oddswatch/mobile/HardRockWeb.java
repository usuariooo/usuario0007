package com.oddswatch.mobile;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.webkit.*;
import java.io.*;

/**
 * Local reader for the Hard Rock page loaded on the device.
 * V5 deliberately DOES NOT treat arbitrary page/article text as bets.
 * Only interactive controls containing an American price are emitted as DOM bet candidates.
 */
public class HardRockWeb {
    public interface Listener {
        void onText(String url,String title,String text,String linksJson);
        void onDom(String url,String json);
        void onPayload(String url,String payload);
        void onPage(String url);
        void onError(String error);
    }
    private final WebView web;
    private final Listener listener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private boolean patched=false;

    @SuppressLint({"SetJavaScriptEnabled","JavascriptInterface"})
    public HardRockWeb(Context c, Listener l){
        listener=l; web=new WebView(c);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true); s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString()+" OddsWatch/5.0");
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.addJavascriptInterface(new Bridge(),"OddsWatchBridge");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap fav){ patched=false; injectNetworkHooks(); }
            @Override public void onPageFinished(WebView v,String url){ injectNetworkHooks(); if(listener!=null) listener.onPage(url); main.postDelayed(()->scanNow(),700); }
            @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError err){ if(req.isForMainFrame()&&listener!=null) listener.onError("WebView: "+err.getDescription()); }
        });
    }

    public WebView view(){ return web; }
    public void loadHome(){ web.loadUrl("https://www.hardrock.bet/sportsbook"); }
    public void load(String url){ if(url!=null&&!url.isEmpty()) web.loadUrl(url); }
    public String url(){ return web.getUrl()==null?"":web.getUrl(); }

    public void scanNow(){
        injectNetworkHooks();
        // 1) Snapshot text is kept ONLY for scoreboard/result resolution + diagnostics.
        String snapshot="(function(){try{var t=(document.body&&document.body.innerText)||'';var a=[];var es=document.querySelectorAll('a[href]');for(var i=0;i<es.length&&i<1200;i++){var z=es[i],tx=(z.innerText||z.textContent||'').trim(),h=z.href||'';if(tx&&h)a.push({t:tx.substring(0,140),h:h});}OddsWatchBridge.onSnapshot(location.href,document.title,t,JSON.stringify(a));return 'ok';}catch(e){return String(e)}})();";
        web.evaluateJavascript(snapshot,null);

        // 2) Strict DOM extractor. An article paragraph containing “+125” is NOT enough.
        //    The price must live inside a button/link/role=button and outside article/help/footer/nav content.
        String dom="(function(){try{"+
                "var R=/[+-](?:100|[1-9][0-9]{2,3})(?![0-9])/g;"+
                "function C(x){return (x||'').replace(/\\s+/g,' ').trim();}"+
                "function bad(el){for(var p=el,n=0;p&&n<9;p=p.parentElement,n++){var tg=(p.tagName||'').toLowerCase(),cl=C((p.className||'')+' '+(p.id||'')).toLowerCase();if(tg==='article'||tg==='footer'||tg==='nav'||cl.indexOf('article')>=0||cl.indexOf('blog')>=0||cl.indexOf('editorial')>=0||cl.indexOf('faq')>=0||cl.indexOf('how-to')>=0||cl.indexOf('marketing')>=0)return true;}return false;}"+
                "function attrs(el){var o={};for(var p=el,n=0;p&&n<6;p=p.parentElement,n++){if(!p.attributes)continue;for(var i=0;i<p.attributes.length;i++){var a=p.attributes[i],k=a.name.toLowerCase();if(k.indexOf('data-')===0||k==='id'||k==='href'||k.indexOf('selection')>=0||k.indexOf('outcome')>=0||k.indexOf('event')>=0){if(a.value&&a.value.length<220)o[k]=a.value;}}}return o;}"+
                "function href(el){for(var p=el,n=0;p&&n<7;p=p.parentElement,n++){if(p.href)return p.href;}var c=el.closest&&el.closest('a[href]');return c?c.href:'';}"+
                "function box(el){var p=el,b=el;for(var n=0;p&&n<8;p=p.parentElement,n++){var tx=(p.innerText||p.textContent||'').trim(),ls=tx.split(/\\n+/).filter(Boolean);var odds=(tx.match(R)||[]).length;if(tx.length>5&&tx.length<1400&&ls.length>=2&&ls.length<=45&&odds>=1)b=p;if(odds>=2&&ls.length>=4)break;}return b;}"+
                "var out=[], seen={};var es=document.querySelectorAll('button,[role=button],a[href]');"+
                "for(var i=0;i<es.length&&out.length<600;i++){var e=es[i],bt=(e.innerText||e.textContent||'').trim();R.lastIndex=0;var mm=R.exec(bt);if(!mm||bad(e))continue;var b=box(e),ct=(b.innerText||b.textContent||'').trim();if(!ct||ct.length>1400)continue;var key=C(bt)+'|'+C(ct).substring(0,280);if(seen[key])continue;seen[key]=1;var pt=e.parentElement?((e.parentElement.innerText||e.parentElement.textContent||'').trim()):'';var gt=e.parentElement&&e.parentElement.parentElement?((e.parentElement.parentElement.innerText||e.parentElement.parentElement.textContent||'').trim()):'';out.push({button:bt,parent:pt,grand:gt,context:ct,href:href(e),attrs:attrs(e),htmlTag:(e.tagName||''),cls:C(e.className||'')});}"+
                "OddsWatchBridge.onDom(location.href,JSON.stringify(out));return out.length;}catch(e){OddsWatchBridge.onDom(location.href,JSON.stringify({error:String(e)}));return -1;}})();";
        web.evaluateJavascript(dom,null);
    }

    /** Prefer actual sportsbook UI controls. Never click SEO/article links such as /sportsbook/table-tennis/. */
    public void clickSport(String sport){
        String n=quote(sport.toLowerCase());
        String js="(function(){var wanted="+n+";var al=[wanted];if(wanted==='table tennis')al=['table tennis','ping pong','tenis de mesa'];if(wanted==='esports')al=['esports','e-sports','esports betting'];var es=[].slice.call(document.querySelectorAll('button,[role=tab],[role=button],a[href]'));function editorial(h){try{var u=new URL(h,location.href),p=u.pathname.toLowerCase();return /^\\/sportsbook\\/(table-tennis|basketball|baseball|soccer|football|tennis|hockey|volleyball|boxing|golf|mma|ufc|cricket|rugby|darts)\\/?$/.test(p);}catch(e){return false;}}for(var j=0;j<al.length;j++){for(var i=0;i<es.length;i++){var t=(es[i].innerText||es[i].textContent||'').trim().toLowerCase();var h=es[i].href||'';if((t===al[j]||t.indexOf(al[j])===0)&&!editorial(h)){es[i].click();return 'clicked '+t;}}}return 'not-found '+wanted;})()";
        web.evaluateJavascript(js,null);
    }

    public void clickLive(){
        web.evaluateJavascript("(function(){var es=[].slice.call(document.querySelectorAll('button,[role=tab],[role=button],a[href]'));for(var i=0;i<es.length;i++){var t=(es[i].innerText||es[i].textContent||'').trim().toLowerCase();if(t==='live'||t==='en vivo'||t.indexOf('live ')===0){es[i].click();return 'live';}}return 'no-live';})()",null);
    }

    public void gentleScroll(){
        web.evaluateJavascript("(function(){try{var h=document.documentElement.scrollHeight||document.body.scrollHeight;var y=window.scrollY||0;var st=Math.max(500,Math.floor(window.innerHeight*.8));if(y+window.innerHeight<h-100)window.scrollBy(0,st);else window.scrollTo(0,0);}catch(e){}})()",null);
    }

    private void injectNetworkHooks(){
        if(patched) return; patched=true;
        String js="(function(){if(window.__ow5)return;window.__ow5=true;try{var of=window.fetch;if(of){window.fetch=async function(){var r=await of.apply(this,arguments);try{var c=r.clone();var t=await c.text();if(t&&t.length<900000)OddsWatchBridge.onPayload(String(arguments[0]),t);}catch(e){}return r;};}var XO=XMLHttpRequest.prototype.open,XS=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__owu=u;return XO.apply(this,arguments)};XMLHttpRequest.prototype.send=function(){this.addEventListener('load',function(){try{var t=this.responseText;if(t&&t.length<900000)OddsWatchBridge.onPayload(String(this.__owu||''),t);}catch(e){}});return XS.apply(this,arguments)};}catch(e){}})()";
        web.evaluateJavascript(js,null);
    }

    public String capture(String id){
        try{
            int w=1080, h=1350;
            web.measure(android.view.View.MeasureSpec.makeMeasureSpec(w,android.view.View.MeasureSpec.EXACTLY),android.view.View.MeasureSpec.makeMeasureSpec(h,android.view.View.MeasureSpec.EXACTLY));
            web.layout(0,0,w,h);
            Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(b); web.draw(c);
            File f=new File(web.getContext().getFilesDir(),"signal_"+id+".jpg");
            try(FileOutputStream os=new FileOutputStream(f)){ b.compress(Bitmap.CompressFormat.JPEG,82,os); }
            b.recycle(); return f.getAbsolutePath();
        }catch(Exception e){ if(listener!=null) listener.onError("Captura: "+e.getMessage()); return ""; }
    }

    public void destroy(){ web.destroy(); }
    private String quote(String s){ return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'"; }

    public class Bridge {
        @JavascriptInterface public void onSnapshot(String url,String title,String text,String links){ main.post(()->{ if(listener!=null) listener.onText(url,title,text,links); }); }
        @JavascriptInterface public void onDom(String url,String json){ main.post(()->{ if(listener!=null) listener.onDom(url,json); }); }
        @JavascriptInterface public void onPayload(String url,String payload){ main.post(()->{ if(listener!=null) listener.onPayload(url,payload); }); }
    }
}
