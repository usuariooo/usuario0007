package com.oddswatch.mobile;

import java.util.*;

public final class AppState {
    public static volatile List<MarketAlert> alerts=new ArrayList<>();
    public static volatile String error="";
    public static volatile int quotaRemaining=-1, quotaUsed=-1, lastRequestCost=-1, scannedSports=0, gamesSeen=0, hardRockGames=0;
    public static volatile long lastScanAt=0;

    public static synchronized void set(ScanResult r){
        alerts=new ArrayList<>(r.alerts);
        quotaRemaining=r.quotaRemaining; quotaUsed=r.quotaUsed; lastRequestCost=r.lastRequestCost;
        scannedSports=r.scannedSports; gamesSeen=r.gamesSeen; hardRockGames=r.hardRockGames;
        lastScanAt=r.completedAt; error="";
    }
    private AppState(){}
}
