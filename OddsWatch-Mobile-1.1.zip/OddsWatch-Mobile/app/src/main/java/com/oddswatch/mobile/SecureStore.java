package com.oddswatch.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Small Android-Keystore-backed store for API keys/tokens. Secrets never ship in source code. */
public final class SecureStore {
    private static final String KS="AndroidKeyStore";
    private static final String ALIAS="OddsWatchFinalSecretsV2";
    private static final String PREF="oddswatch_secure_v2";

    private static SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance(KS); store.load(null);
        if(!store.containsAlias(ALIAS)){
            KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,KS);
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true).build());
            kg.generateKey();
        }
        return ((KeyStore.SecretKeyEntry)store.getEntry(ALIAS,null)).getSecretKey();
    }

    public static void put(Context c,String name,String value){
        try{
            if(value==null||value.isEmpty()){prefs(c).edit().remove(name).apply();return;}
            Cipher cp=Cipher.getInstance("AES/GCM/NoPadding"); cp.init(Cipher.ENCRYPT_MODE,key());
            byte[] enc=cp.doFinal(value.getBytes(StandardCharsets.UTF_8));
            String packed=Base64.encodeToString(cp.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(enc,Base64.NO_WRAP);
            prefs(c).edit().putString(name,packed).apply();
        }catch(Exception e){throw new IllegalStateException("Could not save secure setting: "+e.getMessage(),e);}
    }

    public static String get(Context c,String name){
        String packed=prefs(c).getString(name,""); if(packed==null||packed.isEmpty())return "";
        try{
            String[] p=packed.split(":",2); if(p.length!=2)return "";
            byte[] iv=Base64.decode(p[0],Base64.NO_WRAP), enc=Base64.decode(p[1],Base64.NO_WRAP);
            Cipher cp=Cipher.getInstance("AES/GCM/NoPadding"); cp.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
            return new String(cp.doFinal(enc),StandardCharsets.UTF_8);
        }catch(Exception e){return "";}
    }

    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    private SecureStore(){}
}
