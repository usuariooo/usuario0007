package com.oddswatch.mobile;

import java.util.HashMap;
import java.util.Map;

public class Models {
    public static double americanImplied(int odds){
        if(odds>0) return 100.0/(odds+100.0);
        if(odds<0) return (-odds)/((-odds)+100.0);
        return 0.5;
    }

    public static double pingPongPointStrength(int a,int b){
        double p=(a+4.0)/(a+b+8.0);
        return Math.max(.30,Math.min(.70,p));
    }

    public static double pingPongSetWin(int a,int b){
        return pingPongSetWinWithP(a,b,pingPongPointStrength(a,b));
    }

    public static double pingPongSetWinWithP(int a,int b,double p){
        return setWinDP(a,b,p,0,new HashMap<>());
    }

    private static double setWinDP(int a,int b,double p,int depth,Map<String,Double> memo){
        if(depth>90) return .5;
        if((a>=11||b>=11)&&Math.abs(a-b)>=2) return a>b?1:0;
        if(a>=22&&b>=22){ double q=p*p,r=(1-p)*(1-p); return q+r<1e-9?.5:q/(q+r); }
        String k=a+":"+b; Double h=memo.get(k); if(h!=null)return h;
        double v=p*setWinDP(a+1,b,p,depth+1,memo)+(1-p)*setWinDP(a,b+1,p,depth+1,memo);
        memo.put(k,v); return v;
    }

    public static double pingPongTotalOver(int a,int b,double line){
        double p=pingPongPointStrength(a,b);
        return totalDP(a,b,p,line,0,new HashMap<>());
    }
    private static double totalDP(int a,int b,double p,double line,int depth,Map<String,Double> memo){
        if(depth>90) return (a+b)>line?1:0;
        if((a>=11||b>=11)&&Math.abs(a-b)>=2) return (a+b)>line?1:0;
        String k=a+":"+b+":"+line; Double h=memo.get(k);if(h!=null)return h;
        double v=p*totalDP(a+1,b,p,line,depth+1,memo)+(1-p)*totalDP(a,b+1,p,line,depth+1,memo);
        memo.put(k,v); return v;
    }

    /** handicap is applied to competitor A final points, e.g. -2.5 */
    public static double pingPongHandicapCover(int a,int b,double handicap){
        double p=pingPongPointStrength(a,b);
        return handicapDP(a,b,p,handicap,0,new HashMap<>());
    }
    private static double handicapDP(int a,int b,double p,double hcap,int depth,Map<String,Double> memo){
        if(depth>90) return (a+hcap)>b?1:0;
        if((a>=11||b>=11)&&Math.abs(a-b)>=2) return (a+hcap)>b?1:0;
        String k=a+":"+b+":"+hcap; Double h=memo.get(k);if(h!=null)return h;
        double v=p*handicapDP(a+1,b,p,hcap,depth+1,memo)+(1-p)*handicapDP(a,b+1,p,hcap,depth+1,memo);
        memo.put(k,v); return v;
    }

    public static double genericScoreProbability(int a,int b){
        double d=a-b;
        return 1.0/(1.0+Math.exp(-d/2.75));
    }

    public static int scoreFromEdge(double edge, boolean live, boolean ping, double movement){
        double v=48 + edge*360 + Math.min(10,Math.abs(movement)*160);
        if(live) v+=5;
        if(ping) v+=7;
        return (int)Math.max(1,Math.min(99,Math.round(v)));
    }
}
