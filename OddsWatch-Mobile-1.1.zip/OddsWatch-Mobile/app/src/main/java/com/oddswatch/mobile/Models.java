package com.oddswatch.mobile;

import java.util.HashMap;
import java.util.Map;

public class Models {
    public static double americanImplied(int odds){
        if(odds>0) return 100.0/(odds+100.0);
        if(odds<0) return (-odds)/((-odds)+100.0);
        return 0.5;
    }

    // Free, local table-tennis estimator. It is intentionally conservative.
    public static double pingPongSetWin(int a,int b){
        // Bayesian shrinkage for per-point strength; score alone is weak early in a set.
        double p=(a+4.0)/(a+b+8.0);
        p=Math.max(.30,Math.min(.70,p));
        return setDP(a,b,p,0,new HashMap<>());
    }

    private static double setDP(int a,int b,double p,int depth,Map<String,Double> memo){
        if(depth>80) return .5;
        if((a>=11||b>=11)&&Math.abs(a-b)>=2) return a>b?1:0;
        if(a>=20&&b>=20){
            double q=p*p, r=(1-p)*(1-p);
            if(q+r<1e-9) return .5;
            return q/(q+r);
        }
        String k=a+":"+b; Double hit=memo.get(k); if(hit!=null) return hit;
        double v=p*setDP(a+1,b,p,depth+1,memo)+(1-p)*setDP(a,b+1,p,depth+1,memo);
        memo.put(k,v); return v;
    }

    public static double genericScoreProbability(int a,int b){
        double d=a-b;
        return 1.0/(1.0+Math.exp(-d/2.75));
    }

    public static int scoreFromEdge(double edge, boolean live, boolean ping, double movement){
        double v=50 + edge*360 + Math.min(12,Math.abs(movement)*180);
        if(live) v+=5;
        if(ping) v+=7;
        return (int)Math.max(1,Math.min(99,Math.round(v)));
    }
}
