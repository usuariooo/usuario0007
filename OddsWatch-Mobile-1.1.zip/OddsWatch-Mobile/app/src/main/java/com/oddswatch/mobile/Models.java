package com.oddswatch.mobile;
public class Models {
    public static double americanImplied(int odds){
        if(odds>0)return 100.0/(odds+100.0);
        if(odds<0)return (-odds)/((-odds)+100.0);
        return 0;
    }
    public static double profitForAmerican(int odds){
        if(odds>0)return odds/100.0;
        if(odds<0)return 100.0/Math.abs(odds);
        return 0;
    }
}
