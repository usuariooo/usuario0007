package com.oddswatch.mobile;

import java.util.Locale;

public class Models {
    public static double americanImplied(int odds){
        if(odds>0)return 100.0/(odds+100.0);
        if(odds<0)return (-odds)/((-odds)+100.0);
        return 0;
    }
    public static double profitForAmerican(int odds){
        if(odds>0)return odds/100.0;
        if(odds<0)return 100.0/Math.abs(odds);
        return 0;
    }
    public static double impliedFromOdds(String odds){
        if(odds==null)return 0;
        String x=odds.trim().replace(",", ".");
        try{
            if(x.startsWith("+")||x.startsWith("-"))return americanImplied(Integer.parseInt(x));
            double d=Double.parseDouble(x);
            return d>1.0?1.0/d:0;
        }catch(Exception e){return 0;}
    }
    public static double profitForStake(String odds,double stake){
        if(stake<=0)return 0;
        if(odds==null)return 0;
        String x=odds.trim().replace(",", ".");
        try{
            if(x.startsWith("+")||x.startsWith("-"))return stake*profitForAmerican(Integer.parseInt(x));
            double d=Double.parseDouble(x);
            return d>1.0?stake*(d-1.0):0;
        }catch(Exception e){return 0;}
    }
    public static String money(double x){return String.format(Locale.US,"$%.2f",x);}
}
