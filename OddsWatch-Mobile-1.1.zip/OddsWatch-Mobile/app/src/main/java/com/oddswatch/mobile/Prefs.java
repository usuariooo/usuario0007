package com.oddswatch.mobile;
import android.content.*;
public final class Prefs {
    private static final String P="oddswatch_free_v3";
    public static SharedPreferences p(Context c){return c.getSharedPreferences(P,Context.MODE_PRIVATE);}
    public static boolean running(Context c){return p(c).getBoolean("running",false);}
    public static int interval(Context c){return Math.max(5,p(c).getInt("interval",7));}
    public static int threshold(Context c){return p(c).getInt("threshold",68);}
    public static boolean autoSweep(Context c){return p(c).getBoolean("auto_sweep",true);}
    public static boolean allSports(Context c){return p(c).getBoolean("all_sports",true);}
    public static String url(Context c){return p(c).getString("url","https://www.hardrock.bet/sportsbook/");}
    private Prefs(){}
}
