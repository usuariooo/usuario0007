package com.oddswatch.mobile;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String P="oddswatch_final_prefs";

    // Non-secret defaults. Auth Token and odds API key are intentionally NOT embedded.
    public static final String DEFAULT_WA_TO="";
    public static final String DEFAULT_TW_FROM="";
    public static final String DEFAULT_TW_SID="";
    public static final String DEFAULT_CONTENT_SID="";

    public static SharedPreferences p(Context c){return c.getSharedPreferences(P,Context.MODE_PRIVATE);}
    public static boolean running(Context c){return p(c).getBoolean("running",false);}
    public static int interval(Context c){return p(c).getInt("interval_sec",180);}
    public static int threshold(Context c){return p(c).getInt("threshold",72);}
    public static double minEdge(Context c){return Double.longBitsToDouble(p(c).getLong("min_edge",Double.doubleToLongBits(2.0)));}
    public static int quotaReserve(Context c){return p(c).getInt("quota_reserve",50);}
    public static boolean allSports(Context c){return p(c).getBoolean("all_sports",false);}
    public static boolean includeLive(Context c){return p(c).getBoolean("include_live",true);}
    public static boolean includePre(Context c){return p(c).getBoolean("include_pre",true);}
    public static boolean whatsapp(Context c){return p(c).getBoolean("whatsapp",false);}
    public static String waTo(Context c){return p(c).getString("wa_to",DEFAULT_WA_TO);}
    public static String twFrom(Context c){return p(c).getString("tw_from",DEFAULT_TW_FROM);}
    public static String twSid(Context c){return p(c).getString("tw_sid",DEFAULT_TW_SID);}
    public static String twContentSid(Context c){return p(c).getString("tw_content_sid",DEFAULT_CONTENT_SID);}
    public static String apiKey(Context c){return SecureStore.get(c,"odds_api_key");}
    public static String twToken(Context c){return SecureStore.get(c,"twilio_auth_token");}
    public static void setApiKey(Context c,String v){SecureStore.put(c,"odds_api_key",v==null?"":v.trim());}
    public static void setTwToken(Context c,String v){SecureStore.put(c,"twilio_auth_token",v==null?"":v.trim());}
    public static void setMinEdge(Context c,double v){p(c).edit().putLong("min_edge",Double.doubleToLongBits(v)).apply();}
    private Prefs(){}
}
