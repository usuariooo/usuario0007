package com.oddswatch.mobile;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;

public class CaptureService extends Service implements VisionParser.Listener {
    public static final String ACTION_UPDATE="com.oddswatch.mobile.UPDATE";
    private static final int NOTIF=1909;
    private Store store;private MediaProjection projection;private VirtualDisplay display;private ImageReader reader;private TextRecognizer recognizer;private VisionParser parser;
    private boolean processing=false;private long lastFrame=0;private Bitmap activeBitmap;private PowerManager.WakeLock wakeLock;
    private int screenW,screenH,density;

    @Override public void onCreate(){super.onCreate();store=new Store(this);parser=new VisionParser(store,this);recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);createChannels();}

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        startFg("Preparando lector visual…");
        if(intent==null)return START_NOT_STICKY;
        int code=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED);
        Intent data;
        if(Build.VERSION.SDK_INT>=33)data=intent.getParcelableExtra("resultData",Intent.class);else data=intent.getParcelableExtra("resultData");
        if(code!=Activity.RESULT_OK||data==null){store.setLastError("Falta autorizar la captura de pantalla.");stopSelf();return START_NOT_STICKY;}
        try{startProjection(code,data);store.setScannerOn(true);store.setCaptureReady(true);store.setLastError("");if(store.dedicated())acquireScreenWakeLock();broadcast();}catch(Exception e){store.setLastError("Captura: "+e.getMessage());stopSelf();}
        return START_STICKY;
    }

    private void startProjection(int code,Intent data){
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=m.getMediaProjection(code,data);
        projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){store.setCaptureReady(false);store.setScannerOn(false);broadcast();stopSelf();}},new Handler(Looper.getMainLooper()));
        DisplayMetrics dm=getResources().getDisplayMetrics();screenW=dm.widthPixels;screenH=dm.heightPixels;density=dm.densityDpi;
        reader=ImageReader.newInstance(screenW,screenH,PixelFormat.RGBA_8888,2);
        display=projection.createVirtualDisplay("OddsWatchVision",screenW,screenH,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null);
        reader.setOnImageAvailableListener(this::onImage,new Handler(Looper.getMainLooper()));
        if(store.dedicated())HardRockAccessibilityService.launchHardRock(this);
        updateNotification("Radar activo • esperando Hard Rock");
    }

    private void onImage(ImageReader r){
        Image image=null;try{image=r.acquireLatestImage();if(image==null)return;long now=System.currentTimeMillis();if(processing||now-lastFrame<850){image.close();return;}lastFrame=now;
            String fg=store.foregroundPackage();if(fg!=null&&!fg.isEmpty()&&!"com.hardrockdigital.client".equals(fg)){image.close();updateNotification(store.dedicated()?"Modo 24/7 • recuperando Hard Rock":"Pausado • vuelve a Hard Rock");return;}
            Bitmap full=imageToBitmap(image);image.close();image=null;if(full==null)return;process(full);
        }catch(Exception e){if(image!=null)try{image.close();}catch(Exception ignored){}store.setLastError("Frame: "+e.getMessage());broadcast();}
    }

    private Bitmap imageToBitmap(Image image){
        Image.Plane p=image.getPlanes()[0];ByteBuffer buffer=p.getBuffer();int pixel=p.getPixelStride(),row=p.getRowStride(),pad=row-pixel*screenW;
        Bitmap wide=Bitmap.createBitmap(screenW+pad/pixel,screenH,Bitmap.Config.ARGB_8888);wide.copyPixelsFromBuffer(buffer);
        Bitmap crop=Bitmap.createBitmap(wide,0,0,screenW,screenH);if(crop!=wide)wide.recycle();return crop;
    }

    private void process(Bitmap full){
        processing=true;activeBitmap=full;
        int targetW=Math.min(800,full.getWidth());int targetH=Math.max(1,Math.round(full.getHeight()*(targetW/(float)full.getWidth())));
        Bitmap small=Bitmap.createScaledBitmap(full,targetW,targetH,true);float sx=full.getWidth()/(float)targetW,sy=full.getHeight()/(float)targetH;
        recognizer.process(InputImage.fromBitmap(small,0)).addOnSuccessListener(text->{
            try{
                ArrayList<OcrLine> lines=new ArrayList<>();
                for(Text.TextBlock b:text.getTextBlocks())for(Text.Line l:b.getLines()){Rect q=l.getBoundingBox();if(q==null)continue;Rect scaled=new Rect(Math.round(q.left*sx),Math.round(q.top*sy),Math.round(q.right*sx),Math.round(q.bottom*sy));lines.add(new OcrLine(l.getText(),scaled));}
                parser.ingest(lines,full.getWidth(),full.getHeight());
                store.setLastError(lines.isEmpty()?"OCR activo, pero todavía no leyó texto visible.":"");
                updateNotification("Leyendo Hard Rock • "+store.marketsSeen()+" mercados completos");broadcast();
            }catch(Exception e){store.setLastError("OCR parse: "+e.getMessage());}
        }).addOnFailureListener(e->{store.setLastError("OCR: "+e.getMessage());broadcast();}).addOnCompleteListener(x->{processing=false;try{small.recycle();}catch(Exception ignored){}try{full.recycle();}catch(Exception ignored){}activeBitmap=null;});
    }

    @Override public void onSignal(Signal s){
        if(activeBitmap!=null){String path=saveSignalImage(s.id,activeBitmap);if(path!=null&&!path.isEmpty()){s.screenshot=path;store.upsertSignal(s);}}
        notifySignal(s);if(store.remoteEnabled())NtfyClient.send(store.topic(),"OddsWatch • "+s.sport,"PARTIDO: "+s.event+"\nMERCADO: "+s.market+"\nTOCA: "+s.selection+"\nCUOTA: "+s.odds+"\nMovimiento: +"+String.format(Locale.US,"%.1f",s.movement*100)+" pp");
        broadcast();
    }
    @Override public void onObservedChanged(){broadcast();}
    @Override public void onTargetFound(int x,int y){HardRockAccessibilityService.tapSafeEvent(x,y);}

    private String saveSignalImage(String id,Bitmap b){try{File dir=new File(getFilesDir(),"signals");if(!dir.exists())dir.mkdirs();File f=new File(dir,id+".jpg");try(FileOutputStream o=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.JPEG,82,o);}return f.getAbsolutePath();}catch(Exception ignored){return "";}}

    private void notifySignal(Signal s){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);Intent i=new Intent(this,MainActivity.class).putExtra("tab","detected");PendingIntent pi=PendingIntent.getActivity(this,s.id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(this,"signals").setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat).setContentTitle("🎯 "+s.event).setContentText(s.market+" → "+s.selection+" @ "+s.odds).setStyle(new Notification.BigTextStyle().bigText("PARTIDO: "+s.event+"\nMERCADO: "+s.market+"\nTOCA: "+s.selection+"\nCUOTA: "+s.odds+"\n"+s.reason)).setContentIntent(pi).setAutoCancel(true).build();nm.notify((int)(System.currentTimeMillis()%100000),n);}

    private void createChannels(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("scanner","Radar OddsWatch",NotificationManager.IMPORTANCE_LOW));nm.createNotificationChannel(new NotificationChannel("signals","Señales OddsWatch",NotificationManager.IMPORTANCE_HIGH));}}
    private Notification foregroundNotification(String text){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,1,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,"scanner").setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat).setContentTitle("OddsWatch").setContentText(text).setOngoing(true).setContentIntent(pi).build();}
    private void startFg(String t){Notification n=foregroundNotification(t);if(Build.VERSION.SDK_INT>=29)startForeground(NOTIF,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(NOTIF,n);}
    private void updateNotification(String t){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF,foregroundNotification(t));}
    private void acquireScreenWakeLock(){try{PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);wakeLock=pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK|PowerManager.ON_AFTER_RELEASE,"OddsWatch:DedicatedScreen");wakeLock.acquire();}catch(Exception ignored){}}
    private void broadcast(){sendBroadcast(new Intent(ACTION_UPDATE).setPackage(getPackageName()));}

    @Override public void onDestroy(){store.setCaptureReady(false);store.setScannerOn(false);try{if(reader!=null)reader.close();}catch(Exception ignored){}try{if(display!=null)display.release();}catch(Exception ignored){}try{if(projection!=null)projection.stop();}catch(Exception ignored){}try{recognizer.close();}catch(Exception ignored){}try{if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();}catch(Exception ignored){}broadcast();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
