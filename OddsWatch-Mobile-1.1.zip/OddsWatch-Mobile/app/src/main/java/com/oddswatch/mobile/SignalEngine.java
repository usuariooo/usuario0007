package com.oddswatch.mobile;

import android.content.Context;
import org.json.*;
import java.util.*;
import java.util.regex.*;

public class SignalEngine {
    public interface Listener { void onNewSignal(Signal s); void onDataChanged(); }
    private final Store store;
    private final Listener listener;
    private final Map<String,Double> previousProbability=new HashMap<>();
    private final Map<String,Integer> seenCount=new HashMap<>();
    private final Map<String,String> links=new LinkedHashMap<>();
    private final Map<String,Signal> recent=new LinkedHashMap<>();

    private static final Pattern AMERICAN=Pattern.compile("(?<!\\d)([+-](?:100|[1-9]\\d{2,3}))(?!\\d)");
    private static final Pattern SCORE=Pattern.compile("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)");
    private static final Pattern LINE=Pattern.compile("(?i)\\b(?:over|under|más de|menos de|o/u)\\s*(\\d+(?:\\.5)?)");

    public SignalEngine(Context c, Listener l){ store=new Store(c); listener=l; for(Signal s:store.loadSignals()) recent.put(s.id,s); }

    public synchronized void setLinks(String json){
        links.clear();
        try{
            JSONArray a=new JSONArray(json);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.optJSONObject(i); if(o==null) continue;
                String t=clean(o.optString("t")), h=o.optString("h");
                if(!t.isEmpty() && !h.isEmpty()) links.put(t,h);
            }
        }catch(Exception ignored){}
    }

    public synchronized int ingestText(String url,String title,String text){
        if(text==null) return 0;
        store.setLastScan(System.currentTimeMillis());
        List<Candidate> cs=parseText(url,title,text);
        evaluate(cs,text);
        tryResolve(text);
        store.setOddsSeen(cs.size());
        return cs.size();
    }

    public synchronized int ingestPayload(String url,String payload){
        if(payload==null||payload.length()<2) return 0;
        store.incPayloads();
        ArrayList<Candidate> out=new ArrayList<>();
        try{
            char c=payload.trim().charAt(0);
            if(c=='{' || c=='['){
                Object root=c=='{'?new JSONObject(payload):new JSONArray(payload);
                walkJson(root,new Ctx(),out,url,0);
            }
        }catch(Exception ignored){}
        if(!out.isEmpty()) evaluate(out,payload);
        return out.size();
    }

    private void evaluate(List<Candidate> list,String raw){
        long now=System.currentTimeMillis();
        HashSet<String> touched=new HashSet<>();
        for(Candidate c:list){
            if(c.odds==0 || c.selection.length()<2) continue;
            String key=key(c);
            if(!touched.add(key)) continue;
            double implied=Models.americanImplied(c.odds);
            Double prev=previousProbability.put(key,implied);
            int n=seenCount.getOrDefault(key,0)+1; seenCount.put(key,n);
            if(prev==null || n<2) continue; // never invent a signal from first snapshot
            double movement=implied-prev;

            ModelResult mr=model(c,raw,implied);
            double modelP=mr.probability;
            double edge=modelP>0?modelP-implied:0;
            boolean ping=isPing(c.sport,c.context);
            boolean live=isLive(c.context);
            int score=Models.scoreFromEdge(Math.max(0,edge),live,ping,movement);

            // Requires real model edge OR a very strong repeatable movement with visible live score context.
            boolean actionable=(modelP>0 && edge>=0.035 && score>=store.minScore());
            if(!actionable) continue;

            String id=Integer.toHexString(key.hashCode());
            Signal s=recent.get(id);
            boolean isNew=s==null;
            if(s==null){ s=new Signal(); s.id=id; s.createdAt=now; }
            s.updatedAt=now; s.sport=spanishSport(c.sport,c.context); s.event=clearEvent(c.event); s.market=spanishMarket(c.market);
            s.selection=c.selection; s.odds=(c.odds>0?"+":"")+c.odds; s.implied=implied; s.modelProbability=modelP;
            s.edge=edge; s.score=score; s.url=findBestUrl(c); s.deepLink=findDeepLink(c); s.status="PENDIENTE";
            s.reason=mr.reason + String.format(Locale.US," Prob. modelo %.1f%% vs cuota %.1f%% (diferencia +%.1f pp).", modelP*100, implied*100, edge*100);
            recent.put(id,s); store.upsert(s);
            if(isNew && listener!=null) listener.onNewSignal(s);
        }
        pruneActive(now);
        if(listener!=null) listener.onDataChanged();
    }

    private void pruneActive(long now){
        Iterator<Map.Entry<String,Signal>> it=recent.entrySet().iterator();
        while(it.hasNext()){
            Signal s=it.next().getValue();
            if("PENDIENTE".equals(s.status) && now-s.updatedAt>6*60*60*1000L) it.remove();
        }
    }

    private ModelResult model(Candidate c,String raw,double implied){
        int[] sc=findBestScore(c.context);
        if(sc==null) sc=findBestScore(raw);
        if(sc==null) return new ModelResult(0,"No había marcador interpretable; sin recomendación matemática.");
        String ev=(c.event+" "+c.context).toLowerCase(Locale.US);
        boolean first=selectionIsFirst(c.selection,c.event,c.context);
        double p;
        if(isPing(c.sport,c.context)){
            p=Models.pingPongSetWin(sc[0],sc[1]);
            if(!first) p=1-p;
            return new ModelResult(p,"Modelo local de tenis de mesa usando marcador visible "+sc[0]+"-"+sc[1]+".");
        }
        p=Models.genericScoreProbability(sc[0],sc[1]);
        if(!first) p=1-p;
        // extra shrinkage for generic sports, because score alone is weak.
        p=.5+(p-.5)*.55;
        return new ModelResult(p,"Modelo experimental basado únicamente en el marcador visible "+sc[0]+"-"+sc[1]+".");
    }

    private boolean selectionIsFirst(String sel,String event,String ctx){
        String e=clean(event).toLowerCase(Locale.US), s=clean(sel).toLowerCase(Locale.US);
        String[] sep=e.split("\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2);
        if(sep.length==2){
            if(similar(s,sep[0])) return true;
            if(similar(s,sep[1])) return false;
        }
        // fallback: whichever competitor-like line appears first in context
        String lc=ctx.toLowerCase(Locale.US);
        int at=lc.indexOf(s);
        return at<Math.max(0,lc.length()/2);
    }

    private boolean similar(String a,String b){
        if(a.isEmpty()||b.isEmpty()) return false;
        return a.contains(b)||b.contains(a)||tokenOverlap(a,b)>=0.55;
    }
    private double tokenOverlap(String a,String b){
        Set<String> x=new HashSet<>(Arrays.asList(a.split("\\s+"))), y=new HashSet<>(Arrays.asList(b.split("\\s+")));
        x.removeIf(z->z.length()<2); y.removeIf(z->z.length()<2);
        if(x.isEmpty()||y.isEmpty()) return 0;
        int n=0; for(String z:x) if(y.contains(z)) n++;
        return n/(double)Math.min(x.size(),y.size());
    }

    private String findBestUrl(Candidate c){
        String best=c.url;
        for(Map.Entry<String,String> e:links.entrySet()){
            if(similar(clean(c.event).toLowerCase(Locale.US),clean(e.getKey()).toLowerCase(Locale.US)) ||
               similar(clean(c.selection).toLowerCase(Locale.US),clean(e.getKey()).toLowerCase(Locale.US))){
                best=e.getValue();
                if(best.startsWith("hardrock://")) break;
            }
        }
        return best;
    }
    private String findDeepLink(Candidate c){
        for(Map.Entry<String,String> e:links.entrySet()){
            String h=e.getValue();
            if(h.startsWith("hardrock://") && (similar(c.event.toLowerCase(),e.getKey().toLowerCase())||similar(c.selection.toLowerCase(),e.getKey().toLowerCase()))) return h;
            int p=h.indexOf("deep_link_value=hardrock%3A%2F%2F"); if(p>=0) return h;
        }
        return "";
    }

    private List<Candidate> parseText(String url,String title,String text){
        ArrayList<Candidate> out=new ArrayList<>();
        String[] raw=text.replace('\r','\n').split("\\n+");
        ArrayList<String> lines=new ArrayList<>();
        for(String r:raw){ String x=clean(r); if(!x.isEmpty()&&x.length()<180) lines.add(x); }
        for(int i=0;i<lines.size();i++){
            Matcher m=AMERICAN.matcher(lines.get(i));
            while(m.find()){
                int odds; try{ odds=Integer.parseInt(m.group(1)); }catch(Exception e){continue;}
                Candidate c=new Candidate(); c.odds=odds; c.url=url; c.context=window(lines,i,10,4); c.sport=guessSport(c.context+" "+title);
                c.market=guessMarket(lines,i); c.selection=guessSelection(lines,i,m.start()); c.event=guessEvent(lines,i,c.selection);
                if(c.selection.length()>1) out.add(c);
            }
        }
        return out;
    }

    private void walkJson(Object node,Ctx ctx,List<Candidate> out,String url,int depth){
        if(node==null||depth>15||out.size()>500) return;
        try{
            if(node instanceof JSONObject){
                JSONObject o=(JSONObject)node; Ctx n=new Ctx(ctx);
                Iterator<String> keys=o.keys();
                while(keys.hasNext()){
                    String k=keys.next(); Object v=o.opt(k); String kl=k.toLowerCase(Locale.US);
                    if(v instanceof String || v instanceof Number){
                        String sv=String.valueOf(v);
                        if(keyAny(kl,"sport","category")) n.sport=prefer(n.sport,sv);
                        if(keyAny(kl,"eventname","fixture","matchup","event_name","eventtitle")) n.event=prefer(n.event,sv);
                        if(keyAny(kl,"marketname","market_name","bettype","marketlabel")) n.market=prefer(n.market,sv);
                        if(keyAny(kl,"selectionname","outcomename","runnername","participantname","outcome_label")) n.selection=prefer(n.selection,sv);
                        if(keyAny(kl,"deeplink","deep_link")) n.deepLink=sv;
                    }
                }
                Integer odds=findOdds(o);
                if(odds!=null){
                    Candidate c=new Candidate(); c.odds=odds; c.url=url; c.sport=n.sport; c.event=n.event; c.market=n.market; c.selection=n.selection; c.deepLink=n.deepLink; c.context=o.toString();
                    if(c.selection.isEmpty()) c.selection=findName(o);
                    if(c.event.isEmpty()) c.event=findString(o,"event","fixture","match");
                    if(c.market.isEmpty()) c.market=findString(o,"market","betType","type");
                    if(c.selection.length()>1) out.add(c);
                }
                keys=o.keys(); while(keys.hasNext()){ Object v=o.opt(keys.next()); if(v instanceof JSONObject||v instanceof JSONArray) walkJson(v,n,out,url,depth+1); }
            } else if(node instanceof JSONArray){
                JSONArray a=(JSONArray)node; for(int i=0;i<a.length();i++) walkJson(a.opt(i),ctx,out,url,depth+1);
            }
        }catch(Exception ignored){}
    }

    private Integer findOdds(JSONObject o){
        String[] ks={"americanOdds","american_odds","price","oddsAmerican","american","displayOdds","odds"};
        for(String k:ks){
            if(!o.has(k)) continue; Object v=o.opt(k);
            try{
                if(v instanceof Number){ int n=((Number)v).intValue(); if(Math.abs(n)>=100&&Math.abs(n)<=10000) return n; double d=((Number)v).doubleValue(); if(d>=1.01&&d<100) return decimalToAmerican(d); }
                String s=String.valueOf(v); Matcher m=AMERICAN.matcher(s); if(m.find()) return Integer.parseInt(m.group(1));
                double d=Double.parseDouble(s); if(d>=1.01&&d<100) return decimalToAmerican(d);
            }catch(Exception ignored){}
        }
        return null;
    }
    private int decimalToAmerican(double d){ return d>=2? (int)Math.round((d-1)*100) : (int)Math.round(-100/(d-1)); }
    private String findName(JSONObject o){ return first(o,"name","label","title","participant","outcome","selection"); }
    private String findString(JSONObject o,String... keys){ return first(o,keys); }
    private String first(JSONObject o,String... keys){ for(String k:keys){ Object v=o.opt(k); if(v instanceof String && ((String)v).length()>1) return (String)v; } return ""; }
    private boolean keyAny(String k,String... v){ for(String s:v) if(k.contains(s.toLowerCase(Locale.US))) return true; return false; }
    private String prefer(String old,String n){ return (n!=null&&n.length()>1&&n.length()<160)?n:old; }

    private int[] findBestScore(String text){
        if(text==null) return null; Matcher m=SCORE.matcher(text); int[] last=null; int count=0;
        while(m.find() && count++<30){
            int a=Integer.parseInt(m.group(1)), b=Integer.parseInt(m.group(2));
            if(a<=30&&b<=30 && !(a==0&&b==0)) last=new int[]{a,b};
        }
        return last;
    }

    private void tryResolve(String text){
        String low=text.toLowerCase(Locale.US);
        boolean finalish=low.contains("final")||low.contains("finalizado")||low.contains("finished")||low.contains("ft ")||low.contains("resultado");
        if(!finalish) return;
        List<Signal> list=store.loadSignals(); boolean changed=false;
        for(Signal s:list){
            if(!"PENDIENTE".equals(s.status)||s.event.length()<3) continue;
            String[] teams=s.event.split("\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2);
            if(teams.length!=2) continue;
            if(!(low.contains(teams[0].toLowerCase(Locale.US)) && low.contains(teams[1].toLowerCase(Locale.US)))) continue;
            int idx=Math.max(low.indexOf(teams[0].toLowerCase()),low.indexOf(teams[1].toLowerCase()));
            String area=text.substring(Math.max(0,idx-250),Math.min(text.length(),idx+600));
            int[] sc=findBestScore(area); if(sc==null||sc[0]==sc[1]) continue;
            boolean first=selectionIsFirst(s.selection,s.event,area);
            boolean won=first?sc[0]>sc[1]:sc[1]>sc[0];
            String ml=(s.market+" "+s.selection).toLowerCase(Locale.US);
            if(isWinnerMarket(s.market)){
                s.status=won?"GANADA":"PERDIDA"; s.resolvedAt=System.currentTimeMillis();
                s.simulatedProfit=profit(s,s.status); changed=true;
            } else if(ml.contains("total")||ml.contains("over")||ml.contains("under")||ml.contains("más de")||ml.contains("menos de")){
                Matcher lm=LINE.matcher(ml);
                if(lm.find()){
                    double line=Double.parseDouble(lm.group(1));
                    double total=resolveTotal(area,s.market);
                    if(total>=0){
                        boolean over=ml.contains("over")||ml.contains("más de");
                        if(Math.abs(total-line)<0.001) s.status="PUSH"; else s.status=(over?total>line:total<line)?"GANADA":"PERDIDA";
                        s.resolvedAt=System.currentTimeMillis(); s.simulatedProfit=profit(s,s.status); changed=true;
                    }
                }
            }
        }
        if(changed) store.saveSignals(list);
    }
    private double resolveTotal(String area,String market){
        Matcher m=SCORE.matcher(area); ArrayList<int[]> pairs=new ArrayList<>();
        while(m.find()){ int a=Integer.parseInt(m.group(1)),b=Integer.parseInt(m.group(2)); if(a<=50&&b<=50) pairs.add(new int[]{a,b}); }
        if(pairs.isEmpty()) return -1;
        String x=market.toLowerCase(Locale.US);
        if(x.contains("set")||x.contains("game")||x.contains("juego")){ int[] z=pairs.get(pairs.size()-1); return z[0]+z[1]; }
        double sum=0; int used=0;
        for(int[] z:pairs){ if(Math.max(z[0],z[1])>=5){ sum+=z[0]+z[1]; used++; } }
        if(used>=2) return sum;
        int[] z=pairs.get(pairs.size()-1); return z[0]+z[1];
    }
    private boolean isWinnerMarket(String m){ String x=m.toLowerCase(); return x.contains("ganador")||x.contains("winner")||x.contains("moneyline")||x.contains("match"); }
    private double profit(Signal s,String status){
        if(!"GANADA".equals(status)) return "PERDIDA".equals(status)?-1:0;
        try{ int a=Integer.parseInt(s.odds.replace("+","")); return a>0?a/100.0:100.0/Math.abs(a); }catch(Exception e){return 0;}
    }

    private String guessSelection(List<String> l,int i,int oddsPos){
        String same=l.get(i).substring(0,Math.min(oddsPos,l.get(i).length())).trim();
        if(same.length()>1&&!isJunk(same)) return same;
        for(int j=i-1;j>=Math.max(0,i-4);j--){ String x=l.get(j); if(!hasOdds(x)&&!isMarket(x)&&!isJunk(x)) return x; }
        return "";
    }
    private String guessMarket(List<String> l,int i){
        for(int j=i;j>=Math.max(0,i-10);j--){ if(isMarket(l.get(j))) return l.get(j); }
        return "Mercado";
    }
    private String guessEvent(List<String> l,int i,String sel){
        for(int j=i;j>=Math.max(0,i-14);j--){ String x=l.get(j); if(x.matches("(?i).+\\s+(?:vs\\.?|v\\.?|@|contra)\\s+.+")) return x; }
        ArrayList<String> names=new ArrayList<>();
        for(int j=i-1;j>=Math.max(0,i-10)&&names.size()<3;j--){ String x=l.get(j); if(!isJunk(x)&&!isMarket(x)&&!hasOdds(x)&&x.length()>=3&&x.length()<55) names.add(x); }
        if(names.size()>=2){ Collections.reverse(names); return names.get(names.size()-2)+" vs "+names.get(names.size()-1); }
        return sel.length()>0?sel:"Evento Hard Rock";
    }
    private String guessSport(String x){
        String s=x.toLowerCase(Locale.US);
        if(s.contains("table tennis")||s.contains("ping pong")||s.contains("tenis de mesa")) return "Table Tennis";
        if(s.contains("esport")||s.contains("ebasket")||s.contains("esoccer")||s.contains("efootball")) return "eSports";
        if(s.contains("tennis")||s.contains("tenis")) return "Tennis";
        if(s.contains("basket")) return "Basketball";
        if(s.contains("baseball")||s.contains("mlb")) return "Baseball";
        if(s.contains("soccer")||s.contains("football")||s.contains("fútbol")) return "Soccer";
        if(s.contains("hockey")||s.contains("nhl")) return "Hockey";
        if(s.contains("volley")) return "Volleyball";
        if(s.contains("dart")) return "Darts";
        if(s.contains("boxing")||s.contains("boxeo")) return "Boxing";
        return store.currentSport();
    }
    private boolean isPing(String sport,String ctx){ String x=(sport+" "+ctx).toLowerCase(); return x.contains("table tennis")||x.contains("ping pong")||x.contains("tenis de mesa"); }
    private boolean isLive(String ctx){ String x=ctx.toLowerCase(); return x.contains("live")||x.contains("en vivo")||x.contains("in-play")||x.contains("in play"); }
    private boolean hasOdds(String x){ return AMERICAN.matcher(x).find(); }
    private boolean isMarket(String x){
        String s=x.toLowerCase(); String[] k={"winner","ganador","moneyline","total","over","under","más de","menos de","spread","handicap","set ","game ","correct score","resultado exacto","props","map winner","round winner"};
        for(String z:k) if(s.contains(z)) return true; return false;
    }
    private boolean isJunk(String x){
        String s=x.toLowerCase(); String[] k={"live","en vivo","cash out","betslip","apuestas","sportsbook","login","log in","sign in","boost","parlay","same game","popular","today","tomorrow"};
        for(String z:k) if(s.equals(z)) return true;
        return x.matches("^[\\d:./ -]+$")||x.length()>100;
    }
    private String window(List<String> l,int i,int before,int after){ StringBuilder b=new StringBuilder(); for(int j=Math.max(0,i-before);j<=Math.min(l.size()-1,i+after);j++) b.append(l.get(j)).append('\n'); return b.toString(); }
    private String clean(String x){ return x==null?"":x.replaceAll("\\s+"," ").trim(); }
    private String key(Candidate c){ return (clean(c.sport)+"|"+clean(c.event)+"|"+clean(c.market)+"|"+clean(c.selection)).toLowerCase(Locale.US); }
    private String clearEvent(String e){ return e==null||e.isEmpty()?"Partido detectado":e; }
    private String spanishSport(String sport,String ctx){
        String s=guessSport((sport==null?"":sport)+" "+ctx);
        switch(s){ case "Table Tennis":return "Tenis de mesa"; case "eSports":return "eSports"; case "Basketball":return "Baloncesto"; case "Baseball":return "Béisbol"; case "Soccer":return "Fútbol"; case "Hockey":return "Hockey"; case "Volleyball":return "Voleibol"; case "Darts":return "Dardos"; case "Boxing":return "Boxeo"; case "Tennis":return "Tenis"; default:return s; }
    }
    private String spanishMarket(String m){
        if(m==null||m.isEmpty()) return "Mercado"; String x=m;
        x=x.replaceAll("(?i)Match Winner","Ganador del partido").replaceAll("(?i)Set Winner","Ganador del set").replaceAll("(?i)Game Winner","Ganador del juego");
        x=x.replaceAll("(?i)Total Points","Total de puntos").replaceAll("(?i)Moneyline","Ganador").replaceAll("(?i)Correct Score","Resultado exacto");
        x=x.replaceAll("(?i)Over","Más de").replaceAll("(?i)Under","Menos de"); return x;
    }

    static class Candidate { String sport="",event="",market="",selection="",url="",deepLink="",context=""; int odds=0; }
    static class Ctx { String sport="",event="",market="",selection="",deepLink=""; Ctx(){} Ctx(Ctx x){sport=x.sport;event=x.event;market=x.market;selection=x.selection;deepLink=x.deepLink;} }
    static class ModelResult { double probability; String reason; ModelResult(double p,String r){probability=p;reason=r;} }
}
