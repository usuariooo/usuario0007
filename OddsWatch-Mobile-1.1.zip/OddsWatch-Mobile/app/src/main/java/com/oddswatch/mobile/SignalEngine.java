package com.oddswatch.mobile;

import android.content.Context;
import org.json.*;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class SignalEngine {
    public interface Listener { void onNewSignal(Signal s); void onDataChanged(); }
    private final Store store;
    private final Listener listener;
    private final Map<String,Double> previousProbability=new HashMap<>();
    private final Map<String,Integer> seenCount=new HashMap<>();
    private final Map<String,String> links=new LinkedHashMap<>();
    private final Map<String,Signal> recent=new LinkedHashMap<>();

    private static final Pattern AMERICAN=Pattern.compile("(?<!\\d)([+-](?:100|[1-9]\\d{2,3}))(?!\\d)");
    private static final Pattern SCORE=Pattern.compile("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)");
    private static final Pattern TOTAL=Pattern.compile("(?i)(?:over|under|más de|menos de|o/u)\\s*(\\d+(?:\\.\\d+)?)|(\\d+(?:\\.\\d+)?)\\s*(?:over|under)");
    private static final Pattern HCAP=Pattern.compile("(?<!\\d)([+-]\\d+(?:\\.\\d+))(?!\\d)");
    private static final Pattern SETNO=Pattern.compile("(?i)(?:set|game|round|juego|ronda)\\s*(\\d+)");
    private static final Pattern LONG_ID=Pattern.compile("(?<!\\d)(\\d{8,24})(?!\\d)");

    private static final String[] EDITORIAL={
            "what kind of","how to bet","betting markets are available","for example","let's say","you'd need to","you would need to",
            "summarize with chatgpt","updated:","common bets","betting guide","what is live betting","popular markets","faq","learn more",
            "sports betting spectacle","new to table tennis","we'll take you","we will take you","here's a breakdown","here is a breakdown"
    };

    public SignalEngine(Context c, Listener l){
        store=new Store(c); listener=l;
        for(Signal s:store.loadSignals()) recent.put(s.id,s);
    }

    public synchronized void setLinks(String json){
        links.clear();
        try{
            JSONArray a=new JSONArray(json);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.optJSONObject(i); if(o==null) continue;
                String t=clean(o.optString("t")), h=o.optString("h");
                if(!t.isEmpty() && !h.isEmpty() && !isEditorialUrl(h)) links.put(t,h);
            }
        }catch(Exception ignored){}
    }

    /** V5: page text is not a source of bets. It is only used to resolve existing signals/results. */
    public synchronized void ingestText(String url,String title,String text){
        store.setLastScan(System.currentTimeMillis());
        if(text!=null) tryResolve(text);
    }

    public synchronized int ingestDom(String url,String json){
        ArrayList<Candidate> out=new ArrayList<>();
        try{
            Object root=new JSONTokener(json).nextValue();
            if(root instanceof JSONArray){
                JSONArray a=(JSONArray)root;
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.optJSONObject(i); if(o==null) continue;
                    Candidate c=fromDom(url,o);
                    if(c!=null) out.add(c);
                }
                enrichEventsFromGroups(out);
            }
        }catch(Exception e){ store.setLastError("DOM: "+e.getMessage()); }
        out.removeIf(c->!validCandidate(c));
        store.setOddsSeen(out.size());
        if(!out.isEmpty()) evaluate(out,"DOM");
        return out.size();
    }

    public synchronized int ingestPayload(String url,String payload){
        if(payload==null||payload.length()<2) return 0;
        store.incPayloads();
        ArrayList<Candidate> out=new ArrayList<>();
        try{
            String t=payload.trim(); if(t.isEmpty()) return 0;
            char c=t.charAt(0);
            if(c=='{'||c=='['){ Object root=c=='{'?new JSONObject(t):new JSONArray(t); walkJson(root,new Ctx(),out,url,0); }
        }catch(Exception ignored){}
        out.removeIf(c->!validCandidate(c));
        if(!out.isEmpty()) evaluate(out,"PAYLOAD");
        return out.size();
    }

    private Candidate fromDom(String url,JSONObject o){
        String button=o.optString("button"), parent=o.optString("parent"), grand=o.optString("grand"), context=o.optString("context");
        Matcher om=AMERICAN.matcher(button); if(!om.find()) return null;
        int odds; try{odds=Integer.parseInt(om.group(1));}catch(Exception e){return null;}
        Candidate c=new Candidate(); c.odds=odds; c.url=url; c.context=context; c.source="DOM";
        c.selection=selectionFromInteractive(button,parent,grand,om.group(1));
        c.market=guessMarket(context,c.selection);
        c.event=guessEventStrict(context,c.selection,c.market);
        c.sport=guessSport(context);
        c.eventUrl=clean(o.optString("href"));
        JSONObject attrs=o.optJSONObject("attrs");
        if(attrs!=null){
            c.selectionId=findIdInAttrs(attrs,"selection","outcome","runner","betoffer","bet-offer","marketselection");
            c.eventId=findIdInAttrs(attrs,"event","fixture","match");
            if(c.eventUrl.isEmpty()) c.eventUrl=findUrlInAttrs(attrs);
        }
        if(c.selectionId.isEmpty()) c.selectionId=idFromUrl(c.eventUrl);
        if(!c.selectionId.isEmpty()) c.deepLink="hardrock://betslip/"+c.selectionId;
        return c;
    }

    private String selectionFromInteractive(String button,String parent,String grand,String odds){
        String x=clean(button.replace(odds,""));
        x=x.replaceAll("(?i)\\b(odds|price)\\b","").trim();
        if(validSelectionText(x)) return x;
        for(String src:new String[]{parent,grand}){
            String[] ls=splitLines(src);
            for(String line:ls){
                if(line.contains(odds)){
                    String y=clean(line.replace(odds,""));
                    if(validSelectionText(y)) return y;
                }
            }
        }
        return "";
    }

    private void enrichEventsFromGroups(List<Candidate> list){
        Map<String,List<Candidate>> groups=new LinkedHashMap<>();
        for(Candidate c:list){ String k=clean(c.context); if(k.length()>500)k=k.substring(0,500); groups.computeIfAbsent(k,z->new ArrayList<>()).add(c); }
        for(List<Candidate> g:groups.values()){
            LinkedHashSet<String> winnerSelections=new LinkedHashSet<>();
            for(Candidate c:g) if(isWinnerMarket(c.market)&&validCompetitor(c.selection)) winnerSelections.add(cleanCompetitor(c.selection));
            String grouped="";
            if(winnerSelections.size()>=2){ Iterator<String> it=winnerSelections.iterator(); grouped=it.next()+" vs "+it.next(); }
            if(grouped.isEmpty()) grouped=guessEventStrict(g.get(0).context,g.get(0).selection,g.get(0).market);
            for(Candidate c:g) if(!validEvent(c.event)&&validEvent(grouped)) c.event=grouped;
        }
    }

    private void evaluate(List<Candidate> list,String raw){
        long now=System.currentTimeMillis(); HashSet<String> touched=new HashSet<>();
        for(Candidate c:list){
            if(!validCandidate(c)) continue;
            String key=key(c); if(!touched.add(key)) continue;
            double implied=Models.americanImplied(c.odds);
            Double prev=previousProbability.put(key,implied);
            int n=seenCount.getOrDefault(key,0)+1; seenCount.put(key,n);
            if(prev==null||n<2) continue;
            double movement=implied-prev;
            ModelResult mr=model(c,implied);
            if(mr.probability<=0) continue;
            double edge=mr.probability-implied;
            boolean ping=isPing(c.sport,c.context), live=isLive(c.context);
            int score=Models.scoreFromEdge(Math.max(0,edge),live,ping,movement);
            if(edge<0.035 || score<store.minScore()) continue;

            String id=Integer.toHexString(key.hashCode()); Signal s=recent.get(id); boolean isNew=s==null;
            if(s==null){s=new Signal();s.id=id;s.createdAt=now;}
            s.updatedAt=now; s.sport=spanishSport(c.sport,c.context); s.event=normalizeEvent(c.event);
            s.market=spanishMarket(c.market); s.selection=spanishSelection(c.selection); s.odds=(c.odds>0?"+":"")+c.odds;
            s.implied=implied; s.modelProbability=mr.probability; s.edge=edge; s.score=score;
            s.url=findBestUrl(c); s.deepLink=!c.deepLink.isEmpty()?c.deepLink:findDeepLink(c); s.status="PENDIENTE";
            s.instruction=buildInstruction(s); s.source=c.source;
            s.reason=mr.reason+String.format(Locale.US," Probabilidad estimada %.1f%%; la cuota implica %.1f%%; diferencia +%.1f pp.",mr.probability*100,implied*100,edge*100);
            recent.put(id,s); store.upsert(s); if(isNew&&listener!=null)listener.onNewSignal(s);
        }
        if(listener!=null) listener.onDataChanged();
    }

    private ModelResult model(Candidate c,double implied){
        int[] sc=findBestScore(c.context); if(sc==null) return new ModelResult(0,"No hay marcador actual interpretable para este mercado.");
        boolean ping=isPing(c.sport,c.context); String m=(c.market+" "+c.selection).toLowerCase(Locale.US);
        if(ping){
            if(isTotalMarket(m)){
                Double line=extractTotalLine(m); if(line==null) return new ModelResult(0,"El total no tiene una línea numérica clara.");
                double overP=Models.pingPongTotalOver(sc[0],sc[1],line); boolean under=isUnder(m); double p=under?1-overP:overP;
                return new ModelResult(p,"Modelo local del total del juego/set usando el marcador visible "+sc[0]+"-"+sc[1]+" y línea "+fmtLine(line)+".");
            }
            if(isHandicapMarket(m)){
                Double h=extractHandicap(c.selection+" "+c.market); if(h==null) return new ModelResult(0,"El hándicap no tiene una línea numérica clara.");
                boolean first=selectionIsFirst(c.selection,c.event,c.context); double pFirst=Models.pingPongHandicapCover(sc[0],sc[1],first?h:-h);
                double p=first?pFirst:1-pFirst;
                return new ModelResult(p,"Modelo local de hándicap del juego/set usando marcador "+sc[0]+"-"+sc[1]+" y línea "+fmtSigned(h)+".");
            }
            if(isWinnerMarket(m)){
                double p=Models.pingPongSetWin(sc[0],sc[1]); if(!selectionIsFirst(c.selection,c.event,c.context))p=1-p;
                return new ModelResult(p,"Modelo local de ganador usando el marcador visible "+sc[0]+"-"+sc[1]+".");
            }
            return new ModelResult(0,"Mercado real detectado, pero todavía no hay modelo local fiable para recomendarlo.");
        }
        if(isWinnerMarket(m)){
            double p=Models.genericScoreProbability(sc[0],sc[1]); if(!selectionIsFirst(c.selection,c.event,c.context))p=1-p; p=.5+(p-.5)*.50;
            return new ModelResult(p,"Modelo experimental de ganador basado en marcador visible "+sc[0]+"-"+sc[1]+".");
        }
        return new ModelResult(0,"Mercado real detectado, pero sin modelo local suficiente para recomendarlo.");
    }

    private boolean validCandidate(Candidate c){
        if(c==null||c.odds==0||!validSelectionText(c.selection)||!validEvent(c.event)||!isMarket(c.market)) return false;
        String all=(c.event+" "+c.market+" "+c.selection+" "+c.context).toLowerCase(Locale.US);
        for(String z:EDITORIAL) if(all.contains(z)) return false;
        return true;
    }

    private boolean validEvent(String e){
        e=clean(e); if(e.length()<5||e.length()>110||e.contains("?"))return false;
        String low=e.toLowerCase(Locale.US); for(String z:EDITORIAL)if(low.contains(z))return false;
        String[] p=e.split("(?i)\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2); if(p.length!=2)return false;
        return validCompetitor(p[0])&&validCompetitor(p[1]);
    }
    private boolean validCompetitor(String x){
        x=cleanCompetitor(x); if(x.length()<2||x.length()>50||x.contains("?"))return false;
        String low=x.toLowerCase(Locale.US); if(isMarket(x)||hasOdds(x)||isJunk(x))return false;
        for(String z:EDITORIAL)if(low.contains(z))return false;
        return x.split("\\s+").length<=7;
    }
    private String cleanCompetitor(String x){ return clean(x).replaceAll("(?i)^(live|en vivo)\\s*[-•:]?\\s*",""); }
    private boolean validSelectionText(String x){
        x=clean(x); if(x.length()<1||x.length()>70||x.contains("?"))return false;
        String low=x.toLowerCase(Locale.US); for(String z:EDITORIAL)if(low.contains(z))return false;
        return !low.equals("odds")&&!low.equals("price")&&!isJunk(x);
    }

    private String guessEventStrict(String context,String selection,String market){
        String[] ls=splitLines(context);
        for(String x:ls){ if(x.matches("(?i).+\\s+(?:vs\\.?|v\\.?|@|contra)\\s+.+")&&validEvent(x))return x; }
        ArrayList<String> names=new ArrayList<>();
        for(String x:ls){
            String y=cleanCompetitor(stripOdds(x));
            if(!validCompetitor(y))continue;
            if(y.equalsIgnoreCase(cleanCompetitor(selection))||isLeagueLike(y)) continue;
            if(!names.contains(y)) names.add(y);
            if(names.size()>=6)break;
        }
        String sel=cleanCompetitor(selection);
        if(validCompetitor(sel)){
            for(String n:names){ if(!similar(sel,n)) return sel+" vs "+n; }
        }
        if(names.size()>=2) return names.get(0)+" vs "+names.get(1);
        return "";
    }

    private boolean isLeagueLike(String x){
        String l=x.toLowerCase(Locale.US); return l.contains("league")||l.contains("cup")||l.contains("liga")||l.contains("kbl")||l.contains("nba")||l.contains("mlb")||l.contains("nhl")||l.contains("tournament")||l.contains("series");
    }

    private String guessMarket(String context,String selection){
        String[] ls=splitLines(context); String best="";
        for(String x:ls){ if(isMarket(x)){ best=x; if(x.toLowerCase(Locale.US).contains("set")||x.toLowerCase(Locale.US).contains("game")||x.toLowerCase(Locale.US).contains("round"))break; } }
        if(best.isEmpty()&&isMarket(selection)) best=selection;
        return best;
    }

    private String[] splitLines(String x){
        if(x==null)return new String[0]; String[] a=x.replace('\r','\n').split("\\n+"); ArrayList<String> o=new ArrayList<>();
        for(String z:a){String c=clean(z);if(!c.isEmpty()&&c.length()<180)o.add(c);} return o.toArray(new String[0]);
    }
    private String stripOdds(String x){ return clean(AMERICAN.matcher(x==null?"":x).replaceAll("")); }

    private void walkJson(Object node,Ctx ctx,List<Candidate> out,String url,int depth){
        if(node==null||depth>17||out.size()>900)return;
        try{
            if(node instanceof JSONObject){
                JSONObject o=(JSONObject)node; Ctx n=new Ctx(ctx); Iterator<String> keys=o.keys();
                while(keys.hasNext()){
                    String k=keys.next(); Object v=o.opt(k); String kl=k.toLowerCase(Locale.US);
                    if(v instanceof String||v instanceof Number){
                        String sv=String.valueOf(v);
                        if(keyAny(kl,"sport","category"))n.sport=prefer(n.sport,sv);
                        if(keyAny(kl,"eventname","event_name","eventtitle","fixture","matchup","match_name"))n.event=prefer(n.event,sv);
                        if(keyAny(kl,"marketname","market_name","marketlabel","bettype","bet_type"))n.market=prefer(n.market,sv);
                        if(keyAny(kl,"selectionname","selection_name","outcomename","outcome_name","runnername","participantname","outcome_label"))n.selection=prefer(n.selection,sv);
                        if(keyAny(kl,"deeplink","deep_link"))n.deepLink=sv;
                        if(keyAny(kl,"selectionid","selection_id","outcomeid","outcome_id","runnerid","runner_id"))n.selectionId=cleanId(sv);
                        if(keyAny(kl,"eventid","event_id","fixtureid","fixture_id","matchid","match_id"))n.eventId=cleanId(sv);
                    }
                }
                Integer odds=findOdds(o);
                if(odds!=null){
                    Candidate c=new Candidate(); c.odds=odds;c.url=url;c.sport=n.sport;c.event=n.event;c.market=n.market;c.selection=n.selection;c.deepLink=n.deepLink;c.selectionId=n.selectionId;c.eventId=n.eventId;c.context=o.toString();c.source="RED";
                    if(c.selection.isEmpty())c.selection=findName(o); if(c.event.isEmpty())c.event=findString(o,"eventName","event_name","fixture","matchup"); if(c.market.isEmpty())c.market=findString(o,"marketName","market_name","betType");
                    if(c.selectionId.isEmpty())c.selectionId=findSelectionId(o); if(c.deepLink.isEmpty()&&!c.selectionId.isEmpty())c.deepLink="hardrock://betslip/"+c.selectionId;
                    out.add(c);
                }
                keys=o.keys(); while(keys.hasNext()){Object v=o.opt(keys.next());if(v instanceof JSONObject||v instanceof JSONArray)walkJson(v,n,out,url,depth+1);}
            } else if(node instanceof JSONArray){JSONArray a=(JSONArray)node;for(int i=0;i<a.length();i++)walkJson(a.opt(i),ctx,out,url,depth+1);}
        }catch(Exception ignored){}
    }

    private Integer findOdds(JSONObject o){
        String[] ks={"americanOdds","american_odds","oddsAmerican","displayOdds","price","american","odds"};
        for(String k:ks){ if(!o.has(k))continue;Object v=o.opt(k);try{ if(v instanceof Number){double d=((Number)v).doubleValue();int n=((Number)v).intValue();if(Math.abs(n)>=100&&Math.abs(n)<=10000)return n;if(d>=1.01&&d<100)return decimalToAmerican(d);}String s=String.valueOf(v);Matcher m=AMERICAN.matcher(s);if(m.find())return Integer.parseInt(m.group(1));double d=Double.parseDouble(s);if(d>=1.01&&d<100)return decimalToAmerican(d);}catch(Exception ignored){} } return null;
    }
    private int decimalToAmerican(double d){return d>=2?(int)Math.round((d-1)*100):(int)Math.round(-100/(d-1));}
    private String findName(JSONObject o){return first(o,"selectionName","outcomeName","runnerName","name","label","title","participant","outcome","selection");}
    private String findString(JSONObject o,String...ks){return first(o,ks);}
    private String first(JSONObject o,String...ks){for(String k:ks){Object v=o.opt(k);if(v instanceof String&&((String)v).length()>1)return(String)v;}return"";}
    private String findSelectionId(JSONObject o){
        Iterator<String> it=o.keys(); while(it.hasNext()){String k=it.next(),kl=k.toLowerCase(Locale.US);if(kl.contains("selection")||kl.contains("outcome")||kl.contains("runner")){String v=String.valueOf(o.opt(k));String id=cleanId(v);if(!id.isEmpty())return id;}}return"";
    }

    private String findIdInAttrs(JSONObject o,String...terms){
        Iterator<String> it=o.keys(); while(it.hasNext()){String k=it.next(),kl=k.toLowerCase(Locale.US);boolean hit=false;for(String t:terms)if(kl.contains(t)){hit=true;break;}if(!hit)continue;String id=cleanId(String.valueOf(o.opt(k)));if(!id.isEmpty())return id;}return"";
    }
    private String findUrlInAttrs(JSONObject o){Iterator<String>it=o.keys();while(it.hasNext()){String k=it.next();String v=String.valueOf(o.opt(k));if((k.toLowerCase().contains("href")||k.toLowerCase().contains("url"))&&v.startsWith("http"))return v;}return"";}
    private String cleanId(String s){ if(s==null)return""; Matcher m=LONG_ID.matcher(s);return m.find()?m.group(1):""; }
    private String idFromUrl(String s){return cleanId(s);}

    private void tryResolve(String text){
        if(text==null||text.isEmpty())return; String low=text.toLowerCase(Locale.US); List<Signal> list=store.loadSignals(); boolean changed=false;
        boolean pageFinal=low.contains("final")||low.contains("finalizado")||low.contains("finished")||low.contains("resultado final");
        for(Signal s:list){
            if(!"PENDIENTE".equals(s.status)||!validEvent(s.event))continue;
            String[] teams=s.event.split("(?i)\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2);if(teams.length!=2)continue;
            String a=teams[0].toLowerCase(Locale.US),b=teams[1].toLowerCase(Locale.US);if(!low.contains(a)||!low.contains(b))continue;
            int idx=Math.max(low.indexOf(a),low.indexOf(b));String area=text.substring(Math.max(0,idx-300),Math.min(text.length(),idx+1200));
            ArrayList<int[]> scores=findScores(area);if(scores.isEmpty())continue;String m=(s.market+" "+s.selection).toLowerCase(Locale.US);Integer setNo=extractSetNo(m);
            if(isSetMarket(m)){
                int[] sc=pickCompletedSet(scores,setNo);if(sc==null)continue;resolveFromScore(s,sc,m,area);changed=true;
            }else if(pageFinal){int[] sc=scores.get(scores.size()-1);resolveFromScore(s,sc,m,area);changed=true;}
        }
        if(changed)store.saveSignals(list);
    }

    private void resolveFromScore(Signal s,int[] sc,String m,String area){
        if(isTotalMarket(m)){Double line=extractTotalLine(m);if(line==null)return;double total=sc[0]+sc[1];boolean over=!isUnder(m);if(Math.abs(total-line)<.001)s.status="PUSH";else s.status=(over?total>line:total<line)?"GANADA":"PERDIDA";}
        else if(isHandicapMarket(m)){Double h=extractHandicap(s.selection+" "+s.market);if(h==null)return;boolean first=selectionIsFirst(s.selection,s.event,area);double diff=first?(sc[0]-sc[1]):(sc[1]-sc[0]);if(Math.abs(diff+h)<.001)s.status="PUSH";else s.status=(diff+h>0)?"GANADA":"PERDIDA";}
        else if(isWinnerMarket(m)){boolean first=selectionIsFirst(s.selection,s.event,area);s.status=(first?sc[0]>sc[1]:sc[1]>sc[0])?"GANADA":"PERDIDA";}else return;
        s.resolvedAt=System.currentTimeMillis();s.simulatedProfit=profit(s,s.status);
    }
    private int[] pickCompletedSet(List<int[]> scores,Integer setNo){
        ArrayList<int[]> done=new ArrayList<>();for(int[]z:scores)if((Math.max(z[0],z[1])>=11)&&Math.abs(z[0]-z[1])>=2)done.add(z);if(done.isEmpty())return null;if(setNo!=null&&setNo>0&&done.size()>=setNo)return done.get(setNo-1);return done.get(done.size()-1);
    }
    private ArrayList<int[]> findScores(String text){ArrayList<int[]>o=new ArrayList<>();Matcher m=SCORE.matcher(text);while(m.find()&&o.size()<30){int a=Integer.parseInt(m.group(1)),b=Integer.parseInt(m.group(2));if(a<=50&&b<=50&&!(a==0&&b==0))o.add(new int[]{a,b});}return o;}
    private int[] findBestScore(String text){ArrayList<int[]>x=findScores(text);return x.isEmpty()?null:x.get(x.size()-1);}

    private boolean selectionIsFirst(String sel,String event,String ctx){
        String e=clean(event).toLowerCase(Locale.US),s=clean(sel).toLowerCase(Locale.US);String[]sep=e.split("\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2);if(sep.length==2){if(similar(s,sep[0]))return true;if(similar(s,sep[1]))return false;}int at=ctx.toLowerCase(Locale.US).indexOf(s);return at>=0&&at<Math.max(1,ctx.length()/2);
    }
    private boolean similar(String a,String b){a=clean(a).toLowerCase(Locale.US);b=clean(b).toLowerCase(Locale.US);if(a.isEmpty()||b.isEmpty())return false;return a.contains(b)||b.contains(a)||tokenOverlap(a,b)>=.55;}
    private double tokenOverlap(String a,String b){Set<String>x=new HashSet<>(Arrays.asList(a.split("\\s+"))),y=new HashSet<>(Arrays.asList(b.split("\\s+")));x.removeIf(z->z.length()<2);y.removeIf(z->z.length()<2);if(x.isEmpty()||y.isEmpty())return 0;int n=0;for(String z:x)if(y.contains(z))n++;return n/(double)Math.min(x.size(),y.size());}

    private String findBestUrl(Candidate c){
        if(!c.eventUrl.isEmpty()&&!isEditorialUrl(c.eventUrl))return c.eventUrl;
        for(Map.Entry<String,String>e:links.entrySet()){if((similar(c.event,e.getKey())||similar(c.selection,e.getKey()))&&!isEditorialUrl(e.getValue()))return e.getValue();}
        return isEditorialUrl(c.url)?"":c.url;
    }
    private String findDeepLink(Candidate c){
        if(!c.selectionId.isEmpty())return"hardrock://betslip/"+c.selectionId;
        if(c.deepLink!=null&&!c.deepLink.isEmpty())return decodeMaybeDeep(c.deepLink);
        for(Map.Entry<String,String>e:links.entrySet()){String h=e.getValue();if(h.startsWith("hardrock://")&&(similar(c.event,e.getKey())||similar(c.selection,e.getKey())))return h;String d=decodeMaybeDeep(h);if(d.startsWith("hardrock://")&&(similar(c.event,e.getKey())||similar(c.selection,e.getKey())))return d;}
        return"";
    }
    private String decodeMaybeDeep(String h){try{int p=h.indexOf("deep_link_value=");if(p>=0){String q=h.substring(p+16).split("&",2)[0];return URLDecoder.decode(q,StandardCharsets.UTF_8.name());}}catch(Exception ignored){}return h;}
    private boolean isEditorialUrl(String h){if(h==null)return false;String x=h.toLowerCase(Locale.US);if(x.contains("/news/")||x.contains("/learn/")||x.contains("/guide"))return true;return x.matches(".*hardrock\\.bet/sportsbook/(table-tennis|basketball|baseball|soccer|football|tennis|hockey|volleyball|boxing|golf|mma|ufc|cricket|rugby|darts)/?(?:[?#].*)?$");}

    private String buildInstruction(Signal s){
        String m=s.market.toLowerCase(Locale.US),sel=s.selection;
        if(isTotalMarket(m+" "+sel)) return "TOCA: "+sel+" • "+s.market+" • cuota "+s.odds;
        if(isHandicapMarket(m+" "+sel)) return "TOCA: "+s.market+" → "+sel+" • cuota "+s.odds;
        if(m.contains("set")||m.contains("juego")||m.contains("ronda")) return "TOCA: "+s.market+" → "+sel+" • cuota "+s.odds;
        return "TOCA: "+s.market+" → "+sel+" • cuota "+s.odds;
    }

    private String normalizeEvent(String e){String[]p=clean(e).split("(?i)\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2);return p.length==2?cleanCompetitor(p[0])+" vs "+cleanCompetitor(p[1]):clean(e);}
    private String spanishSport(String sport,String ctx){String s=guessSport((sport==null?"":sport)+" "+ctx);switch(s){case"Table Tennis":return"Tenis de mesa";case"eSports":return"eSports";case"Basketball":return"Baloncesto";case"Baseball":return"Béisbol";case"Soccer":return"Fútbol";case"Hockey":return"Hockey";case"Volleyball":return"Voleibol";case"Darts":return"Dardos";case"Boxing":return"Boxeo";case"Tennis":return"Tenis";default:return s;}}
    private String spanishMarket(String m){
        String x=clean(m);if(x.isEmpty())return"Mercado";
        x=x.replaceAll("(?i)Match Winner","Ganador del partido").replaceAll("(?i)Moneyline","Ganador del partido");
        x=x.replaceAll("(?i)Set\\s*(\\d+)\\s*Winner","Ganador del set $1").replaceAll("(?i)Set Winner","Ganador del set");
        x=x.replaceAll("(?i)Game\\s*(\\d+)\\s*Winner","Ganador del juego $1").replaceAll("(?i)Game Winner","Ganador del juego");
        x=x.replaceAll("(?i)Round\\s*(\\d+)\\s*Winner","Ganador de la ronda $1").replaceAll("(?i)Round Winner","Ganador de la ronda");
        x=x.replaceAll("(?i)Total Points","Total de puntos").replaceAll("(?i)Game Total","Total del juego").replaceAll("(?i)Set Total","Total del set");
        x=x.replaceAll("(?i)Handicap","Hándicap").replaceAll("(?i)Spread","Hándicap").replaceAll("(?i)Correct Score","Resultado exacto");
        x=x.replaceAll("(?i)Over","Más de").replaceAll("(?i)Under","Menos de").replaceAll("(?i)Winner","Ganador"); return x;
    }
    private String spanishSelection(String s){String x=clean(s);x=x.replaceAll("(?i)\\bOver\\b","Más de").replaceAll("(?i)\\bUnder\\b","Menos de").replaceAll("(?i)\\bDraw\\b","Empate").replaceAll("(?i)^Yes$","Sí").replaceAll("(?i)^No$","No");return x;}

    private String guessSport(String x){String s=(x==null?"":x).toLowerCase(Locale.US);if(s.contains("table tennis")||s.contains("ping pong")||s.contains("tenis de mesa"))return"Table Tennis";if(s.contains("esport")||s.contains("ebasket")||s.contains("esoccer")||s.contains("efootball"))return"eSports";if(s.contains("tennis")||s.contains("tenis"))return"Tennis";if(s.contains("basket")||s.contains("kbl")||s.contains("nba"))return"Basketball";if(s.contains("baseball")||s.contains("mlb"))return"Baseball";if(s.contains("soccer")||s.contains("fútbol"))return"Soccer";if(s.contains("hockey")||s.contains("nhl"))return"Hockey";if(s.contains("volley"))return"Volleyball";if(s.contains("dart"))return"Darts";if(s.contains("boxing")||s.contains("boxeo"))return"Boxing";return store.currentSport();}
    private boolean isPing(String sport,String ctx){String x=(sport+" "+ctx).toLowerCase(Locale.US);return x.contains("table tennis")||x.contains("ping pong")||x.contains("tenis de mesa");}
    private boolean isLive(String ctx){String x=(ctx==null?"":ctx).toLowerCase(Locale.US);return x.contains("live")||x.contains("en vivo")||x.contains("in-play")||x.contains("in play");}
    private boolean isMarket(String x){String s=(x==null?"":x).toLowerCase(Locale.US);String[]k={"winner","ganador","moneyline","total","over","under","más de","menos de","spread","handicap","hándicap","set ","game ","round ","juego ","ronda ","correct score","resultado exacto","map winner"};for(String z:k)if(s.contains(z))return true;return false;}
    private boolean isWinnerMarket(String x){String s=(x==null?"":x).toLowerCase(Locale.US);return s.contains("winner")||s.contains("ganador")||s.contains("moneyline");}
    private boolean isTotalMarket(String x){String s=(x==null?"":x).toLowerCase(Locale.US);return s.contains("total")||s.contains("over")||s.contains("under")||s.contains("más de")||s.contains("menos de");}
    private boolean isHandicapMarket(String x){String s=(x==null?"":x).toLowerCase(Locale.US);return s.contains("handicap")||s.contains("hándicap")||s.contains("spread");}
    private boolean isSetMarket(String x){String s=(x==null?"":x).toLowerCase(Locale.US);return s.contains("set")||s.contains("juego")||s.contains("game")||s.contains("round")||s.contains("ronda");}
    private boolean isUnder(String x){String s=x.toLowerCase(Locale.US);return s.contains("under")||s.contains("menos de");}
    private Double extractTotalLine(String x){Matcher m=TOTAL.matcher(x);if(m.find()){String z=m.group(1)!=null?m.group(1):m.group(2);try{return Double.parseDouble(z);}catch(Exception ignored){}}return null;}
    private Double extractHandicap(String x){Matcher m=HCAP.matcher(x);while(m.find()){try{double d=Double.parseDouble(m.group(1));if(Math.abs(d)<50)return d;}catch(Exception ignored){}}return null;}
    private Integer extractSetNo(String x){Matcher m=SETNO.matcher(x);if(m.find())try{return Integer.parseInt(m.group(1));}catch(Exception ignored){}return null;}
    private String fmtLine(double d){return d==(long)d?String.valueOf((long)d):String.valueOf(d);}
    private String fmtSigned(double d){return(d>0?"+":"")+fmtLine(d);}

    private boolean hasOdds(String x){return AMERICAN.matcher(x==null?"":x).find();}
    private boolean isJunk(String x){String s=clean(x).toLowerCase(Locale.US);String[]k={"live","en vivo","cash out","betslip","apuestas","sportsbook","login","log in","sign in","boost","parlay","same game","popular","today","tomorrow","open","close","more bets","stream now"};for(String z:k)if(s.equals(z))return true;return x.matches("^[\\d:./ -]+$")||x.length()>110;}
    private String clean(String x){return x==null?"":x.replaceAll("\\s+"," ").trim();}
    private String key(Candidate c){return(clean(c.sport)+"|"+normalizeEvent(c.event)+"|"+clean(c.market)+"|"+clean(c.selection)).toLowerCase(Locale.US);}
    private boolean keyAny(String k,String...v){for(String s:v)if(k.contains(s.toLowerCase(Locale.US)))return true;return false;}
    private String prefer(String old,String n){return(n!=null&&n.length()>1&&n.length()<160)?n:old;}
    private double profit(Signal s,String status){if(!"GANADA".equals(status))return"PERDIDA".equals(status)?-1:0;try{int a=Integer.parseInt(s.odds.replace("+",""));return a>0?a/100.0:100.0/Math.abs(a);}catch(Exception e){return 0;}}

    static class Candidate{String sport="",event="",market="",selection="",url="",eventUrl="",deepLink="",selectionId="",eventId="",context="",source="";int odds=0;}
    static class Ctx{String sport="",event="",market="",selection="",deepLink="",selectionId="",eventId="";Ctx(){}Ctx(Ctx x){sport=x.sport;event=x.event;market=x.market;selection=x.selection;deepLink=x.deepLink;selectionId=x.selectionId;eventId=x.eventId;}}
    static class ModelResult{double probability;String reason;ModelResult(double p,String r){probability=p;reason=r;}}
}
