package com.oddswatch.mobile;

import android.graphics.Rect;
import java.util.*;
import java.util.regex.*;

/**
 * Geometry-first parser for the Hard Rock screen.
 * It deliberately refuses to create a signal unless it can identify two real
 * competitors, a market/selection and a price. This avoids OCR strings such as
 * "U 8.5", "1st Half" or "SGP" becoming fake team names.
 */
public class VisionParser {
    public interface Listener { void onSignal(Signal s); void onObservedChanged(); void onTargetFound(int x,int y); void onHighlight(int x,int y,String label,boolean test); void onResultResolved(String event,String status); void onNavigateTap(int x,int y,String sport); void onSportBarSwipe(boolean left); void onLiveConfirmed(); }
    private final Store store; private final Listener listener;
    private final Map<String,Double> previousImplied=new HashMap<>();
    private final Map<String,String> previousOddsText=new HashMap<>();
    private final Map<String,Long> lastSignalAt=new HashMap<>(), lastEventSignalAt=new HashMap<>(), lastSeenAt=new HashMap<>();
    private final Map<String,Integer> stableSeen=new HashMap<>();
    private final Map<String,Long> resultCheckAt=new HashMap<>();
    private long lastResultSearch=0,lastVisualNav=0,lastVisualSwipe=0,lastVisualLiveTap=0,lastAnySignalAt=0;
    private int visualSportIndex=0;
    private static final String[] VISUAL_SPORTS={"Table Tennis","eSports","Table Tennis","E-Sports","Table Tennis","Esports"};

    private static final Pattern AMERICAN=Pattern.compile("(?<!\\d)([+-](?:100|[1-9]\\d{2,3}))(?!\\d)");
    private static final Pattern DECIMAL=Pattern.compile("(?<![\\d.])((?:1|[2-9]|[1-9]\\d)\\.\\d{2})(?!\\d)");
    private static final Pattern SCORE=Pattern.compile("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)");
    private static final Pattern COMPLETE_LEFT_SCORE=Pattern.compile("(?i)^\\s*(\\d{1,2})\\s+(.{2,45}?)\\s+vs\\.?\\s+(.{2,45}?)\\s+(\\d{1,2})\\s*$");
    private static final Pattern COMPLETE_MID_SCORE=Pattern.compile("(?i)^\\s*(.{2,45}?)\\s+(\\d{1,2})\\s+vs\\.?\\s+(.{2,45}?)\\s+(\\d{1,2})\\s*$");
    private static final Pattern STAGE=Pattern.compile("(?i)(?:set|game|round|juego|ronda)\\s*(\\d+)");
    private static final Pattern PERIOD_ONLY=Pattern.compile("(?i)^(?:1st|2nd|3rd|4th|first|second|third|fourth)\\s+(?:half|quarter|period|set|game|round)$");
    private static final Pattern OU_TOKEN=Pattern.compile("(?i)^(?:o|u|over|under|más de|menos de)\\s*\\d+(?:[.,]\\d+)?$");
    private static final Pattern LINE_TOKEN=Pattern.compile("^[+-]\\d+(?:[.,]\\d+)?$");
    private static final Pattern INT_TOKEN=Pattern.compile("(?<!\\d)(\\d{1,2})(?![\\d.])");

    private static final String[] MARKET_WORDS={"winner","moneyline","ganador","match result","result","set winner","game winner","round winner","total","goals","runs","points","puntos","over","under","más de","menos de","handicap","hándicap","spread","correct score","resultado exacto","1st half total","2nd half total"};
    private static final String[] JUNK={"live","live now","en vivo","bet slip","betslip","popular","all sports","sports","search","promos","my bets","cash out","login","sign in","same game","parlay","boost","odds","more wagers","show more","league","cup","tournament","today","tomorrow","stream","stream now","watch","sgp","account","home","discover","games","table tennis","ping pong","e-sports","esports","basketball","soccer","tennis","baseball","mlb","hockey","football","nfl","pga","golf","winner","moneyline","spread","total"};

    public VisionParser(Store s,Listener l){store=s;listener=l;}

    public synchronized void ingest(List<OcrLine> raw,int screenW,int screenH){
        long now=System.currentTimeMillis();
        ArrayList<OcrLine> lines=new ArrayList<>();
        for(OcrLine x:raw)if(x!=null&&!clean(x.text).isEmpty())lines.add(new OcrLine(clean(x.text),x.box));
        lines.sort((a,b)->{int d=Integer.compare(a.box.top,b.box.top);return d!=0?d:Integer.compare(a.box.left,b.box.left);});
        store.setLastOcr(now);store.setLinesSeen(lines.size());
        String all=join(lines);String screenSport=detectSport(lines,screenH);store.setCurrentSport(screenSport);
        boolean screenLive=isConfirmedLiveScreen(lines,screenH);
        if(screenLive&&listener!=null)listener.onLiveConfirmed();
        maybeFindTarget(lines);
        resolveCompletedScreen(lines,all);
        resolveTableTennis(lines);

        // ONE-SIGNAL LOCK: during the virtual test, once a signal is opened we stop
        // hunting for new bets and keep following that exact event until it resolves.
        Signal tracking=store.trackingSignal();
        if(store.paperActive()&&tracking!=null&&"PENDIENTE".equals(tracking.status)){
            if(store.openTarget().isEmpty()&&now-store.openTargetAt()>2500){
                store.setOpenTarget(tracking.event,tracking.sport);
            }
            store.setResultStatus("🔒 SIGUIENDO: "+tracking.event+" • "+tracking.market+" → "+tracking.selection+" @ "+tracking.odds);
            store.setMarketsSeen(0);
            if(listener!=null)listener.onObservedChanged();
            return;
        }

        // Overnight mode is LIVE-first. On Home/Discover we do not parse pregame cards
        // and we do not touch MLB/Table Tennis tabs until the LIVE section is actually visible.
        if(store.dedicated()&&store.openTarget().isEmpty()&&!screenLive){
            maybeEnterLive(lines,screenW,screenH,now);
            store.setMarketsSeen(0);
            if(listener!=null)listener.onObservedChanged();
            return;
        }
        maybeRotateVisualSports(lines,screenW,screenH,now,screenLive);

        ArrayList<Candidate> candidates=new ArrayList<>();
        for(int i=0;i<lines.size();i++){
            OcrLine l=lines.get(i);
            collectOdds(lines,i,l,AMERICAN,true,screenSport,screenLive,screenW,screenH,candidates);
            collectOdds(lines,i,l,DECIMAL,false,screenSport,screenLive,screenW,screenH,candidates);
        }
        dedupe(candidates);store.setMarketsSeen(candidates.size());

        if(store.consumeTestHighlight()&&!candidates.isEmpty()&&listener!=null){Candidate t=candidates.get(0);listener.onHighlight(t.x,t.y,"PRUEBA • "+t.selection+"  "+t.oddsText,true);}

        Candidate bestCandidate=null; Signal bestObserved=null; double bestMove=0; double bestPrev=0; String bestPrevOdds=""; int bestStable=0;
        for(Candidate c:candidates){
            Signal observed=toSignal(c,now);store.upsertObserved(observed);
            String key=observed.baseId;
            long prevAt=lastSeenAt.getOrDefault(key,0L);int stable=(now-prevAt<3200)?stableSeen.getOrDefault(key,0)+1:1;stableSeen.put(key,stable);lastSeenAt.put(key,now);

            double prev=previousImplied.containsKey(key)?previousImplied.get(key):Double.NaN;
            String prevOdds=previousOddsText.getOrDefault(key,"");
            previousImplied.put(key,c.implied);previousOddsText.put(key,c.oddsText);
            if(stable<2)continue; // test mode: two stable OCR reads are enough before evaluating movement
            if(Double.isNaN(prev)||Math.abs(prev-c.implied)<0.000001)continue;
            double move=c.implied-prev;
            if(move<store.movementThreshold())continue;
            long last=lastSignalAt.getOrDefault(key,0L);if(now-last<90000)continue;
            String eventKey=observed.event.toLowerCase(Locale.US);
            if(now-lastEventSignalAt.getOrDefault(eventKey,0L)<90000)continue;
            if(store.paperActive()&&store.trackingSignal()!=null)continue;
            // One actionable signal at a time. No more bursts of 10 cards in a few seconds.
            if(now-lastAnySignalAt<20000)continue;
            if(bestCandidate==null||move>bestMove){bestCandidate=c;bestObserved=observed;bestMove=move;bestPrev=prev;bestPrevOdds=prevOdds;bestStable=stable;}
        }
        if(bestCandidate!=null&&bestObserved!=null){
            String key=bestObserved.baseId;Signal s=toSignal(bestCandidate,now);s.movement=bestMove;s.previousOdds=bestPrevOdds;s.observations=bestStable;boolean strong=bestMove>=0.008;
            s.score=Math.min(99,(strong?76:64)+bestMove*100*6);s.id=key+"-"+(now/90000);s.createdAt=now;s.updatedAt=now;s.status="PENDIENTE";
            String before=(bestPrevOdds==null||bestPrevOdds.isEmpty())?"cuota anterior":bestPrevOdds;
            s.reason=(s.live?"🔴 LIVE • ":"🗓️ PRE • ")+(strong?"SEÑAL FUERTE":"SEÑAL CONFIRMADA")+". Base: "+bestStable+" lecturas consecutivas del mismo partido/mercado. Cuota "+before+" → "+s.odds+"; probabilidad implícita "+fmt(bestPrev*100)+"% → "+fmt(s.implied*100)+"% (+"+fmt(bestMove*100)+" pp). Se eligió como la mejor señal visible de ese ciclo.";
            if(store.paperActive()){
                if(!store.canPaperBet()){store.incrementPaperSkipped();}
                else {s.paper=true;s.sessionId=store.paperSessionId();s.stake=store.paperStake();s.potentialProfit=Models.profitForStake(s.odds,s.stake);s.reason="🧪 APUESTA VIRTUAL • MODO 1 A LA VEZ. "+s.reason+" Stake virtual "+Models.money(s.stake)+"; $0 real. OddsWatch seguirá este partido hasta resolverlo antes de buscar otra señal.";lastSignalAt.put(key,now);lastEventSignalAt.put(s.event.toLowerCase(Locale.US),now);lastAnySignalAt=now;store.upsertSignal(s);store.setTrackingSignal(s);store.setOpenTarget(s.event,s.sport);if(listener!=null)listener.onSignal(s);}
            } else {lastSignalAt.put(key,now);lastEventSignalAt.put(s.event.toLowerCase(Locale.US),now);lastAnySignalAt=now;store.upsertSignal(s);if(listener!=null)listener.onSignal(s);}
        }

        maybeScheduleResultCheck(now,screenSport);
        if(listener!=null)listener.onObservedChanged();
    }

    private void collectOdds(List<OcrLine> lines,int idx,OcrLine l,Pattern p,boolean american,String sport,boolean screenLive,int sw,int sh,List<Candidate> out){
        Matcher m=p.matcher(normalizeNums(l.text));
        while(m.find()){
            String price=m.group(1);double implied=Models.impliedFromOdds(price);if(implied<=0||implied>=0.995)continue;
            if(!american){try{double d=Double.parseDouble(price);if(d>15.0)continue;}catch(Exception e){continue;}}
            Candidate c=buildCandidate(lines,idx,l,price,implied,sport,screenLive,sw,sh);if(c!=null&&valid(c))out.add(c);
        }
    }

    private Candidate buildCandidate(List<OcrLine> lines,int idx,OcrLine oddsLine,String oddsText,double implied,String sport,boolean screenLive,int sw,int sh){
        EventPair pair=findEventPair(lines,oddsLine,sw,sh);if(pair==null)return null;
        Candidate c=new Candidate();c.oddsText=oddsText;c.implied=implied;c.sport=inferSport(sport,pair,lines,oddsLine,sh);c.live=screenLive||nearLive(lines,oddsLine,sh);c.x=oddsLine.cx();c.y=oddsLine.cy();c.screenState=summarizeState(nearText(lines,oddsLine,sh));c.event=pair.a+" vs "+pair.b;
        OcrLine selectionLine=findSelectionLine(lines,oddsLine,pair,oddsText,sw,sh);
        if(selectionLine!=null)c.selection=translateSelection(clean(removePrice(selectionLine.text,oddsText)));
        if(c.selection.isEmpty()){
            OcrLine row=rowCompetitor(pair,oddsLine);if(row!=null)c.selection=cleanCompetitor(stripScores(stripOdds(row.text)));
        }
        OcrLine marketLine=findMarketLine(lines,oddsLine,selectionLine,sh);c.market=marketLine==null?inferMarket(c.selection,nearText(lines,oddsLine,sh),c.sport):translateMarket(marketLine.text,c.sport);
        if(c.market.isEmpty())c.market=inferMarket(c.selection,nearText(lines,oddsLine,sh),c.sport);
        Rect ev=new Rect(pair.box);ev.union(oddsLine.box);if(selectionLine!=null)ev.union(selectionLine.box);if(marketLine!=null)ev.union(marketLine.box);
        // Screenshot crop is anchored to the exact price that triggered the signal.
        // Keep enough room above for event/market names, but avoid unrelated games below.
        int anchorTop=Math.max(0,oddsLine.cy()-300),anchorBottom=Math.min(sh,oddsLine.cy()+190);
        c.cropTop=Math.max(0,Math.min(ev.top-90,anchorTop));c.cropBottom=Math.min(sh,Math.max(ev.bottom+70,anchorBottom));
        if(c.cropBottom-c.cropTop>620)c.cropTop=Math.max(0,c.cropBottom-620);
        return c;
    }

    private EventPair findEventPair(List<OcrLine> lines,OcrLine odds,int sw,int sh){
        // Explicit "A vs B" text wins, but only if both halves pass strict competitor validation.
        for(OcrLine x:lines){if(Math.abs(x.cy()-odds.cy())>Math.max(360,sh/4))continue;String t=normalizeEvent(stripOdds(x.text));if(explicitEvent(t)&&validEvent(t))return EventPair.fromExplicit(t,x.box);}
        ArrayList<OcrLine> names=new ArrayList<>();
        for(OcrLine x:lines){
            if(Math.abs(x.cy()-odds.cy())>Math.max(240,sh/6))continue;
            if(x.box.top<sh*.20)continue; // never use the horizontal sports/category strip as a competitor
            if(x.box.left>sw*.62)continue; // competitors are normally left of the price columns
            String t=cleanCompetitor(stripScores(stripOdds(x.text)));if(!validCompetitor(t))continue;names.add(x);
        }
        EventPair best=null;double bestScore=1e9;
        for(int i=0;i<names.size();i++)for(int j=i+1;j<names.size();j++){
            OcrLine a=names.get(i),b=names.get(j);int gap=Math.abs(a.cy()-b.cy());if(gap<46||gap>150)continue;if(Math.abs(a.box.left-b.box.left)>125)continue;
            String sa=cleanCompetitor(stripScores(stripOdds(a.text))),sb=cleanCompetitor(stripScores(stripOdds(b.text)));if(similar(sa,sb)||likelyWrappedName(sa,sb,gap))continue;
            int top=Math.min(a.box.top,b.box.top),bottom=Math.max(a.box.bottom,b.box.bottom);if(odds.cy()<top-45||odds.cy()>bottom+70)continue;
            double score=Math.abs(((a.cy()+b.cy())/2.0)-odds.cy())+gap*.35+Math.abs(a.box.left-b.box.left)*.2;
            if(score<bestScore){bestScore=score;best=new EventPair(sa,sb,a,b);}
        }
        return best;
    }

    private OcrLine findSelectionLine(List<OcrLine> lines,OcrLine odds,EventPair pair,String price,int sw,int sh){
        String same=clean(removePrice(normalizeNums(odds.text),price));if(isSelectionToken(same))return new OcrLine(same,odds.box);
        OcrLine best=null;int bd=Integer.MAX_VALUE;
        for(OcrLine x:lines){int dy=Math.abs(x.cy()-odds.cy());if(dy>115)continue;String t=clean(stripOdds(normalizeNums(x.text)));if(t.isEmpty())continue;
            boolean token=isSelectionToken(t);boolean comp=validCompetitor(cleanCompetitor(stripScores(t)))&&(similar(t,pair.a)||similar(t,pair.b));if(!token&&!comp)continue;
            int dx=Math.abs(x.cx()-odds.cx());if(token&&dx>170)continue;if(comp&&dy>55)continue;int d=dy*3+dx;if(d<bd){bd=d;best=x;}
        }
        // For O/U grids the label is often directly above the price in the same column.
        if(best==null)for(OcrLine x:lines){if(x.cy()>=odds.cy()||odds.cy()-x.cy()>170)continue;if(Math.abs(x.cx()-odds.cx())>110)continue;String t=clean(stripOdds(normalizeNums(x.text)));if(isSelectionToken(t)){best=x;break;}}
        return best;
    }

    private OcrLine rowCompetitor(EventPair p,OcrLine odds){int da=Math.abs(p.la.cy()-odds.cy()),db=Math.abs(p.lb.cy()-odds.cy());int d=Math.min(da,db);return d<=70?(da<=db?p.la:p.lb):null;}

    private OcrLine findMarketLine(List<OcrLine> lines,OcrLine odds,OcrLine selection,int sh){OcrLine best=null;int br=-1;for(OcrLine x:lines){int dy=odds.cy()-x.cy();if(dy<-70||dy>Math.max(320,sh/5))continue;String t=clean(x.text);int r=marketRank(t);if(r<0)continue;r+=Math.max(0,8-dy/50);if(r>br){br=r;best=x;}}return best;}
    private int marketRank(String t){String l=clean(t).toLowerCase(Locale.US);if(PERIOD_ONLY.matcher(l).matches())return -1;if(!isMarket(t))return -1;int r=2;if(l.contains("set winner")||l.contains("game winner")||l.contains("round winner"))r+=5;if(l.contains("total")||l.contains("winner")||l.contains("moneyline")||l.contains("handicap")||l.contains("spread"))r+=3;if(l.contains("1st half")||l.contains("2nd half"))r+=2;return r;}

    private String inferMarket(String selection,String context,String sport){String l=(selection+" "+context).toLowerCase(Locale.US);String stage=stage(l);if(isOverUnder(l)){String noun="Total de puntos";if("Béisbol".equals(sport))noun="Total de carreras";else if("Fútbol".equals(sport)||"eSports".equals(sport))noun="Total";return noun+(stage.isEmpty()?periodSuffix(l):" • "+stage);}if(looksHandicap(selection)||l.contains("handicap")||l.contains("spread"))return "Hándicap"+(stage.isEmpty()?periodSuffix(l):" • "+stage);if(!stage.isEmpty())return "Ganador del "+stage.toLowerCase(Locale.US);return "Ganador del partido";}
    private String translateMarket(String t,String sport){String l=clean(t).toLowerCase(Locale.US);String stage=stage(l);if(l.contains("total")||l.contains("over")||l.contains("under")||l.contains("goals")||l.contains("runs")){String noun=l.contains("goals")?"Total de goles":l.contains("runs")||"Béisbol".equals(sport)?"Total de carreras":"Total de puntos";return noun+(stage.isEmpty()?periodSuffix(l):" • "+stage);}if(l.contains("handicap")||l.contains("spread"))return "Hándicap"+(stage.isEmpty()?periodSuffix(l):" • "+stage);if(l.contains("correct score"))return "Resultado exacto"+(stage.isEmpty()?periodSuffix(l):" • "+stage);if(l.contains("winner")||l.contains("moneyline")||l.contains("result")||l.contains("ganador"))return stage.isEmpty()?"Ganador del partido":"Ganador del "+stage.toLowerCase(Locale.US);return inferMarket("",l,sport);}
    private String periodSuffix(String l){if(l.contains("1st half")||l.contains("first half"))return " • 1.ª mitad";if(l.contains("2nd half")||l.contains("second half"))return " • 2.ª mitad";return "";}
    private String stage(String l){Matcher m=STAGE.matcher(l);if(m.find()){String w=m.group(0).toLowerCase(Locale.US);if(w.startsWith("game")||w.startsWith("juego"))return "Juego "+m.group(1);if(w.startsWith("round")||w.startsWith("ronda"))return "Ronda "+m.group(1);return "Set "+m.group(1);}return "";}
    private String translateSelection(String s){s=clean(normalizeNums(s));String l=s.toLowerCase(Locale.US);Matcher n=Pattern.compile("(?i)\\b(over|under)\\s*([+-]?\\d+(?:\\.\\d+)?)").matcher(s);if(n.find())return (n.group(1).equalsIgnoreCase("over")?"Más de ":"Menos de ")+n.group(2);if(l.matches("^o\\s*\\d.*"))return s.replaceFirst("(?i)^o\\s*","Más de ");if(l.matches("^u\\s*\\d.*"))return s.replaceFirst("(?i)^u\\s*","Menos de ");return cleanCompetitor(s);}

    private boolean valid(Candidate c){return c.implied>0&&c.implied<.995&&validEvent(c.event)&&!c.market.isEmpty()&&validSelection(c.selection)&&!looksLikeMarketAsEvent(c.event);}
    private Signal toSignal(Candidate c,long now){Signal s=new Signal();String base=Integer.toHexString((c.event+"|"+c.market+"|"+c.selection).toLowerCase(Locale.US).hashCode());s.baseId=base;s.id=base;s.sport=c.sport;s.event=c.event;s.market=c.market;s.selection=c.selection;s.odds=c.oddsText;s.screenState=c.screenState;s.implied=c.implied;s.targetX=c.x;s.targetY=c.y;s.cropTop=c.cropTop;s.cropBottom=c.cropBottom;s.live=c.live;s.createdAt=now;s.updatedAt=now;s.reason="Mercado y cuota leídos visualmente de la pantalla de Hard Rock.";return s;}
    private void dedupe(List<Candidate>a){HashSet<String>seen=new HashSet<>();a.removeIf(c->!seen.add((c.event+"|"+c.market+"|"+c.selection+"|"+c.oddsText).toLowerCase(Locale.US)));}

    private void maybeFindTarget(List<OcrLine> lines){String target=store.openTarget();if(target.isEmpty()||System.currentTimeMillis()-store.openTargetAt()>60000){if(!target.isEmpty())store.clearOpenTarget();return;}String[] p=target.split("(?i)\\s+vs\\s+",2);for(OcrLine l:lines){String t=l.text.toLowerCase(Locale.US);boolean ok=p.length==2?(containsName(t,p[0])||containsName(t,p[1])):containsName(t,target);if(ok&&!containsOdds(t)){store.clearOpenTarget();if(listener!=null)listener.onTargetFound(l.cx(),l.cy());return;}}}

    /** Resolve table-tennis markets from the visible set scoreboard. */
    private void resolveTableTennis(List<OcrLine> lines){
        List<Signal> pending=store.loadSignals();for(Signal s:pending){if(!"PENDIENTE".equals(s.status)||!s.sport.toLowerCase(Locale.US).contains("mesa"))continue;String[] p=s.event.split("(?i)\\s+vs\\s+",2);if(p.length!=2)continue;OcrLine a=findNameLine(lines,p[0]),b=findNameLine(lines,p[1]);if(a==null||b==null)continue;List<Integer> na=rowNumbers(lines,a),nb=rowNumbers(lines,b);if(na.isEmpty()||nb.isEmpty())continue;int setsA=na.get(0),setsB=nb.get(0);
            String ml=s.market.toLowerCase(Locale.US);if(ml.contains("ganador del partido")&&Math.max(setsA,setsB)>=3&&setsA!=setsB){String win=setsA>setsB?p[0]:p[1];resolveAuto(s,similar(win,s.selection)?"GANADA":"PERDIDA");continue;}
            Matcher sm=Pattern.compile("(?i)set\\s*(\\d+)").matcher(s.market);if(!sm.find())continue;int n;try{n=Integer.parseInt(sm.group(1));}catch(Exception e){continue;}if(na.size()<=n||nb.size()<=n)continue;int pa=na.get(n),pb=nb.get(n);if(!finishedSet(pa,pb))continue;
            if(ml.contains("ganador")){String win=pa>pb?p[0]:p[1];resolveAuto(s,similar(win,s.selection)?"GANADA":"PERDIDA");continue;}
            if(ml.contains("total")){Double line=selectionLineValue(s.selection);if(line==null)continue;double total=pa+pb;boolean over=s.selection.toLowerCase(Locale.US).contains("más");boolean under=s.selection.toLowerCase(Locale.US).contains("menos");if(!over&&!under)continue;if(Math.abs(total-line)<1e-9)resolveAuto(s,"PUSH");else resolveAuto(s,(over?total>line:total<line)?"GANADA":"PERDIDA");}
        }
    }
    private OcrLine findNameLine(List<OcrLine> lines,String name){String f=firstWord(name).toLowerCase(Locale.US);OcrLine best=null;for(OcrLine x:lines){String t=x.text.toLowerCase(Locale.US);if((!f.isEmpty()&&t.contains(f))||similar(x.text,name)){if(best==null||x.box.left<best.box.left)best=x;}}return best;}
    private List<Integer> rowNumbers(List<OcrLine> lines,OcrLine name){ArrayList<OcrLine> row=new ArrayList<>();for(OcrLine x:lines)if(Math.abs(x.cy()-name.cy())<=34&&x.box.left>=name.box.left)row.add(x);row.sort(Comparator.comparingInt(x->x.box.left));ArrayList<Integer> nums=new ArrayList<>();for(OcrLine x:row){String t=normalizeNums(x.text);if(DECIMAL.matcher(t).find()||AMERICAN.matcher(t).find())continue;Matcher m=INT_TOKEN.matcher(t);while(m.find()){try{int v=Integer.parseInt(m.group(1));if(v>=0&&v<=30)nums.add(v);}catch(Exception ignored){}}}return nums;}
    private boolean finishedSet(int a,int b){return Math.max(a,b)>=11&&Math.abs(a-b)>=2;}
    private Double selectionLineValue(String s){Matcher m=Pattern.compile("(\\d+(?:[.,]\\d+)?)").matcher(s);if(!m.find())return null;try{return Double.parseDouble(m.group(1).replace(',','.'));}catch(Exception e){return null;}}

    private void resolveCompletedScreen(List<OcrLine> lines,String all){
        String low=all.toLowerCase(Locale.US);
        boolean finished=low.contains("match completed")||low.contains("this game has ended")||low.contains("final whistle")||low.contains("finished")||low.contains("finalizado")||low.contains("completed")||low.contains("game has ended")||low.contains("terminado");
        if(!finished)return;
        FinalScore generic=findCompletedScore(lines);

        for(Signal s:store.loadSignals()){
            if(!"PENDIENTE".equals(s.status))continue;
            String[] p=s.event.split("(?i)\\s+vs\\s+",2);if(p.length!=2)continue;

            // Hard Rock often renders completed scoreboards as two rows:
            //   Cleveland Cavaliers   16 21 17 28 82
            //   Golden State Warriors 20 17 25 15 77
            // OCR therefore does not produce a single "Team 82 - Team 77" line. Resolve the
            // final total from the right-most integer on each participant row.
            FinalScore rowScore=findCompletedScoreForEvent(lines,p);
            FinalScore fs=(rowScore!=null?rowScore:generic);
            if(fs==null||!eventMatchesFinal(p,fs))continue;

            String ml=s.market==null?"":s.market.toLowerCase(Locale.US);
            String sl=s.selection==null?"":s.selection.toLowerCase(Locale.US);

            if(ml.contains("ganador del partido")||ml.equals("ganador")||ml.contains("moneyline")){
                if(fs.scoreA==fs.scoreB){resolveAuto(s,"PUSH");continue;}
                String winner=fs.scoreA>fs.scoreB?fs.a:fs.b;
                String selected=selectionSide(s.selection,p);if(selected.isEmpty())continue;
                String chosenFinal=matchSide(selected,fs.a,fs.b)==0?fs.a:fs.b;
                resolveAuto(s,similar(chosenFinal,winner)||abbr(chosenFinal).equals(abbr(winner))?"GANADA":"PERDIDA");
                continue;
            }

            // Full-game totals can be settled directly from the final score. Do not use this
            // for half/quarter/set markets because the final game total would be the wrong data.
            if(ml.contains("total")&&!ml.contains("mitad")&&!ml.contains("half")&&!ml.contains("quarter")&&!ml.contains("cuarto")&&!ml.contains("set")){
                Double line=selectionLineValue(s.selection);if(line==null)continue;
                boolean over=sl.contains("más")||sl.contains("mas")||sl.contains("over");
                boolean under=sl.contains("menos")||sl.contains("under");
                if(!over&&!under)continue;
                double total=fs.scoreA+fs.scoreB;
                if(Math.abs(total-line)<1e-9)resolveAuto(s,"PUSH");
                else resolveAuto(s,(over?total>line:total<line)?"GANADA":"PERDIDA");
                continue;
            }

            // Simple full-game handicap/spread. The selection must contain a participant and a
            // signed line, e.g. "Cleveland Cavaliers -3.5". Otherwise leave it pending.
            if((ml.contains("hándicap")||ml.contains("handicap")||ml.contains("spread"))&&!ml.contains("mitad")&&!ml.contains("half")&&!ml.contains("quarter")&&!ml.contains("set")){
                String chosen=selectionSide(s.selection,p);Double handicap=signedLineValue(s.selection);
                if(chosen.isEmpty()||handicap==null)continue;
                int side=matchSide(chosen,fs.a,fs.b);if(side<0)continue;
                double chosenScore=side==0?fs.scoreA:fs.scoreB;
                double otherScore=side==0?fs.scoreB:fs.scoreA;
                double adjusted=chosenScore+handicap;
                if(Math.abs(adjusted-otherScore)<1e-9)resolveAuto(s,"PUSH");
                else resolveAuto(s,adjusted>otherScore?"GANADA":"PERDIDA");
            }
        }
    }

    private FinalScore findCompletedScoreForEvent(List<OcrLine> lines,String[] p){
        OcrLine a=findNameLine(lines,p[0]),b=findNameLine(lines,p[1]);
        if(a==null||b==null)return null;
        Integer sa=rightMostFinalScore(lines,a),sb=rightMostFinalScore(lines,b);
        if(sa==null||sb==null)return null;
        // Reject implausible pairs caused by accidentally reading a quarter/header number.
        if(sa<0||sb<0||sa>500||sb>500)return null;
        return new FinalScore(p[0],p[1],sa,sb);
    }

    private Integer rightMostFinalScore(List<OcrLine> lines,OcrLine name){
        Integer best=null;int bestX=-1;
        for(OcrLine x:lines){
            if(Math.abs(x.cy()-name.cy())>42)continue;
            if(x.box.right<=name.box.left+20)continue;
            String t=clean(normalizeNums(x.text));
            // Decimal odds and clock strings are not final scores.
            if(DECIMAL.matcher(t).find()||AMERICAN.matcher(t).find()||t.matches(".*\\d{1,2}:\\d{2}.*"))continue;
            Matcher m=Pattern.compile("(?<![\\d.])(\\d{1,3})(?![\\d.])").matcher(t);
            Integer last=null;while(m.find()){try{int v=Integer.parseInt(m.group(1));if(v>=0&&v<=500)last=v;}catch(Exception ignored){}}
            if(last!=null&&x.box.right>bestX){best=last;bestX=x.box.right;}
        }
        return best;
    }

    private Double signedLineValue(String s){
        Matcher m=Pattern.compile("([+-]\\d+(?:[.,]\\d+)?)").matcher(s==null?"":s);
        if(!m.find())return null;try{return Double.parseDouble(m.group(1).replace(',','.'));}catch(Exception e){return null;}
    }

    private FinalScore findCompletedScore(List<OcrLine> lines){
        for(OcrLine l:lines){String t=clean(normalizeNums(l.text));Matcher m=COMPLETE_LEFT_SCORE.matcher(t);if(m.matches()){try{return new FinalScore(cleanCompetitor(m.group(2)),cleanCompetitor(m.group(3)),Integer.parseInt(m.group(1)),Integer.parseInt(m.group(4)));}catch(Exception ignored){}}m=COMPLETE_MID_SCORE.matcher(t);if(m.matches()){try{return new FinalScore(cleanCompetitor(m.group(1)),cleanCompetitor(m.group(3)),Integer.parseInt(m.group(2)),Integer.parseInt(m.group(4)));}catch(Exception ignored){}}}
        return null;
    }
    private boolean eventMatchesFinal(String[] p,FinalScore f){int a=matchSide(p[0],f.a,f.b),b=matchSide(p[1],f.a,f.b);return a>=0&&b>=0&&a!=b;}
    private int matchSide(String name,String a,String b){if(nameMatch(name,a))return 0;if(nameMatch(name,b))return 1;return -1;}
    private boolean nameMatch(String longName,String shown){String x=cleanCompetitor(longName),y=cleanCompetitor(shown);if(similar(x,y))return true;String ax=abbr(x),ay=abbr(y);return ax.length()>=3&&ax.equals(ay);}
    private String selectionSide(String selection,String[] p){if(nameMatch(selection,p[0]))return p[0];if(nameMatch(selection,p[1]))return p[1];return "";}
    private String abbr(String s){String x=cleanCompetitor(s).replaceAll("\\([^)]*\\)","").replaceAll("(?i)\\b(fc|cf|sc|club|team|esports?)\\b","").trim();String w=firstWord(x).replaceAll("[^A-Za-zÀ-ÿ]","").toUpperCase(Locale.US);return w.length()>=3?w.substring(0,3):w;}
    private void resolveAuto(Signal s,String status){if(store.setResultAuto(s.id,status)){store.setResultStatus("AUTO: "+s.event+" → "+status);if(listener!=null)listener.onResultResolved(s.event,status);}}


    private String inferSport(String page,EventPair pair,List<OcrLine> lines,OcrLine odds,int sh){String near=nearText(lines,odds,sh).toLowerCase(Locale.US);String ev=(pair.a+" "+pair.b).toLowerCase(Locale.US);if(near.contains("setka")||near.contains("tt cup")||near.contains("liga pro table"))return "Tenis de mesa";if(near.contains("utr pro tennis")||near.contains("atp ")||near.contains("wta "))return "Tenis";if(near.contains("ebasketball")||near.contains("esoccer")||near.contains("efootball")||near.contains("e-sports")||near.contains("esports")||((ev.contains("fc")||ev.contains("united")||ev.contains("city"))&&(ev.contains("(")&&ev.contains(")"))))return "eSports";return page;}
    private String detectSport(List<OcrLine> lines,int sh){
        String nav=store.navSport();if(!nav.isEmpty()&&System.currentTimeMillis()-store.navSportAt()<25000)return nav;
        StringBuilder body=new StringBuilder();for(OcrLine x:lines)if(x.box.top>sh*.20&&x.box.top<sh*.90)body.append(x.text).append(' ');String l=body.toString().toLowerCase(Locale.US);
        if(l.contains("setka")||l.contains("tt cup")||l.contains("liga pro table"))return "Tenis de mesa";
        if(l.contains("ebasketball")||l.contains("esoccer")||l.contains("efootball"))return "eSports";
        if(l.contains("utr pro tennis")||l.contains(" atp ")||l.contains(" wta "))return "Tenis";
        if(l.contains(" mlb ")||l.contains("american league")||l.contains("national league"))return "Béisbol";
        return "Deporte visible";
    }
    private boolean isConfirmedLiveScreen(List<OcrLine> lines,int sh){
        String all=join(lines).toLowerCase(Locale.US);
        // Event/detail screens can be recognized from live-specific status text.
        if(all.contains("stream now")||all.contains("1st set")||all.contains("2nd set")||all.contains("3rd set")||all.contains("4th set")
                ||all.contains("match completed")||all.contains("this game has ended"))return true;
        // IMPORTANT: merely seeing a "Live Now" card on Home is NOT enough.
        // The real Live hub has the Live Now title near the very top AND multiple sport tabs below it.
        boolean topLive=false;int sportTabs=0;
        for(OcrLine x:lines){
            String l=clean(x.text).toLowerCase(Locale.US);
            if((l.equals("live now")||l.equals("en vivo ahora"))&&x.box.top<sh*.18)topLive=true;
            if(x.box.top<sh*.30&&isSportTabText(l))sportTabs++;
        }
        return topLive&&sportTabs>=2;
    }
    private boolean nearLive(List<OcrLine> lines,OcrLine odds,int sh){String l=nearText(lines,odds,sh).toLowerCase(Locale.US);if(l.contains("streaming soon")||l.contains("tomorrow,"))return false;if(l.contains("stream now")||l.contains(" live ")||l.startsWith("live "))return true;return Pattern.compile("(?i)\\b\\d{1,2}\\s+(?:[A-Za-zÀ-ÿ().-]+\\s+){0,4}vs\\s+(?:[A-Za-zÀ-ÿ().-]+\\s+){0,4}\\d{1,2}\\b").matcher(l).find();}
    private String nearText(List<OcrLine> lines,OcrLine o,int sh){StringBuilder s=new StringBuilder();for(OcrLine x:lines)if(Math.abs(x.cy()-o.cy())<Math.max(260,sh/6))s.append(x.text).append(' ');return s.toString();}
    private String summarizeState(String context){
        String c=clean(context),l=c.toLowerCase(Locale.US);StringBuilder out=new StringBuilder();
        String st=stage(l);if(!st.isEmpty())out.append(st);
        Matcher sm=SCORE.matcher(c);int n=0;while(sm.find()&&n<2){if(out.length()>0)out.append(" • ");out.append("marcador ").append(sm.group(1)).append("-").append(sm.group(2));n++;}
        if(out.length()==0){if(l.contains("live"))out.append("LIVE visible");else out.append("sin marcador legible");}
        return out.toString();
    }

    private boolean explicitEvent(String t){return t.matches("(?i).+\\s+(?:vs\\.?|v\\.?|@|contra)\\s+.+")&&!t.contains("?");}
    private String normalizeEvent(String t){return clean(t).replaceAll("(?i)\\s+(?:v\\.?|@|contra)\\s+"," vs ").replaceAll("(?i)\\s+vs\\.?\\s+"," vs ");}
    private boolean validEvent(String e){String[] p=e.split("(?i)\\s+vs\\s+",2);return p.length==2&&validCompetitor(p[0])&&validCompetitor(p[1]);}
    private boolean looksLikeMarketAsEvent(String e){String l=e.toLowerCase(Locale.US);return l.matches(".*\\b(?:over|under|total|half|set|game|round|sgp)\\b.*")||OU_TOKEN.matcher(l.replace(" ","")).matches();}
    private boolean validCompetitor(String t){t=cleanCompetitor(t);if(t.length()<2||t.length()>55||containsOdds(t)||t.contains("?")||isSelectionToken(t)||PERIOD_ONLY.matcher(t).matches())return false;String l=t.toLowerCase(Locale.US);if(isSportTabText(l))return false;if(l.equals("tie")||l.equals("draw")||l.equals("empate")||l.equals("the draw"))return false;for(String z:JUNK)if(l.equals(z)||l.startsWith(z+" "))return false;if(l.matches(".*\\b(am|pm|edt|est|ct|pt)\\b.*")||l.matches("\\d{1,2}:\\d{2}.*"))return false;if(l.matches("^(?:o|u)\\s*\\d.*")||l.matches("^(?:over|under)\\s*\\d.*"))return false;if(l.matches("^(?:1st|2nd|3rd|4th)\\s+.*"))return false;return t.split("\\s+").length<=7&&containsLetter(t);}
    private boolean likelyWrappedName(String a,String b,int gap){
        if(gap>76)return false;
        String x=(a+" "+b).toLowerCase(Locale.US);
        return x.contains("(")||x.matches(".*\\b(?:fc|cf|sc|afc|united|city|town|club)\\b.*");
    }
    private void maybeScheduleResultCheck(long now,String screenSport){
        if(!store.paperActive())return;
        Signal locked=store.trackingSignal();
        if(locked!=null&&"PENDIENTE".equals(locked.status)){
            if(store.openTarget().isEmpty()&&now-lastResultSearch>5000){store.setOpenTarget(locked.event,locked.sport);lastResultSearch=now;}
            return;
        }
        if(!store.openTarget().isEmpty()||now-lastResultSearch<30000)return;
        Signal pick=null;
        for(Signal s:store.loadSignals()){
            if(!"PENDIENTE".equals(s.status)||!s.live||now-s.createdAt<45000)continue;
            long last=resultCheckAt.getOrDefault(s.id,0L);if(now-last<75000)continue;
            if(pick==null||s.createdAt<pick.createdAt)pick=s;
        }
        if(pick!=null){
            resultCheckAt.put(pick.id,now);lastResultSearch=now;
            store.setResultStatus("Buscando resultado: "+pick.event+" • "+pick.sport);
            store.setOpenTarget(pick.event,pick.sport);
        }
    }
    private boolean sameSport(String a,String b){
        String x=(a==null?"":a).toLowerCase(Locale.US),y=(b==null?"":b).toLowerCase(Locale.US);
        if(x.contains("mesa")&&y.contains("mesa"))return true;
        if(x.contains("esport")&&y.contains("esport"))return true;
        return !x.isEmpty()&&x.equals(y);
    }
    private void maybeEnterLive(List<OcrLine> lines,int sw,int sh,long now){
        if(listener==null||now-lastVisualLiveTap<1800)return;
        OcrLine best=null;
        for(OcrLine x:lines){
            String l=clean(x.text).toLowerCase(Locale.US);
            // Only the real section label. Generic LIVE badges appear everywhere inside events.
            if(!(l.equals("live now")||l.equals("en vivo ahora")))continue;
            // On the real Live page the title is at the very top. Home's Live Now card can
            // start a little higher on some Samsung layouts, so keep a wider safe band.
            if(x.box.top<sh*.10)continue;
            // The Home Live Now label must be in the content column, never the far-right
            // search/header area. The accessibility service enforces the same safety gate.
            if(x.cx()>sw*.76||x.box.top>sh*.88)continue;
            if(best==null||x.box.top<best.box.top)best=x;
        }
        if(best!=null){listener.onNavigateTap(best.cx(),best.cy(),"__LIVE__");lastVisualLiveTap=now;}
    }

    private void maybeRotateVisualSports(List<OcrLine> lines,int sw,int sh,long now,boolean screenLive){
        if(!screenLive||!store.dedicated()||!store.openTarget().isEmpty())return;
        // Once we deliberately enter Table Tennis/eSports, stay there long enough to scan
        // the whole vertical list. Previously Vision clicked another sport every ~6.5s.
        String nav=store.navSport(); long navAge=now-store.navSportAt(); String nl=nav==null?"":nav.toLowerCase(Locale.US);
        long hold=nl.contains("mesa")?90000:(nl.contains("esport")?60000:0);
        if(hold>0&&navAge<hold)return;
        if(now-lastVisualNav<3500)return;
        String wanted=VISUAL_SPORTS[visualSportIndex++%VISUAL_SPORTS.length];
        OcrLine found=null;
        for(OcrLine x:lines){if(x.box.top>sh*.24)continue;String t=clean(x.text);if(t.equalsIgnoreCase(wanted)){found=x;break;}if(wanted.equalsIgnoreCase("eSports")&&(t.equalsIgnoreCase("E-Sports")||t.equalsIgnoreCase("Esports"))){found=x;break;}if(wanted.equalsIgnoreCase("MLB")&&(t.equalsIgnoreCase("Baseball")||t.equalsIgnoreCase("MLB"))){found=x;break;}}
        if(found!=null&&listener!=null){listener.onNavigateTap(found.cx(),found.cy(),wanted);lastVisualNav=now;return;}
        if(listener!=null&&now-lastVisualSwipe>3000){listener.onSportBarSwipe((visualSportIndex%2)==0);lastVisualSwipe=now;}
        lastVisualNav=now;
    }
    private String canonicalSport(String s){String l=s==null?"":s.toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong"))return "Tenis de mesa";if(l.contains("sport"))return "eSports";if(l.equals("mlb")||l.contains("baseball"))return "Béisbol";if(l.contains("basketball"))return "Baloncesto";if(l.contains("soccer"))return "Fútbol";if(l.equals("tennis"))return "Tenis";if(l.contains("hockey"))return "Hockey";if(l.contains("football"))return "Fútbol americano";if(l.contains("pga")||l.contains("golf"))return "Golf";return s;}
    private boolean isSportTabText(String l){return l.equals("table tennis")||l.equals("ping pong")||l.equals("e-sports")||l.equals("esports")||l.equals("basketball")||l.equals("soccer")||l.equals("tennis")||l.equals("baseball")||l.equals("mlb")||l.equals("hockey")||l.equals("football")||l.equals("nfl")||l.equals("pga")||l.equals("golf");}

    private String cleanCompetitor(String t){return clean(t).replaceAll("(?i)^(live|en vivo)\\s*[-•:]?\\s*","").replaceAll("(?:\\s+\\d{1,2}){1,8}$","");}
    private boolean validSelection(String t){t=clean(t);if(t.isEmpty()||t.length()>65||containsOdds(t)||t.contains("?"))return false;String l=t.toLowerCase(Locale.US);for(String z:JUNK)if(l.equals(z))return false;return validCompetitor(t)||isSelectionToken(t);}
    private boolean isSelectionToken(String t){String x=clean(normalizeNums(t));if(x.isEmpty())return false;String l=x.toLowerCase(Locale.US);if(OU_TOKEN.matcher(l).matches())return true;if(LINE_TOKEN.matcher(l).matches())return true;if(l.matches("^(?:over|under|más de|menos de)\\s*\\d+(?:\\.\\d+)?$"))return true;return false;}
    private boolean isMarket(String t){String l=clean(t).toLowerCase(Locale.US);for(String x:MARKET_WORDS)if(l.contains(x))return true;return false;}
    private boolean isOverUnder(String t){String l=clean(t).toLowerCase(Locale.US);return l.contains("over")||l.contains("under")||l.contains("más de")||l.contains("menos de")||l.matches(".*\\b[ou]\\s*\\d+(?:[.,]\\d+)?.*");}
    private boolean looksHandicap(String t){String x=stripOdds(t);return Pattern.compile("(?<!\\d)[+-]\\d+(?:[.,]\\d+)(?!\\d)").matcher(x).find();}
    private String removePrice(String t,String price){return clean(t.replaceFirst(Pattern.quote(price),""));}
    private String stripOdds(String t){String n=normalizeNums(t);return clean(DECIMAL.matcher(AMERICAN.matcher(n).replaceAll("")).replaceAll(""));}
    private String stripScores(String t){return clean(SCORE.matcher(t).replaceAll(""));}
    private boolean containsOdds(String t){String n=normalizeNums(t);return AMERICAN.matcher(n).find()||DECIMAL.matcher(n).find();}
    private String normalizeNums(String t){return t==null?"":t.replace(',', '.');}
    private boolean containsLetter(String t){for(char c:t.toCharArray())if(Character.isLetter(c))return true;return false;}
    private boolean similar(String a,String b){String x=clean(a).toLowerCase(Locale.US),y=clean(b).toLowerCase(Locale.US);if(x.isEmpty()||y.isEmpty())return false;return x.equals(y)||x.contains(y)||y.contains(x)||(!firstWord(x).isEmpty()&&firstWord(x).equals(firstWord(y)));}
    private boolean containsName(String hay,String name){String n=clean(name).toLowerCase(Locale.US);return hay.contains(n)||(!firstWord(n).isEmpty()&&hay.contains(firstWord(n)));}
    private String firstWord(String s){String[] a=clean(s).split("\\s+");return a.length==0?"":a[0].replaceAll("[^A-Za-zÀ-ÿ0-9._-]","");}
    private String clean(String t){return t==null?"":t.replace('\n',' ').replaceAll("\\s+"," ").trim();}
    private String join(Collection<OcrLine>a){StringBuilder s=new StringBuilder();for(OcrLine x:a)s.append(x.text).append('\n');return s.toString();}
    private String fmt(double d){return String.format(Locale.US,"%.1f",d);}

    private static class FinalScore{String a,b;int scoreA,scoreB;FinalScore(String a,String b,int scoreA,int scoreB){this.a=a;this.b=b;this.scoreA=scoreA;this.scoreB=scoreB;}}
    private static class Candidate{String oddsText="",sport="",event="",market="",selection="",screenState="";double implied=0;int x=0,y=0,cropTop=0,cropBottom=0;boolean live=false;}
    private static class EventPair{String a,b;OcrLine la,lb;Rect box;EventPair(String a,String b,OcrLine la,OcrLine lb){this.a=a;this.b=b;this.la=la;this.lb=lb;box=new Rect(la.box);box.union(lb.box);}static EventPair fromExplicit(String e,Rect r){String[]p=e.split("(?i)\\s+vs\\s+",2);OcrLine l=new OcrLine(p[0],r),q=new OcrLine(p[1],r);return new EventPair(p[0],p[1],l,q);}}
}
