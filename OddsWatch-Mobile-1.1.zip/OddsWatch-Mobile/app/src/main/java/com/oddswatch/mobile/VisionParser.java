package com.oddswatch.mobile;

import android.graphics.Rect;
import java.util.*;
import java.util.regex.*;

public class VisionParser {
    public interface Listener { void onSignal(Signal s); void onObservedChanged(); void onTargetFound(int x,int y); void onHighlight(int x,int y,String label,boolean test); }
    private final Store store; private final Listener listener;
    private final Map<String,Double> previousImplied=new HashMap<>();
    private final Map<String,Long> lastSignalAt=new HashMap<>();

    private static final Pattern AMERICAN=Pattern.compile("(?<!\\d)([+-](?:100|[1-9]\\d{2,3}))(?!\\d)");
    // Hard Rock commonly shows decimal prices such as 1.45 / 2.60. Requiring two decimals avoids confusing most +/-0.5 line values with prices.
    private static final Pattern DECIMAL=Pattern.compile("(?<![\\d.])((?:1|[2-9]|[1-9]\\d)\\.\\d{2})(?!\\d)");
    private static final Pattern SCORE=Pattern.compile("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)");
    private static final String[] MARKET_WORDS={"winner","moneyline","ganador","match result","set winner","game winner","round winner","total","points","puntos","over","under","más de","menos de","handicap","hándicap","spread","correct score","resultado exacto","set","game","round","juego","ronda"};
    private static final String[] JUNK={"live","en vivo","bet slip","betslip","popular","all sports","sports","search","promos","my bets","cash out","login","sign in","same game","parlay","boost","odds","more wagers","show more","league","cup","tournament","today","tomorrow","stream","watch"};

    public VisionParser(Store s,Listener l){store=s;listener=l;}

    public synchronized void ingest(List<OcrLine> raw,int screenW,int screenH){
        long now=System.currentTimeMillis();
        ArrayList<OcrLine> lines=new ArrayList<>();
        for(OcrLine x:raw)if(x!=null&&!clean(x.text).isEmpty())lines.add(new OcrLine(clean(x.text),x.box));
        lines.sort((a,b)->{int d=Integer.compare(a.box.top,b.box.top);return d!=0?d:Integer.compare(a.box.left,b.box.left);});
        store.setLastOcr(now);store.setLinesSeen(lines.size());
        String all=join(lines);String sport=detectSport(all);store.setCurrentSport(sport);
        maybeFindTarget(lines);

        ArrayList<Candidate> candidates=new ArrayList<>();
        for(int i=0;i<lines.size();i++){
            OcrLine l=lines.get(i);
            collectOdds(lines,i,l,AMERICAN,true,sport,screenW,screenH,candidates);
            collectOdds(lines,i,l,DECIMAL,false,sport,screenW,screenH,candidates);
        }
        dedupe(candidates);
        store.setMarketsSeen(candidates.size());

        if(store.consumeTestHighlight()&&!candidates.isEmpty()&&listener!=null){Candidate t=candidates.get(0);listener.onHighlight(t.x,t.y,"PRUEBA • "+t.selection+"  "+t.oddsText,true);}

        for(Candidate c:candidates){
            Signal observed=toSignal(c,now);store.upsertObserved(observed);
            String key=observed.baseId;
            double prev=previousImplied.containsKey(key)?previousImplied.get(key):Double.NaN;
            previousImplied.put(key,c.implied);
            if(Double.isNaN(prev)||Math.abs(prev-c.implied)<0.000001)continue;

            double move=c.implied-prev; // positive = market price moved toward this selection
            if(move<store.movementThreshold())continue;
            long last=lastSignalAt.getOrDefault(key,0L);if(now-last<60000)continue;
            if(store.paperActive()&&store.hasOpenPaper(key))continue; // one open paper bet per exact selection

            Signal s=toSignal(c,now);
            s.movement=move;boolean strong=move>=0.010;
            s.score=Math.min(99,(strong?74:58)+move*100*8);
            s.reason=(strong?"SEÑAL FUERTE":"SEÑAL DE PRUEBA")+": la probabilidad implícita visible subió de "+fmt(prev*100)+"% a "+fmt(c.implied*100)+"% (+"+fmt(move*100)+" pp). Se registra ANTES del resultado para medir el rendimiento real de la estrategia.";
            s.id=key+"-"+(now/60000);s.createdAt=now;s.updatedAt=now;s.status="PENDIENTE";

            if(store.paperActive()){
                if(!store.canPaperBet()){store.incrementPaperSkipped();continue;}
                s.paper=true;s.sessionId=store.paperSessionId();s.stake=store.paperStake();s.potentialProfit=Models.profitForStake(s.odds,s.stake);
                s.reason="🧪 APUESTA VIRTUAL • "+s.reason+" Stake virtual "+Models.money(s.stake)+"; no toca ni coloca apuestas reales.";
            }

            lastSignalAt.put(key,now);store.upsertSignal(s);if(listener!=null)listener.onSignal(s);
        }
        tryResolve(all);
        if(listener!=null)listener.onObservedChanged();
    }

    private void collectOdds(List<OcrLine> lines,int idx,OcrLine l,Pattern p,boolean american,String sport,int sw,int sh,List<Candidate> out){
        Matcher m=p.matcher(l.text);
        while(m.find()){
            String price=m.group(1);double implied=Models.impliedFromOdds(price);if(implied<=0||implied>=0.995)continue;
            // Decimal prices above 15.00 are unusual for the intended live scanner and create OCR false positives.
            if(!american){try{double d=Double.parseDouble(price);if(d>15.0)continue;}catch(Exception e){continue;}}
            Candidate c=buildCandidate(lines,idx,l,price,implied,sport,sw,sh);
            if(c!=null&&valid(c))out.add(c);
        }
    }

    private Candidate buildCandidate(List<OcrLine> lines,int idx,OcrLine oddsLine,String oddsText,double implied,String sport,int sw,int sh){
        Candidate c=new Candidate();c.oddsText=oddsText;c.implied=implied;c.sport=sport;c.x=oddsLine.cx();c.y=oddsLine.cy();
        String same=clean(removePrice(oddsLine.text,oddsText));
        if(validSelection(same))c.selection=translateSelection(same);
        ArrayList<OcrLine> near=new ArrayList<>();
        for(OcrLine x:lines){int dy=Math.abs(x.cy()-oddsLine.cy());if(dy<=Math.max(90,sh/12)&&horizontalClose(x.box,oddsLine.box,sw))near.add(x);}
        if(c.selection.isEmpty()){
            OcrLine best=null;int bd=Integer.MAX_VALUE;
            for(OcrLine x:near){String t=stripOdds(x.text);if(!validSelection(t))continue;int d=Math.abs(x.cy()-oddsLine.cy())+Math.abs(x.cx()-oddsLine.cx())/3;if(d<bd){bd=d;best=x;}}
            if(best!=null)c.selection=translateSelection(stripOdds(best.text));
        }
        ArrayList<OcrLine> above=new ArrayList<>();int maxUp=Math.max(440,sh/3);
        for(int j=idx-1;j>=0;j--){OcrLine x=lines.get(j);if(oddsLine.box.top-x.box.bottom>maxUp)break;if(Math.abs(x.cx()-oddsLine.cx())<sw*0.48)above.add(x);}
        c.market=findMarket(near,above,c.selection);
        c.event=findEvent(lines,above,near,c.selection,oddsLine,sw,sh);
        if(c.market.isEmpty())c.market=inferMarket(c.selection,join(near));
        return c;
    }

    private String findEvent(List<OcrLine> all,List<OcrLine> above,List<OcrLine> near,String selection,OcrLine oddsLine,int sw,int sh){
        for(OcrLine x:above){String t=clean(stripOdds(x.text));if(explicitEvent(t))return normalizeEvent(t);}
        for(OcrLine x:near){String t=clean(stripOdds(x.text));if(explicitEvent(t))return normalizeEvent(t);}
        ArrayList<NameLine> names=new ArrayList<>();
        for(OcrLine x:all){
            if(x.box.bottom>oddsLine.box.bottom+Math.max(90,sh/18))continue;
            if(oddsLine.box.top-x.box.top>Math.max(500,sh/2))continue;
            if(Math.abs(x.cx()-oddsLine.cx())>sw*0.48)continue;
            String t=cleanCompetitor(stripScores(stripOdds(x.text)));
            if(!validCompetitor(t)||isMarket(t)||similar(t,selection))continue;
            names.add(new NameLine(t,Math.abs(oddsLine.cy()-x.cy())));
        }
        names.sort(Comparator.comparingInt(a->a.d));LinkedHashSet<String> unique=new LinkedHashSet<>();
        if(validCompetitor(selection)&&!isOverUnder(selection)&&!looksHandicap(selection))unique.add(cleanCompetitor(selection));
        for(NameLine n:names){unique.add(n.s);if(unique.size()>=4)break;}
        if(unique.size()>=2){Iterator<String> it=unique.iterator();return it.next()+" vs "+it.next();}
        return "";
    }

    private String findMarket(List<OcrLine> near,List<OcrLine> above,String selection){
        String best="";int rank=-1;
        for(OcrLine x:near){String t=clean(stripOdds(x.text));int r=marketRank(t);if(r>rank){rank=r;best=t;}}
        for(OcrLine x:above){String t=clean(stripOdds(x.text));int r=marketRank(t);if(r>rank){rank=r;best=t;}}
        if(rank<0)return inferMarket(selection,join(near));return translateMarket(best);
    }

    private int marketRank(String t){String l=t.toLowerCase(Locale.US);if(!isMarket(t))return -1;int r=1;if(l.contains("set")||l.contains("game")||l.contains("round")||l.contains("juego")||l.contains("ronda"))r+=3;if(l.contains("total")||l.contains("over")||l.contains("under")||l.contains("handicap")||l.contains("hándicap")||l.contains("winner")||l.contains("ganador"))r+=2;return r;}
    private String inferMarket(String selection,String context){String l=(selection+" "+context).toLowerCase(Locale.US);String stage=stage(l);if(isOverUnder(l))return "Total de puntos"+(stage.isEmpty()?"":" • "+stage);if(l.contains("handicap")||l.contains("hándicap")||looksHandicap(selection))return "Hándicap"+(stage.isEmpty()?"":" • "+stage);if(l.contains("correct score")||l.contains("resultado exacto"))return "Resultado exacto"+(stage.isEmpty()?"":" • "+stage);if(!stage.isEmpty())return "Ganador del "+stage.toLowerCase(Locale.US);return "Ganador del partido";}
    private String translateMarket(String t){String l=t.toLowerCase(Locale.US);String stage=stage(l);if(l.contains("total")||l.contains("over")||l.contains("under"))return "Total de puntos"+(stage.isEmpty()?"":" • "+stage);if(l.contains("handicap")||l.contains("spread")||l.contains("hándicap"))return "Hándicap"+(stage.isEmpty()?"":" • "+stage);if(l.contains("correct score"))return "Resultado exacto"+(stage.isEmpty()?"":" • "+stage);if(l.contains("winner")||l.contains("moneyline")||l.contains("ganador"))return stage.isEmpty()?"Ganador del partido":"Ganador del "+stage.toLowerCase(Locale.US);return clean(t);}
    private String stage(String l){Matcher m=Pattern.compile("(?i)(?:set|game|round|juego|ronda)\\s*(\\d+)").matcher(l);if(m.find()){String w=m.group(0).toLowerCase(Locale.US);if(w.startsWith("game")||w.startsWith("juego"))return "Juego "+m.group(1);if(w.startsWith("round")||w.startsWith("ronda"))return "Ronda "+m.group(1);return "Set "+m.group(1);}return "";}
    private String translateSelection(String s){String l=s.toLowerCase(Locale.US);Matcher n=Pattern.compile("(?i)\\b(over|under)\\s*([+-]?\\d+(?:\\.\\d+)?)").matcher(s);if(n.find())return (n.group(1).equalsIgnoreCase("over")?"Más de ":"Menos de ")+n.group(2);if(l.matches("^o\\s*\\d.*"))return s.replaceFirst("(?i)^o\\s*","Más de ");if(l.matches("^u\\s*\\d.*"))return s.replaceFirst("(?i)^u\\s*","Menos de ");return clean(s);}

    private boolean valid(Candidate c){return c.implied>0&&c.implied<.995&&validEvent(c.event)&&!c.market.isEmpty()&&validSelection(c.selection);}
    private Signal toSignal(Candidate c,long now){Signal s=new Signal();String base=Integer.toHexString((c.event+"|"+c.market+"|"+c.selection).toLowerCase(Locale.US).hashCode());s.baseId=base;s.id=base;s.sport=c.sport;s.event=c.event;s.market=c.market;s.selection=c.selection;s.odds=c.oddsText;s.implied=c.implied;s.targetX=c.x;s.targetY=c.y;s.createdAt=now;s.updatedAt=now;s.reason="Mercado y cuota leídos visualmente de la pantalla de Hard Rock.";return s;}
    private void dedupe(List<Candidate>a){HashSet<String>seen=new HashSet<>();a.removeIf(c->!seen.add((c.event+"|"+c.market+"|"+c.selection+"|"+c.oddsText).toLowerCase(Locale.US)));}

    private void maybeFindTarget(List<OcrLine> lines){String target=store.openTarget();if(target.isEmpty()||System.currentTimeMillis()-store.openTargetAt()>60000){if(!target.isEmpty())store.clearOpenTarget();return;}String[] p=target.split("(?i)\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2);for(OcrLine l:lines){String t=l.text.toLowerCase(Locale.US);boolean ok=p.length==2?(containsName(t,p[0])||containsName(t,p[1])):containsName(t,target);if(ok&&!containsOdds(t)){store.clearOpenTarget();if(listener!=null)listener.onTargetFound(l.cx(),l.cy());return;}}}
    private boolean containsName(String hay,String name){String n=clean(name).toLowerCase(Locale.US);if(n.length()>10)n=n.substring(0,Math.min(n.length(),18));return hay.contains(n)||(!firstWord(n).isEmpty()&&hay.contains(firstWord(n)));}

    // Automatic settlement is intentionally conservative: only winner markets are resolved when a visible FINAL area contains both competitors and a small match score such as 3-1 / 2-0.
    private void tryResolve(String all){
        String low=all.toLowerCase(Locale.US);
        if(!(low.contains("final")||low.contains("finished")||low.contains("finalizado")))return;
        List<Signal> list=store.loadSignals();
        for(Signal s:list){
            if(!"PENDIENTE".equals(s.status)||!s.market.toLowerCase(Locale.US).contains("ganador"))continue;
            String[] p=s.event.split("(?i)\\s+vs\\s+",2);if(p.length!=2)continue;
            String n1=firstWord(p[0]).toLowerCase(Locale.US),n2=firstWord(p[1]).toLowerCase(Locale.US);if(n1.isEmpty()||n2.isEmpty())continue;
            int i1=low.indexOf(n1),i2=low.indexOf(n2);if(i1<0||i2<0)continue;
            int from=Math.max(0,Math.min(i1,i2)-80),to=Math.min(all.length(),Math.max(i1,i2)+220);String zone=all.substring(from,to);
            Matcher sm=SCORE.matcher(zone);boolean done=false;
            while(sm.find()){
                try{int a=Integer.parseInt(sm.group(1)),b=Integer.parseInt(sm.group(2));if(a==b||a>5||b>5)continue;String winner=a>b?p[0]:p[1];store.setResult(s.id,similar(winner,s.selection)?"GANADA":"PERDIDA");done=true;break;}catch(Exception ignored){}
            }
            if(done)continue;
        }
    }

    private String detectSport(String all){String l=all.toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong")||l.contains("tenis de mesa"))return "Tenis de mesa";if(l.contains("esports")||l.contains("e-sports")||l.contains("ebasketball")||l.contains("esoccer")||l.contains("efootball"))return "eSports";if(l.contains("basketball"))return "Baloncesto";if(l.contains("soccer")||l.contains("football"))return "Fútbol";if(l.contains("tennis"))return "Tenis";if(l.contains("baseball"))return "Béisbol";if(l.contains("hockey"))return "Hockey";if(l.contains("volleyball"))return "Voleibol";if(l.contains("darts"))return "Dardos";if(l.contains("mma")||l.contains("ufc"))return "MMA";return "Deporte visible";}
    private boolean explicitEvent(String t){return t.matches("(?i).+\\s+(?:vs\\.?|v\\.?|@|contra)\\s+.+")&&!t.contains("?");}
    private String normalizeEvent(String t){return clean(t).replaceAll("(?i)\\s+(?:v\\.?|@|contra)\\s+"," vs ").replaceAll("(?i)\\s+vs\\.?\\s+"," vs ");}
    private boolean validEvent(String e){String[] p=e.split("(?i)\\s+vs\\s+",2);return p.length==2&&validCompetitor(p[0])&&validCompetitor(p[1]);}
    private boolean validCompetitor(String t){t=cleanCompetitor(t);if(t.length()<2||t.length()>55||isMarket(t)||containsOdds(t)||t.contains("?"))return false;String l=t.toLowerCase(Locale.US);for(String z:JUNK)if(l.equals(z)||l.startsWith(z+" "))return false;if(t.matches(".*\\b(am|pm)\\b.*")||t.matches("\\d{1,2}:\\d{2}.*"))return false;return t.split("\\s+").length<=7&&containsLetter(t);}
    private String cleanCompetitor(String t){return clean(t).replaceAll("(?i)^(live|en vivo)\\s*[-•:]?\\s*","").replaceAll("\\s+\\d{1,2}$","");}
    private boolean validSelection(String t){t=clean(t);if(t.isEmpty()||t.length()>65||containsOdds(t)||t.contains("?"))return false;String l=t.toLowerCase(Locale.US);for(String z:JUNK)if(l.equals(z))return false;return containsLetter(t)||isOverUnder(t)||looksHandicap(t);}
    private boolean isMarket(String t){String l=t.toLowerCase(Locale.US);for(String x:MARKET_WORDS)if(l.contains(x))return true;return false;}
    private boolean isOverUnder(String t){String l=t.toLowerCase(Locale.US);return l.contains("over")||l.contains("under")||l.contains("más de")||l.contains("menos de")||l.matches(".*\\b[ou]\\s*\\d+(?:\\.\\d+)?.*");}
    private boolean looksHandicap(String t){String x=stripOdds(t);Matcher m=Pattern.compile("(?<!\\d)[+-]\\d+(?:\\.\\d+)(?!\\d)").matcher(x);return m.find();}
    private String removePrice(String t,String price){return clean(t.replaceFirst(Pattern.quote(price),""));}
    private String stripOdds(String t){return clean(DECIMAL.matcher(AMERICAN.matcher(t).replaceAll("")).replaceAll(""));}
    private String stripScores(String t){return clean(SCORE.matcher(t).replaceAll(""));}
    private boolean containsOdds(String t){return AMERICAN.matcher(t).find()||DECIMAL.matcher(t).find();}
    private boolean horizontalClose(Rect a,Rect b,int sw){return Math.abs(a.centerX()-b.centerX())<sw*.42||overlap(a.left,a.right,b.left,b.right)>0;}
    private int overlap(int a1,int a2,int b1,int b2){return Math.max(0,Math.min(a2,b2)-Math.max(a1,b1));}
    private boolean containsLetter(String t){for(char c:t.toCharArray())if(Character.isLetter(c))return true;return false;}
    private boolean similar(String a,String b){String x=clean(a).toLowerCase(Locale.US),y=clean(b).toLowerCase(Locale.US);return x.equals(y)||x.contains(y)||y.contains(x)||(!firstWord(x).isEmpty()&&firstWord(x).equals(firstWord(y)));}
    private String firstWord(String s){String[] a=clean(s).split("\\s+");return a.length==0?"":a[0].replaceAll("[^A-Za-zÀ-ÿ0-9._-]","");}
    private String clean(String t){return t==null?"":t.replace('\n',' ').replaceAll("\\s+"," ").trim();}
    private String join(Collection<OcrLine>a){StringBuilder s=new StringBuilder();for(OcrLine x:a)s.append(x.text).append('\n');return s.toString();}
    private String fmt(double d){return String.format(Locale.US,"%.1f",d);}

    private static class Candidate{String oddsText="",sport="",event="",market="",selection="";double implied=0;int x=0,y=0;}
    private static class NameLine{String s;int d;NameLine(String s,int d){this.s=s;this.d=d;}}
}
