package com.oddswatch.mobile;

import android.graphics.Rect;
import java.util.*;
import java.util.regex.*;

/**
 * Geometry-first parser for the Hard Rock screen.
 * It deliberately refuses to create a signal unless it can identify two real
 * competitors, a market/selection and a price. This avoids OCR strings such as
 * "U 8.5", "1st Half" or "SGP" becoming fake team names.
 */
public class VisionParser {
    public interface Listener { void onSignal(Signal s); void onObservedChanged(); void onTargetFound(int x,int y); void onHighlight(int x,int y,String label,boolean test); }
    private final Store store; private final Listener listener;
    private final Map<String,Double> previousImplied=new HashMap<>();
    private final Map<String,Long> lastSignalAt=new HashMap<>(), lastSeenAt=new HashMap<>();
    private final Map<String,Integer> stableSeen=new HashMap<>();

    private static final Pattern AMERICAN=Pattern.compile("(?<!\\d)([+-](?:100|[1-9]\\d{2,3}))(?!\\d)");
    private static final Pattern DECIMAL=Pattern.compile("(?<![\\d.])((?:1|[2-9]|[1-9]\\d)\\.\\d{2})(?!\\d)");
    private static final Pattern SCORE=Pattern.compile("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)");
    private static final Pattern STAGE=Pattern.compile("(?i)(?:set|game|round|juego|ronda)\\s*(\\d+)");
    private static final Pattern PERIOD_ONLY=Pattern.compile("(?i)^(?:1st|2nd|3rd|4th|first|second|third|fourth)\\s+(?:half|quarter|period|set|game|round)$");
    private static final Pattern OU_TOKEN=Pattern.compile("(?i)^(?:o|u|over|under|más de|menos de)\\s*\\d+(?:[.,]\\d+)?$");
    private static final Pattern LINE_TOKEN=Pattern.compile("^[+-]\\d+(?:[.,]\\d+)?$");
    private static final Pattern INT_TOKEN=Pattern.compile("(?<!\\d)(\\d{1,2})(?![\\d.])");

    private static final String[] MARKET_WORDS={"winner","moneyline","ganador","match result","result","set winner","game winner","round winner","total","goals","runs","points","puntos","over","under","más de","menos de","handicap","hándicap","spread","correct score","resultado exacto","1st half total","2nd half total"};
    private static final String[] JUNK={"live","live now","en vivo","bet slip","betslip","popular","all sports","sports","search","promos","my bets","cash out","login","sign in","same game","parlay","boost","odds","more wagers","show more","league","cup","tournament","today","tomorrow","stream","stream now","watch","sgp","account","home","discover","games"};

    public VisionParser(Store s,Listener l){store=s;listener=l;}

    public synchronized void ingest(List<OcrLine> raw,int screenW,int screenH){
        long now=System.currentTimeMillis();
        ArrayList<OcrLine> lines=new ArrayList<>();
        for(OcrLine x:raw)if(x!=null&&!clean(x.text).isEmpty())lines.add(new OcrLine(clean(x.text),x.box));
        lines.sort((a,b)->{int d=Integer.compare(a.box.top,b.box.top);return d!=0?d:Integer.compare(a.box.left,b.box.left);});
        store.setLastOcr(now);store.setLinesSeen(lines.size());
        String all=join(lines);String screenSport=detectSport(lines,screenH);store.setCurrentSport(screenSport);
        boolean screenLive=isLiveScreen(all);
        maybeFindTarget(lines);

        ArrayList<Candidate> candidates=new ArrayList<>();
        for(int i=0;i<lines.size();i++){
            OcrLine l=lines.get(i);
            collectOdds(lines,i,l,AMERICAN,true,screenSport,screenLive,screenW,screenH,candidates);
            collectOdds(lines,i,l,DECIMAL,false,screenSport,screenLive,screenW,screenH,candidates);
        }
        dedupe(candidates);store.setMarketsSeen(candidates.size());

        if(store.consumeTestHighlight()&&!candidates.isEmpty()&&listener!=null){Candidate t=candidates.get(0);listener.onHighlight(t.x,t.y,"PRUEBA • "+t.selection+"  "+t.oddsText,true);}

        for(Candidate c:candidates){
            Signal observed=toSignal(c,now);store.upsertObserved(observed);
            String key=observed.baseId;
            long prevAt=lastSeenAt.getOrDefault(key,0L);int stable=(now-prevAt<2600)?stableSeen.getOrDefault(key,0)+1:1;stableSeen.put(key,stable);lastSeenAt.put(key,now);
            if(stable<2)continue; // require two consecutive frames with the same event identity

            double prev=previousImplied.containsKey(key)?previousImplied.get(key):Double.NaN;
            previousImplied.put(key,c.implied);
            if(Double.isNaN(prev)||Math.abs(prev-c.implied)<0.000001)continue;
            double move=c.implied-prev;
            if(move<store.movementThreshold())continue;
            long last=lastSignalAt.getOrDefault(key,0L);if(now-last<45000)continue;
            if(store.paperActive()&&store.hasOpenPaper(key))continue;

            Signal s=toSignal(c,now);s.movement=move;boolean strong=move>=0.008;
            s.score=Math.min(99,(strong?72:58)+move*100*7);s.id=key+"-"+(now/45000);s.createdAt=now;s.updatedAt=now;s.status="PENDIENTE";
            s.reason=(s.live?"🔴 LIVE • ":"🗓️ PRE • ")+(strong?"SEÑAL FUERTE":"SEÑAL")+": precio confirmado en 2+ lecturas. Probabilidad implícita "+fmt(prev*100)+"% → "+fmt(c.implied*100)+"% (+"+fmt(move*100)+" pp).";
            if(store.paperActive()){
                if(!store.canPaperBet()){store.incrementPaperSkipped();continue;}
                s.paper=true;s.sessionId=store.paperSessionId();s.stake=store.paperStake();s.potentialProfit=Models.profitForStake(s.odds,s.stake);
                s.reason="🧪 APUESTA VIRTUAL • "+s.reason+" Stake virtual "+Models.money(s.stake)+"; no coloca apuestas reales.";
            }
            lastSignalAt.put(key,now);store.upsertSignal(s);if(listener!=null)listener.onSignal(s);
        }

        resolveTableTennis(lines);
        resolveFinalWinnerText(lines,all);
        if(listener!=null)listener.onObservedChanged();
    }

    private void collectOdds(List<OcrLine> lines,int idx,OcrLine l,Pattern p,boolean american,String sport,boolean screenLive,int sw,int sh,List<Candidate> out){
        Matcher m=p.matcher(normalizeNums(l.text));
        while(m.find()){
            String price=m.group(1);double implied=Models.impliedFromOdds(price);if(implied<=0||implied>=0.995)continue;
            if(!american){try{double d=Double.parseDouble(price);if(d>15.0)continue;}catch(Exception e){continue;}}
            Candidate c=buildCandidate(lines,idx,l,price,implied,sport,screenLive,sw,sh);if(c!=null&&valid(c))out.add(c);
        }
    }

    private Candidate buildCandidate(List<OcrLine> lines,int idx,OcrLine oddsLine,String oddsText,double implied,String sport,boolean screenLive,int sw,int sh){
        EventPair pair=findEventPair(lines,oddsLine,sw,sh);if(pair==null)return null;
        Candidate c=new Candidate();c.oddsText=oddsText;c.implied=implied;c.sport=inferSport(sport,pair,lines,oddsLine,sh);c.live=screenLive||nearLive(lines,oddsLine,sh);c.x=oddsLine.cx();c.y=oddsLine.cy();c.event=pair.a+" vs "+pair.b;
        OcrLine selectionLine=findSelectionLine(lines,oddsLine,pair,oddsText,sw,sh);
        if(selectionLine!=null)c.selection=translateSelection(clean(removePrice(selectionLine.text,oddsText)));
        if(c.selection.isEmpty()){
            OcrLine row=rowCompetitor(pair,oddsLine);if(row!=null)c.selection=cleanCompetitor(stripScores(stripOdds(row.text)));
        }
        OcrLine marketLine=findMarketLine(lines,oddsLine,selectionLine,sh);c.market=marketLine==null?inferMarket(c.selection,nearText(lines,oddsLine,sh),c.sport):translateMarket(marketLine.text,c.sport);
        if(c.market.isEmpty())c.market=inferMarket(c.selection,nearText(lines,oddsLine,sh),c.sport);
        Rect ev=new Rect(pair.box);ev.union(oddsLine.box);if(selectionLine!=null)ev.union(selectionLine.box);if(marketLine!=null)ev.union(marketLine.box);
        c.cropTop=Math.max(0,ev.top-100);c.cropBottom=Math.min(sh,ev.bottom+110);
        if(c.cropBottom-c.cropTop<260){int mid=oddsLine.cy();c.cropTop=Math.max(0,mid-180);c.cropBottom=Math.min(sh,mid+180);}if(c.cropBottom-c.cropTop>720){c.cropTop=Math.max(0,oddsLine.cy()-330);c.cropBottom=Math.min(sh,oddsLine.cy()+330);}
        return c;
    }

    private EventPair findEventPair(List<OcrLine> lines,OcrLine odds,int sw,int sh){
        // Explicit "A vs B" text wins, but only if both halves pass strict competitor validation.
        for(OcrLine x:lines){if(Math.abs(x.cy()-odds.cy())>Math.max(360,sh/4))continue;String t=normalizeEvent(stripOdds(x.text));if(explicitEvent(t)&&validEvent(t))return EventPair.fromExplicit(t,x.box);}
        ArrayList<OcrLine> names=new ArrayList<>();
        for(OcrLine x:lines){
            if(Math.abs(x.cy()-odds.cy())>Math.max(310,sh/5))continue;
            if(x.box.left>sw*.62)continue; // competitors are normally left of the price columns
            String t=cleanCompetitor(stripScores(stripOdds(x.text)));if(!validCompetitor(t))continue;names.add(x);
        }
        EventPair best=null;double bestScore=1e9;
        for(int i=0;i<names.size();i++)for(int j=i+1;j<names.size();j++){
            OcrLine a=names.get(i),b=names.get(j);int gap=Math.abs(a.cy()-b.cy());if(gap<28||gap>190)continue;if(Math.abs(a.box.left-b.box.left)>150)continue;
            String sa=cleanCompetitor(stripScores(stripOdds(a.text))),sb=cleanCompetitor(stripScores(stripOdds(b.text)));if(similar(sa,sb))continue;
            int top=Math.min(a.box.top,b.box.top),bottom=Math.max(a.box.bottom,b.box.bottom);if(odds.cy()<top-80||odds.cy()>bottom+95)continue;
            double score=Math.abs(((a.cy()+b.cy())/2.0)-odds.cy())+gap*.35+Math.abs(a.box.left-b.box.left)*.2;
            if(score<bestScore){bestScore=score;best=new EventPair(sa,sb,a,b);}
        }
        return best;
    }

    private OcrLine findSelectionLine(List<OcrLine> lines,OcrLine odds,EventPair pair,String price,int sw,int sh){
        String same=clean(removePrice(normalizeNums(odds.text),price));if(isSelectionToken(same))return new OcrLine(same,odds.box);
        OcrLine best=null;int bd=Integer.MAX_VALUE;
        for(OcrLine x:lines){int dy=Math.abs(x.cy()-odds.cy());if(dy>115)continue;String t=clean(stripOdds(normalizeNums(x.text)));if(t.isEmpty())continue;
            boolean token=isSelectionToken(t);boolean comp=validCompetitor(cleanCompetitor(stripScores(t)))&&(similar(t,pair.a)||similar(t,pair.b));if(!token&&!comp)continue;
            int dx=Math.abs(x.cx()-odds.cx());if(token&&dx>170)continue;if(comp&&dy>55)continue;int d=dy*3+dx;if(d<bd){bd=d;best=x;}
        }
        // For O/U grids the label is often directly above the price in the same column.
        if(best==null)for(OcrLine x:lines){if(x.cy()>=odds.cy()||odds.cy()-x.cy()>170)continue;if(Math.abs(x.cx()-odds.cx())>110)continue;String t=clean(stripOdds(normalizeNums(x.text)));if(isSelectionToken(t)){best=x;break;}}
        return best;
    }

    private OcrLine rowCompetitor(EventPair p,OcrLine odds){int da=Math.abs(p.la.cy()-odds.cy()),db=Math.abs(p.lb.cy()-odds.cy());int d=Math.min(da,db);return d<=70?(da<=db?p.la:p.lb):null;}

    private OcrLine findMarketLine(List<OcrLine> lines,OcrLine odds,OcrLine selection,int sh){OcrLine best=null;int br=-1;for(OcrLine x:lines){int dy=odds.cy()-x.cy();if(dy<-70||dy>Math.max(320,sh/5))continue;String t=clean(x.text);int r=marketRank(t);if(r<0)continue;r+=Math.max(0,8-dy/50);if(r>br){br=r;best=x;}}return best;}
    private int marketRank(String t){String l=clean(t).toLowerCase(Locale.US);if(PERIOD_ONLY.matcher(l).matches())return -1;if(!isMarket(t))return -1;int r=2;if(l.contains("set winner")||l.contains("game winner")||l.contains("round winner"))r+=5;if(l.contains("total")||l.contains("winner")||l.contains("moneyline")||l.contains("handicap")||l.contains("spread"))r+=3;if(l.contains("1st half")||l.contains("2nd half"))r+=2;return r;}

    private String inferMarket(String selection,String context,String sport){String l=(selection+" "+context).toLowerCase(Locale.US);String stage=stage(l);if(isOverUnder(l)){String noun="Total de puntos";if("Béisbol".equals(sport))noun="Total de carreras";else if("Fútbol".equals(sport)||"eSports".equals(sport))noun="Total";return noun+(stage.isEmpty()?periodSuffix(l):" • "+stage);}if(looksHandicap(selection)||l.contains("handicap")||l.contains("spread"))return "Hándicap"+(stage.isEmpty()?periodSuffix(l):" • "+stage);if(!stage.isEmpty())return "Ganador del "+stage.toLowerCase(Locale.US);return "Ganador del partido";}
    private String translateMarket(String t,String sport){String l=clean(t).toLowerCase(Locale.US);String stage=stage(l);if(l.contains("total")||l.contains("over")||l.contains("under")||l.contains("goals")||l.contains("runs")){String noun=l.contains("goals")?"Total de goles":l.contains("runs")||"Béisbol".equals(sport)?"Total de carreras":"Total de puntos";return noun+(stage.isEmpty()?periodSuffix(l):" • "+stage);}if(l.contains("handicap")||l.contains("spread"))return "Hándicap"+(stage.isEmpty()?periodSuffix(l):" • "+stage);if(l.contains("correct score"))return "Resultado exacto"+(stage.isEmpty()?periodSuffix(l):" • "+stage);if(l.contains("winner")||l.contains("moneyline")||l.contains("result")||l.contains("ganador"))return stage.isEmpty()?"Ganador del partido":"Ganador del "+stage.toLowerCase(Locale.US);return inferMarket("",l,sport);}
    private String periodSuffix(String l){if(l.contains("1st half")||l.contains("first half"))return " • 1.ª mitad";if(l.contains("2nd half")||l.contains("second half"))return " • 2.ª mitad";return "";}
    private String stage(String l){Matcher m=STAGE.matcher(l);if(m.find()){String w=m.group(0).toLowerCase(Locale.US);if(w.startsWith("game")||w.startsWith("juego"))return "Juego "+m.group(1);if(w.startsWith("round")||w.startsWith("ronda"))return "Ronda "+m.group(1);return "Set "+m.group(1);}return "";}
    private String translateSelection(String s){s=clean(normalizeNums(s));String l=s.toLowerCase(Locale.US);Matcher n=Pattern.compile("(?i)\\b(over|under)\\s*([+-]?\\d+(?:\\.\\d+)?)").matcher(s);if(n.find())return (n.group(1).equalsIgnoreCase("over")?"Más de ":"Menos de ")+n.group(2);if(l.matches("^o\\s*\\d.*"))return s.replaceFirst("(?i)^o\\s*","Más de ");if(l.matches("^u\\s*\\d.*"))return s.replaceFirst("(?i)^u\\s*","Menos de ");return cleanCompetitor(s);}

    private boolean valid(Candidate c){return c.implied>0&&c.implied<.995&&validEvent(c.event)&&!c.market.isEmpty()&&validSelection(c.selection)&&!looksLikeMarketAsEvent(c.event);}
    private Signal toSignal(Candidate c,long now){Signal s=new Signal();String base=Integer.toHexString((c.event+"|"+c.market+"|"+c.selection).toLowerCase(Locale.US).hashCode());s.baseId=base;s.id=base;s.sport=c.sport;s.event=c.event;s.market=c.market;s.selection=c.selection;s.odds=c.oddsText;s.implied=c.implied;s.targetX=c.x;s.targetY=c.y;s.cropTop=c.cropTop;s.cropBottom=c.cropBottom;s.live=c.live;s.createdAt=now;s.updatedAt=now;s.reason="Mercado y cuota leídos visualmente de la pantalla de Hard Rock.";return s;}
    private void dedupe(List<Candidate>a){HashSet<String>seen=new HashSet<>();a.removeIf(c->!seen.add((c.event+"|"+c.market+"|"+c.selection+"|"+c.oddsText).toLowerCase(Locale.US)));}

    private void maybeFindTarget(List<OcrLine> lines){String target=store.openTarget();if(target.isEmpty()||System.currentTimeMillis()-store.openTargetAt()>60000){if(!target.isEmpty())store.clearOpenTarget();return;}String[] p=target.split("(?i)\\s+vs\\s+",2);for(OcrLine l:lines){String t=l.text.toLowerCase(Locale.US);boolean ok=p.length==2?(containsName(t,p[0])||containsName(t,p[1])):containsName(t,target);if(ok&&!containsOdds(t)){store.clearOpenTarget();if(listener!=null)listener.onTargetFound(l.cx(),l.cy());return;}}}

    /** Resolve table-tennis markets from the visible set scoreboard. */
    private void resolveTableTennis(List<OcrLine> lines){
        List<Signal> pending=store.loadSignals();for(Signal s:pending){if(!"PENDIENTE".equals(s.status)||!s.sport.toLowerCase(Locale.US).contains("mesa"))continue;String[] p=s.event.split("(?i)\\s+vs\\s+",2);if(p.length!=2)continue;OcrLine a=findNameLine(lines,p[0]),b=findNameLine(lines,p[1]);if(a==null||b==null)continue;List<Integer> na=rowNumbers(lines,a),nb=rowNumbers(lines,b);if(na.isEmpty()||nb.isEmpty())continue;int setsA=na.get(0),setsB=nb.get(0);
            String ml=s.market.toLowerCase(Locale.US);if(ml.contains("ganador del partido")&&Math.max(setsA,setsB)>=3&&setsA!=setsB){String win=setsA>setsB?p[0]:p[1];store.setResult(s.id,similar(win,s.selection)?"GANADA":"PERDIDA");continue;}
            Matcher sm=Pattern.compile("(?i)set\\s*(\\d+)").matcher(s.market);if(!sm.find())continue;int n;try{n=Integer.parseInt(sm.group(1));}catch(Exception e){continue;}if(na.size()<=n||nb.size()<=n)continue;int pa=na.get(n),pb=nb.get(n);if(!finishedSet(pa,pb))continue;
            if(ml.contains("ganador")){String win=pa>pb?p[0]:p[1];store.setResult(s.id,similar(win,s.selection)?"GANADA":"PERDIDA");continue;}
            if(ml.contains("total")){Double line=selectionLineValue(s.selection);if(line==null)continue;double total=pa+pb;boolean over=s.selection.toLowerCase(Locale.US).contains("más");boolean under=s.selection.toLowerCase(Locale.US).contains("menos");if(!over&&!under)continue;if(Math.abs(total-line)<1e-9)store.setResult(s.id,"PUSH");else store.setResult(s.id,(over?total>line:total<line)?"GANADA":"PERDIDA");}
        }
    }
    private OcrLine findNameLine(List<OcrLine> lines,String name){String f=firstWord(name).toLowerCase(Locale.US);OcrLine best=null;for(OcrLine x:lines){String t=x.text.toLowerCase(Locale.US);if((!f.isEmpty()&&t.contains(f))||similar(x.text,name)){if(best==null||x.box.left<best.box.left)best=x;}}return best;}
    private List<Integer> rowNumbers(List<OcrLine> lines,OcrLine name){ArrayList<OcrLine> row=new ArrayList<>();for(OcrLine x:lines)if(Math.abs(x.cy()-name.cy())<=34&&x.box.left>=name.box.left)row.add(x);row.sort(Comparator.comparingInt(x->x.box.left));ArrayList<Integer> nums=new ArrayList<>();for(OcrLine x:row){String t=normalizeNums(x.text);if(DECIMAL.matcher(t).find()||AMERICAN.matcher(t).find())continue;Matcher m=INT_TOKEN.matcher(t);while(m.find()){try{int v=Integer.parseInt(m.group(1));if(v>=0&&v<=30)nums.add(v);}catch(Exception ignored){}}}return nums;}
    private boolean finishedSet(int a,int b){return Math.max(a,b)>=11&&Math.abs(a-b)>=2;}
    private Double selectionLineValue(String s){Matcher m=Pattern.compile("(\\d+(?:[.,]\\d+)?)").matcher(s);if(!m.find())return null;try{return Double.parseDouble(m.group(1).replace(',','.'));}catch(Exception e){return null;}}

    private void resolveFinalWinnerText(List<OcrLine> lines,String all){String low=all.toLowerCase(Locale.US);if(!(low.contains("final")||low.contains("finished")||low.contains("finalizado")))return;for(Signal s:store.loadSignals()){if(!"PENDIENTE".equals(s.status)||!s.market.toLowerCase(Locale.US).contains("ganador del partido"))continue;String[] p=s.event.split("(?i)\\s+vs\\s+",2);if(p.length!=2)continue;int i1=low.indexOf(firstWord(p[0]).toLowerCase(Locale.US)),i2=low.indexOf(firstWord(p[1]).toLowerCase(Locale.US));if(i1<0||i2<0)continue;int from=Math.max(0,Math.min(i1,i2)-100),to=Math.min(all.length(),Math.max(i1,i2)+260);Matcher sm=SCORE.matcher(all.substring(from,to));while(sm.find()){try{int a=Integer.parseInt(sm.group(1)),b=Integer.parseInt(sm.group(2));if(a==b)continue;String win=a>b?p[0]:p[1];store.setResult(s.id,similar(win,s.selection)?"GANADA":"PERDIDA");break;}catch(Exception ignored){}}}}

    private String inferSport(String page,EventPair pair,List<OcrLine> lines,OcrLine odds,int sh){String near=nearText(lines,odds,sh).toLowerCase(Locale.US);if(near.contains("setka")||near.contains("table tennis")||near.contains("4th set")||near.contains("5th set"))return "Tenis de mesa";if(near.contains("ebasketball")||near.contains("esoccer")||near.contains("efootball")||near.contains("esports"))return "eSports";return page;}
    private String detectSport(List<OcrLine> lines,int sh){StringBuilder top=new StringBuilder();for(OcrLine x:lines)if(x.box.top<sh*.36)top.append(x.text).append(' ');String l=top.toString().toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong")||l.contains("tenis de mesa"))return "Tenis de mesa";if(l.contains("e-sports")||l.contains("esports")||l.contains("ebasketball")||l.contains("esoccer")||l.contains("efootball"))return "eSports";if(l.contains("baseball"))return "Béisbol";if(l.contains("basketball"))return "Baloncesto";if(l.contains("soccer"))return "Fútbol";if(l.contains("tennis"))return "Tenis";if(l.contains("hockey"))return "Hockey";return "Deporte visible";}
    private boolean isLiveScreen(String all){String l=all.toLowerCase(Locale.US);return l.contains("live now")||l.contains("en vivo")||l.contains("stream now");}
    private boolean nearLive(List<OcrLine> lines,OcrLine odds,int sh){String l=nearText(lines,odds,sh).toLowerCase(Locale.US);return l.contains("set")||l.contains("period")||l.contains("quarter")||l.contains("stream now")||l.contains("live");}
    private String nearText(List<OcrLine> lines,OcrLine o,int sh){StringBuilder s=new StringBuilder();for(OcrLine x:lines)if(Math.abs(x.cy()-o.cy())<Math.max(260,sh/6))s.append(x.text).append(' ');return s.toString();}

    private boolean explicitEvent(String t){return t.matches("(?i).+\\s+(?:vs\\.?|v\\.?|@|contra)\\s+.+")&&!t.contains("?");}
    private String normalizeEvent(String t){return clean(t).replaceAll("(?i)\\s+(?:v\\.?|@|contra)\\s+"," vs ").replaceAll("(?i)\\s+vs\\.?\\s+"," vs ");}
    private boolean validEvent(String e){String[] p=e.split("(?i)\\s+vs\\s+",2);return p.length==2&&validCompetitor(p[0])&&validCompetitor(p[1]);}
    private boolean looksLikeMarketAsEvent(String e){String l=e.toLowerCase(Locale.US);return l.matches(".*\\b(?:over|under|total|half|set|game|round|sgp)\\b.*")||OU_TOKEN.matcher(l.replace(" ","")).matches();}
    private boolean validCompetitor(String t){t=cleanCompetitor(t);if(t.length()<2||t.length()>55||containsOdds(t)||t.contains("?")||isSelectionToken(t)||PERIOD_ONLY.matcher(t).matches())return false;String l=t.toLowerCase(Locale.US);for(String z:JUNK)if(l.equals(z)||l.startsWith(z+" "))return false;if(l.matches(".*\\b(am|pm|edt|est|ct|pt)\\b.*")||l.matches("\\d{1,2}:\\d{2}.*"))return false;if(l.matches("^(?:o|u)\\s*\\d.*")||l.matches("^(?:over|under)\\s*\\d.*"))return false;if(l.matches("^(?:1st|2nd|3rd|4th)\\s+.*"))return false;return t.split("\\s+").length<=7&&containsLetter(t);}
    private String cleanCompetitor(String t){return clean(t).replaceAll("(?i)^(live|en vivo)\\s*[-•:]?\\s*","").replaceAll("(?:\\s+\\d{1,2}){1,8}$","");}
    private boolean validSelection(String t){t=clean(t);if(t.isEmpty()||t.length()>65||containsOdds(t)||t.contains("?"))return false;String l=t.toLowerCase(Locale.US);for(String z:JUNK)if(l.equals(z))return false;return validCompetitor(t)||isSelectionToken(t);}
    private boolean isSelectionToken(String t){String x=clean(normalizeNums(t));if(x.isEmpty())return false;String l=x.toLowerCase(Locale.US);if(OU_TOKEN.matcher(l).matches())return true;if(LINE_TOKEN.matcher(l).matches())return true;if(l.matches("^(?:over|under|más de|menos de)\\s*\\d+(?:\\.\\d+)?$"))return true;return false;}
    private boolean isMarket(String t){String l=clean(t).toLowerCase(Locale.US);for(String x:MARKET_WORDS)if(l.contains(x))return true;return false;}
    private boolean isOverUnder(String t){String l=clean(t).toLowerCase(Locale.US);return l.contains("over")||l.contains("under")||l.contains("más de")||l.contains("menos de")||l.matches(".*\\b[ou]\\s*\\d+(?:[.,]\\d+)?.*");}
    private boolean looksHandicap(String t){String x=stripOdds(t);return Pattern.compile("(?<!\\d)[+-]\\d+(?:[.,]\\d+)(?!\\d)").matcher(x).find();}
    private String removePrice(String t,String price){return clean(t.replaceFirst(Pattern.quote(price),""));}
    private String stripOdds(String t){String n=normalizeNums(t);return clean(DECIMAL.matcher(AMERICAN.matcher(n).replaceAll("")).replaceAll(""));}
    private String stripScores(String t){return clean(SCORE.matcher(t).replaceAll(""));}
    private boolean containsOdds(String t){String n=normalizeNums(t);return AMERICAN.matcher(n).find()||DECIMAL.matcher(n).find();}
    private String normalizeNums(String t){return t==null?"":t.replace(',', '.');}
    private boolean containsLetter(String t){for(char c:t.toCharArray())if(Character.isLetter(c))return true;return false;}
    private boolean similar(String a,String b){String x=clean(a).toLowerCase(Locale.US),y=clean(b).toLowerCase(Locale.US);if(x.isEmpty()||y.isEmpty())return false;return x.equals(y)||x.contains(y)||y.contains(x)||(!firstWord(x).isEmpty()&&firstWord(x).equals(firstWord(y)));}
    private boolean containsName(String hay,String name){String n=clean(name).toLowerCase(Locale.US);return hay.contains(n)||(!firstWord(n).isEmpty()&&hay.contains(firstWord(n)));}
    private String firstWord(String s){String[] a=clean(s).split("\\s+");return a.length==0?"":a[0].replaceAll("[^A-Za-zÀ-ÿ0-9._-]","");}
    private String clean(String t){return t==null?"":t.replace('\n',' ').replaceAll("\\s+"," ").trim();}
    private String join(Collection<OcrLine>a){StringBuilder s=new StringBuilder();for(OcrLine x:a)s.append(x.text).append('\n');return s.toString();}
    private String fmt(double d){return String.format(Locale.US,"%.1f",d);}

    private static class Candidate{String oddsText="",sport="",event="",market="",selection="";double implied=0;int x=0,y=0,cropTop=0,cropBottom=0;boolean live=false;}
    private static class EventPair{String a,b;OcrLine la,lb;Rect box;EventPair(String a,String b,OcrLine la,OcrLine lb){this.a=a;this.b=b;this.la=la;this.lb=lb;box=new Rect(la.box);box.union(lb.box);}static EventPair fromExplicit(String e,Rect r){String[]p=e.split("(?i)\\s+vs\\s+",2);OcrLine l=new OcrLine(p[0],r),q=new OcrLine(p[1],r);return new EventPair(p[0],p[1],l,q);}}
}
