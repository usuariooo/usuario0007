package com.oddswatch.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.*;

/** V7 lightweight coordinator. Actual free reading is performed by HardRockAccessibilityService. */
public class ScannerService extends Service {
    public static final String ACTION_UPDATE="com.oddswatch.mobile.UPDATE";
    private static final String CH="oddswatch_scanner";
    private final Handler h=new Handler(Looper.getMainLooper());
    private Store store;

    @Override public void onCreate(){super.onCreate();store=new Store(this);createChannel();startForeground(7,notification("Activa el lector de Accesibilidad y deja Hard Rock abierto"));h.post(tick);}
    private final Runnable tick=new Runnable(){@Override public void run(){
        try{
            if(!store.scannerOn()){stopSelf();return;}
            sendBroadcast(new Intent(ACTION_UPDATE).setPackage(getPackageName()));
            getSystemService(NotificationManager.class).notify(7,notification(store.readerReady()?"Lector V7 listo • abre Hard Rock LIVE":"Falta activar Lector Hard Rock en Accesibilidad"));
        }catch(Exception ignored){}
        h.postDelayed(this,1000);
    }};
    @Override public int onStartCommand(Intent i,int flags,int id){if(store==null)store=new Store(this);store.setScannerOn(true);return START_STICKY;}
    @Override public void onDestroy(){h.removeCallbacksAndMessages(null);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    private void createChannel(){NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel(CH,"Radar OddsWatch",NotificationManager.IMPORTANCE_LOW));}
    private Notification notification(String text){
        Intent x=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,x,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CH).setSmallIcon(R.drawable.ic_stat).setContentTitle("OddsWatch 7 • Radar").setContentText(text).setContentIntent(pi).setOngoing(true).build();
    }
}
