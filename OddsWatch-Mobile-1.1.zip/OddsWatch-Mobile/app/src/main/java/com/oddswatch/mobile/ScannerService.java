package com.oddswatch.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.*;

public class ScannerService extends Service implements HardRockWeb.Listener, SignalEngine.Listener {
    public static final String ACTION_UPDATE="com.oddswatch.mobile.UPDATE";
    private static final String CH="oddswatch_scanner";
    private final Handler h=new Handler(Looper.getMainLooper());
    private Store store; private HardRockWeb hard; private SignalEngine engine;
    private long lastSportChange=0,lastScroll=0;
    private int zeroStreak=0;
    private int sportIndex=0;
    private final String[] sports={"Table Tennis","eSports","Table Tennis","Basketball","Soccer","Table Tennis","Tennis","Baseball","Hockey","Volleyball","Darts","Boxing","Football","Golf","MMA","UFC","Cricket","Auto Racing","Rugby","Handball"};

    @Override public void onCreate(){
        super.onCreate(); store=new Store(this); engine=new SignalEngine(this,this); hard=new HardRockWeb(this,this); createChannel(); startForeground(7,notification("Iniciando radar gratuito…")); hard.loadHome(); h.post(tick);
    }

    private final Runnable tick=new Runnable(){ public void run(){
        try{
            if(!store.scannerOn()){ stopSelf(); return; }
            long now=System.currentTimeMillis();
            hard.scanNow(); // every second: current live page/odds are re-read
            if(now-lastScroll>3000){ hard.gentleScroll(); lastScroll=now; }
            if(now-lastSportChange>store.sportCycleSeconds()*1000L){
                String sport=nextSport(); store.setCurrentSport(sport); hard.clickSport(sport); lastSportChange=now;
            }
            updateNotification(); sendBroadcast(new Intent(ACTION_UPDATE).setPackage(getPackageName()));
        }catch(Exception e){ store.setLastError(e.toString()); }
        h.postDelayed(this,1000);
    }};

    private String nextSport(){
        for(int guard=0;guard<sports.length*2;guard++){
            String s=sports[sportIndex++%sports.length];
            if("Table Tennis".equals(s) && !store.pingPongPriority()) continue;
            if("eSports".equals(s) && !store.esportsPriority()) continue;
            return s;
        }
        return "Table Tennis";
    }

    @Override public int onStartCommand(Intent i,int flags,int id){ if(store==null) store=new Store(this); store.setScannerOn(true); return START_STICKY; }
    @Override public void onDestroy(){ h.removeCallbacksAndMessages(null); if(hard!=null) hard.destroy(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){ return null; }

    @Override public void onText(String url,String title,String text,String links){
        try{
            engine.setLinks(links); int n=engine.ingestText(url,title,text); store.incPages();
            if(n>0){ zeroStreak=0; store.setLastError(""); }
            else if(++zeroStreak>=10) store.setLastError("La página está cargada pero llevo 10 lecturas sin encontrar cuotas. Abre HARD ROCK, confirma que el sportsbook/eventos se ven y vuelve a dejar el scanner encendido.");
        }catch(Exception e){ store.setLastError("Lectura: "+e); }
    }
    @Override public void onPayload(String url,String payload){ try{ engine.ingestPayload(url,payload); }catch(Exception e){ store.setLastError("Payload: "+e); } }
    @Override public void onPage(String url){ store.incPages(); }
    @Override public void onError(String error){ store.setLastError(error); }

    @Override public void onNewSignal(Signal s){
        try{
            String path=hard.capture(s.id); if(!path.isEmpty()){ s.screenshot=path; new Store(this).upsert(s); }
            notifySignal(s);
        }catch(Exception ignored){}
    }
    @Override public void onDataChanged(){ sendBroadcast(new Intent(ACTION_UPDATE).setPackage(getPackageName())); }

    private void createChannel(){
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH,"Radar OddsWatch",NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel("signals","Señales OddsWatch",NotificationManager.IMPORTANCE_HIGH));
    }
    private Notification notification(String text){
        Intent x=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,x,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CH).setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat).setContentTitle("OddsWatch • Scanner ON").setContentText(text).setContentIntent(pi).setOngoing(true).build();
    }
    private void updateNotification(){
        List<Signal> list=store.loadSignals(); int active=0; long now=System.currentTimeMillis(); for(Signal s:list) if("PENDIENTE".equals(s.status)&&now-s.updatedAt<120000) active++;
        getSystemService(NotificationManager.class).notify(7,notification("Actualiza cada 1 s • "+store.currentSport()+" • señales activas "+active));
    }
    private void notifySignal(Signal s){
        Intent x=new Intent(this,MainActivity.class).putExtra("tab","detected"); PendingIntent pi=PendingIntent.getActivity(this,s.id.hashCode(),x,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        String text="TOCA: "+s.selection+" "+s.odds+" • "+s.market;
        Notification n=new Notification.Builder(this,"signals").setSmallIcon(R.drawable.ic_stat).setContentTitle("Nueva señal • "+s.sport).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(s.event+"\n"+text+"\nScore "+Math.round(s.score)+"/99")).setContentIntent(pi).setAutoCancel(true).build();
        getSystemService(NotificationManager.class).notify(s.id.hashCode(),n);
    }
}
