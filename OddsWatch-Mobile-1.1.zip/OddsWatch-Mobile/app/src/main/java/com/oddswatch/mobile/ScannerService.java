package com.oddswatch.mobile;

import android.app.*;
import android.content.*;
import android.os.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScannerService extends Service {
    public static final String CH="oddswatch_final_scanner";
    public static final String ACTION_UPDATED="com.oddswatch.mobile.FINAL_UPDATED";
    private final ExecutorService scanExec=Executors.newSingleThreadExecutor();
    private final ExecutorService alertExec=Executors.newSingleThreadExecutor();
    private final AtomicBoolean loopStarted=new AtomicBoolean(false);
    private volatile boolean alive=true;

    @Override public void onCreate(){super.onCreate();createChannel();startForeground(41,baseNotification("Scanner starting…"));}

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(!Prefs.running(this)){stopSelf();return START_NOT_STICKY;}
        if(loopStarted.compareAndSet(false,true))scanExec.submit(this::loop);
        return START_STICKY;
    }

    private void loop(){
        while(alive&&Prefs.running(this)){
            long sleepSec=Math.max(60,Prefs.interval(this));
            try{
                ScanResult r=OddsAnalyzer.scan(this); AppState.set(r);
                String line=r.alerts.isEmpty()?"No qualifying anomalies":r.alerts.get(0).oneLine();
                if(r.quotaRemaining>=0)line+=" • API left "+r.quotaRemaining;
                ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(41,baseNotification(line));
                sendBroadcast(new Intent(ACTION_UPDATED).setPackage(getPackageName()));
                maybeAlert(r.alerts);
                if(r.quotaRemaining>=0&&r.quotaRemaining<=Prefs.quotaReserve(this)){
                    AppState.error="API quota reserve reached ("+r.quotaRemaining+"). Automatic scans slowed to protect the remaining requests.";
                    sleepSec=Math.max(sleepSec,6*60*60L);
                }
            }catch(Exception e){
                AppState.error=e.getMessage()==null?e.toString():e.getMessage();
                ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(41,baseNotification("Scanner error: "+AppState.error));
                sendBroadcast(new Intent(ACTION_UPDATED).setPackage(getPackageName()));
                sleepSec=Math.max(sleepSec,5*60L);
            }
            try{Thread.sleep(sleepSec*1000L);}catch(InterruptedException e){break;}
        }
        stopSelf();
    }

    private void maybeAlert(List<MarketAlert>alerts){
        if(alerts==null||alerts.isEmpty())return;
        long now=System.currentTimeMillis(); int localCount=0; MarketAlert whatsappCandidate=null;
        for(MarketAlert a:alerts){
            String k="sent_"+Integer.toHexString(a.id.hashCode()); long last=Prefs.p(this).getLong(k,0);
            if(now-last<30*60*1000L)continue;
            if(localCount<3){notifyLocal(a);localCount++;}
            Prefs.p(this).edit().putLong(k,now).apply();
            if(whatsappCandidate==null)whatsappCandidate=a;
            if(localCount>=3&&whatsappCandidate!=null)break;
        }
        if(whatsappCandidate!=null&&Prefs.whatsapp(this)){
            MarketAlert a=whatsappCandidate;
            alertExec.submit(()->{try{WhatsAppSender.sendAlert(this,a);}catch(Exception e){AppState.error="WhatsApp: "+e.getMessage();sendBroadcast(new Intent(ACTION_UPDATED).setPackage(getPackageName()));}});
        }
    }

    private Notification baseNotification(String text){
        Intent i=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CH).setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat)
                .setContentTitle("OddsWatch Final • scanner ON").setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text)).setContentIntent(pi).setOngoing(true).build();
    }

    private void notifyLocal(MarketAlert a){
        String c="oddswatch_final_alerts";
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel nc=new NotificationChannel(c,"OddsWatch anomaly alerts",NotificationManager.IMPORTANCE_HIGH);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(nc);
        }
        String text=a.oneLine()+"\n"+a.probabilityLine()+"\n"+a.detail;
        Notification n=new Notification.Builder(this,c).setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat)
                .setContentTitle((a.live?"LIVE":"PRE")+" anomaly • "+a.score+"/100")
                .setContentText(a.event).setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),n);
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CH,"OddsWatch background scanner",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public void onTimeout(int startId,int fgsType){
        AppState.error="Android background data-sync time limit reached. Open OddsWatch again to restart the scanner, or move the scanner to a server for true 24/7 operation.";
        sendBroadcast(new Intent(ACTION_UPDATED).setPackage(getPackageName()));
        stopSelf();
    }

    @Override public void onDestroy(){alive=false;scanExec.shutdownNow();alertExec.shutdownNow();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
