package com.oddswatch.mobile;

import android.content.*;
import org.json.*;
import java.security.SecureRandom;
import java.util.*;

public class Store {
    private static final String PREF="oddswatch_vision_v9";
    public static final String MODE_PHONE="phone", MODE_DEDICATED="dedicated";
    private final SharedPreferences sp;
    public Store(Context c){sp=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);ensureTopic();}

    public boolean scannerOn(){return sp.getBoolean("scanner",false);} public void setScannerOn(boolean v){sp.edit().putBoolean("scanner",v).apply();}
    public String mode(){return sp.getString("mode",MODE_PHONE);} public void setMode(String v){sp.edit().putString("mode",v).apply();}
    public boolean dedicated(){return MODE_DEDICATED.equals(mode());}
    public boolean captureReady(){return sp.getBoolean("capture_ready",false);} public void setCaptureReady(boolean v){sp.edit().putBoolean("capture_ready",v).apply();}
    public boolean readerReady(){return sp.getBoolean("reader_ready",false);} public void setReaderReady(boolean v){sp.edit().putBoolean("reader_ready",v).apply();}
    public String foregroundPackage(){return sp.getString("fg_pkg","");} public void setForegroundPackage(String v){sp.edit().putString("fg_pkg",v==null?"":v).apply();}
    public long lastOcr(){return sp.getLong("last_ocr",0);} public void setLastOcr(long v){sp.edit().putLong("last_ocr",v).apply();}
    public int linesSeen(){return sp.getInt("lines",0);} public void setLinesSeen(int v){sp.edit().putInt("lines",Math.max(0,v)).apply();}
    public int marketsSeen(){return sp.getInt("markets",0);} public void setMarketsSeen(int v){sp.edit().putInt("markets",Math.max(0,v)).apply();}
    public String lastError(){return sp.getString("err","");} public void setLastError(String v){sp.edit().putString("err",v==null?"":v).apply();}
    public String currentSport(){return sp.getString("sport","—");} public void setCurrentSport(String v){sp.edit().putString("sport",v==null?"—":v).apply();}
    public double movementThreshold(){return Double.longBitsToDouble(sp.getLong("move",Double.doubleToLongBits(0.008)));}
    public void setMovementThreshold(double v){sp.edit().putLong("move",Double.doubleToLongBits(Math.max(.003,Math.min(.05,v)))).apply();}
    public boolean remoteEnabled(){return sp.getBoolean("remote",false);} public void setRemoteEnabled(boolean v){sp.edit().putBoolean("remote",v).apply();}
    public String topic(){return sp.getString("topic","");}
    public String openTarget(){return sp.getString("target","");} public void setOpenTarget(String v){sp.edit().putString("target",v==null?"":v).putLong("target_at",System.currentTimeMillis()).apply();}
    public long openTargetAt(){return sp.getLong("target_at",0);} public void clearOpenTarget(){sp.edit().remove("target").remove("target_at").apply();}
    public int navStep(){return sp.getInt("nav_step",0);} public void setNavStep(int v){sp.edit().putInt("nav_step",v).apply();}

    private void ensureTopic(){if(!sp.getString("topic","").isEmpty())return;String abc="abcdefghijkmnopqrstuvwxyz23456789";SecureRandom r=new SecureRandom();StringBuilder s=new StringBuilder("oddswatch-");for(int i=0;i<18;i++)s.append(abc.charAt(r.nextInt(abc.length())));sp.edit().putString("topic",s.toString()).apply();}

    public synchronized List<Signal> loadSignals(){ArrayList<Signal> out=new ArrayList<>();try{JSONArray a=new JSONArray(sp.getString("signals","[]"));for(int i=0;i<a.length();i++)out.add(Signal.fromJson(a.getJSONObject(i)));}catch(Exception ignored){}out.sort((a,b)->Long.compare(b.updatedAt,a.updatedAt));return out;}
    public synchronized void saveSignals(List<Signal> list){JSONArray a=new JSONArray();int n=0;for(Signal s:list){if(n++>=600)break;a.put(s.toJson());}sp.edit().putString("signals",a.toString()).apply();}
    public synchronized void upsertSignal(Signal s){List<Signal> a=loadSignals();boolean f=false;for(int i=0;i<a.size();i++)if(a.get(i).id.equals(s.id)){Signal old=a.get(i);if(!"PENDIENTE".equals(old.status))s.status=old.status;a.set(i,s);f=true;break;}if(!f)a.add(0,s);a.sort((x,y)->Long.compare(y.updatedAt,x.updatedAt));saveSignals(a);}
    public synchronized List<Signal> loadObserved(){ArrayList<Signal> out=new ArrayList<>();try{JSONArray a=new JSONArray(sp.getString("observed","[]"));for(int i=0;i<a.length();i++)out.add(Signal.fromJson(a.getJSONObject(i)));}catch(Exception ignored){}out.sort((a,b)->Long.compare(b.updatedAt,a.updatedAt));return out;}
    public synchronized void saveObserved(List<Signal> list){JSONArray a=new JSONArray();long now=System.currentTimeMillis();int n=0;for(Signal s:list){if(now-s.updatedAt>120000)continue;if(n++>=300)break;a.put(s.toJson());}sp.edit().putString("observed",a.toString()).apply();}
    public synchronized void upsertObserved(Signal s){List<Signal>a=loadObserved();boolean f=false;for(int i=0;i<a.size();i++)if(a.get(i).id.equals(s.id)){a.set(i,s);f=true;break;}if(!f)a.add(0,s);a.sort((x,y)->Long.compare(y.updatedAt,x.updatedAt));saveObserved(a);}
    public synchronized void setResult(String id,String status){List<Signal>a=loadSignals();for(Signal s:a)if(s.id.equals(id)){s.status=status;s.resolvedAt=System.currentTimeMillis();if("PERDIDA".equals(status))s.simulatedProfit=-1;else if("GANADA".equals(status)){try{s.simulatedProfit=Models.profitForAmerican(Integer.parseInt(s.odds.replace("+","")));}catch(Exception ignored){}}else s.simulatedProfit=0;}saveSignals(a);}
    public synchronized void clearHistory(){sp.edit().remove("signals").remove("observed").apply();}
}
