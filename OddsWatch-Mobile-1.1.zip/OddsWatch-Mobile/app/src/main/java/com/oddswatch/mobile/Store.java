package com.oddswatch.mobile;

import android.content.*;
import org.json.*;
import java.security.SecureRandom;
import java.util.*;

public class Store {
    private static final String PREF="oddswatch_vision_night_v1";
    public static final String MODE_PHONE="phone", MODE_DEDICATED="dedicated";
    public static final long TRACKING_TIMEOUT_MS=15L*60L*1000L;
    private final SharedPreferences sp;
    public Store(Context c){sp=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);ensureTopic();migrate();migrateStrictParser();migrateTestSensitivity();}
    private void migrate(){if(!sp.getBoolean("defaults",false)){sp.edit().putLong("move",Double.doubleToLongBits(0.0035)).putLong("paper_initial",Double.doubleToLongBits(30.0)).putLong("paper_stake",Double.doubleToLongBits(3.0)).putBoolean("defaults",true).apply();}}

    private void migrateStrictParser(){
        if(sp.getBoolean("strict_parser_v2",false))return;
        // Older OCR builds could confuse market labels (U8.5 / 1st Half / SGP) with competitors.
        // Those records are not valid for profitability testing, so start one clean dataset once.
        sp.edit().remove("signals").remove("observed").remove("paper_session").remove("paper_started").putBoolean("paper_active",false).putInt("paper_skipped",0).putBoolean("strict_parser_v2",true).apply();
    }

    private void migrateTestSensitivity(){
        if(sp.getBoolean("test_sensitivity_v1",false))return;
        double cur=movementThreshold();
        SharedPreferences.Editor e=sp.edit().putBoolean("test_sensitivity_v1",true);
        // Test mode: 0.25 percentage points. Preserve a custom lower value if the user already set one.
        if(cur>=0.0034)e.putLong("move",Double.doubleToLongBits(0.0025));
        e.apply();
    }

    public boolean scannerOn(){return sp.getBoolean("scanner",false);} public void setScannerOn(boolean v){sp.edit().putBoolean("scanner",v).apply();}
    public String mode(){return sp.getString("mode",MODE_PHONE);} public void setMode(String v){sp.edit().putString("mode",v).apply();}
    public boolean dedicated(){return MODE_DEDICATED.equals(mode());}
    public boolean captureReady(){return sp.getBoolean("capture_ready",false);} public void setCaptureReady(boolean v){sp.edit().putBoolean("capture_ready",v).apply();}
    public boolean readerReady(){return sp.getBoolean("reader_ready",false);} public void setReaderReady(boolean v){sp.edit().putBoolean("reader_ready",v).apply();}
    public String foregroundPackage(){return sp.getString("fg_pkg","");} public void setForegroundPackage(String v){sp.edit().putString("fg_pkg",v==null?"":v).apply();}
    public long lastOcr(){return sp.getLong("last_ocr",0);} public void setLastOcr(long v){sp.edit().putLong("last_ocr",v).apply();}
    public int linesSeen(){return sp.getInt("lines",0);} public void setLinesSeen(int v){sp.edit().putInt("lines",Math.max(0,v)).apply();}
    public int marketsSeen(){return sp.getInt("markets",0);} public void setMarketsSeen(int v){sp.edit().putInt("markets",Math.max(0,v)).apply();}
    public String lastError(){return sp.getString("err","");} public void setLastError(String v){sp.edit().putString("err",v==null?"":v).apply();}
    public String currentSport(){return sp.getString("sport","—");} public void setCurrentSport(String v){sp.edit().putString("sport",v==null?"—":v).apply();}
    public String navSport(){return sp.getString("nav_sport","");}
    public long navSportAt(){return sp.getLong("nav_sport_at",0);}
    public void setNavSport(String v){sp.edit().putString("nav_sport",v==null?"":v).putLong("nav_sport_at",System.currentTimeMillis()).apply();}
    public void clearNavSport(){sp.edit().remove("nav_sport").remove("nav_sport_at").apply();}
    public long lastSignalAt(){return sp.getLong("last_signal",0);} public void setLastSignalAt(long v){sp.edit().putLong("last_signal",v).apply();}
    public double movementThreshold(){return Double.longBitsToDouble(sp.getLong("move",Double.doubleToLongBits(0.0035)));}
    public void setMovementThreshold(double v){sp.edit().putLong("move",Double.doubleToLongBits(Math.max(.001,Math.min(.05,v)))).apply();}
    public void requestTestHighlight(){sp.edit().putBoolean("test_highlight",true).apply();}
    public boolean consumeTestHighlight(){boolean v=sp.getBoolean("test_highlight",false);if(v)sp.edit().putBoolean("test_highlight",false).apply();return v;}
    public boolean remoteEnabled(){return sp.getBoolean("remote",false);} public void setRemoteEnabled(boolean v){sp.edit().putBoolean("remote",v).apply();}
    public String topic(){return sp.getString("topic","");}
    public String openTarget(){return sp.getString("target","");}
    public String openTargetSport(){return sp.getString("target_sport","");}
    public void setOpenTarget(String v){setOpenTarget(v,"");}
    public void setOpenTarget(String v,String sport){sp.edit().putString("target",v==null?"":v).putString("target_sport",sport==null?"":sport).putLong("target_at",System.currentTimeMillis()).apply();}
    public long openTargetAt(){return sp.getLong("target_at",0);} public void clearOpenTarget(){sp.edit().remove("target").remove("target_sport").remove("target_at").apply();}
    public String resultStatus(){return sp.getString("result_status","En espera");}
    public void setResultStatus(String v){sp.edit().putString("result_status",v==null?"":v).apply();}
    public long resultExitAt(){return sp.getLong("result_exit_at",0);}
    public String resultExitEvent(){return sp.getString("result_exit_event","");}
    public void clearResultExit(){sp.edit().remove("result_exit_at").remove("result_exit_event").apply();}
    public int navStep(){return sp.getInt("nav_step",0);} public void setNavStep(int v){sp.edit().putInt("nav_step",v).apply();}

    public boolean paperActive(){return sp.getBoolean("paper_active",false);} 
    public String paperSessionId(){return sp.getString("paper_session","");}
    public long paperStartedAt(){return sp.getLong("paper_started",0);}
    public double paperInitial(){return Double.longBitsToDouble(sp.getLong("paper_initial",Double.doubleToLongBits(30.0)));}
    public double paperStake(){return Double.longBitsToDouble(sp.getLong("paper_stake",Double.doubleToLongBits(3.0)));}
    public int paperSkipped(){return sp.getInt("paper_skipped",0);} public void incrementPaperSkipped(){sp.edit().putInt("paper_skipped",paperSkipped()+1).apply();}
    public void setPaperDefaults(double initial,double stake){sp.edit().putLong("paper_initial",Double.doubleToLongBits(Math.max(1,initial))).putLong("paper_stake",Double.doubleToLongBits(Math.max(.1,stake))).apply();}
    public void startPaperSession(){String id="night-"+System.currentTimeMillis();sp.edit().putBoolean("paper_active",true).putString("paper_session",id).putLong("paper_started",System.currentTimeMillis()).putInt("paper_skipped",0).remove("tracking_signal").remove("tracking_since").remove("target").remove("target_sport").remove("target_at").remove("result_exit_at").remove("result_exit_event").putString("result_status","Esperando primera señal").apply();}
    public void stopPaperSession(){sp.edit().putBoolean("paper_active",false).apply();}

    private void ensureTopic(){if(!sp.getString("topic","").isEmpty())return;String abc="abcdefghijkmnopqrstuvwxyz23456789";SecureRandom r=new SecureRandom();StringBuilder s=new StringBuilder("oddswatch-");for(int i=0;i<18;i++)s.append(abc.charAt(r.nextInt(abc.length())));sp.edit().putString("topic",s.toString()).apply();}

    public synchronized List<Signal> loadSignals(){ArrayList<Signal> out=new ArrayList<>();try{JSONArray a=new JSONArray(sp.getString("signals","[]"));for(int i=0;i<a.length();i++)out.add(Signal.fromJson(a.getJSONObject(i)));}catch(Exception ignored){}out.sort((a,b)->Long.compare(b.updatedAt,a.updatedAt));return out;}
    public synchronized void saveSignals(List<Signal> list){JSONArray a=new JSONArray();int n=0;for(Signal s:list){if(n++>=1000)break;a.put(s.toJson());}sp.edit().putString("signals",a.toString()).apply();}
    public synchronized void upsertSignal(Signal s){List<Signal> a=loadSignals();boolean f=false;for(int i=0;i<a.size();i++)if(a.get(i).id.equals(s.id)){Signal old=a.get(i);if(!"PENDIENTE".equals(old.status)){s.status=old.status;s.simulatedProfit=old.simulatedProfit;s.resolvedAt=old.resolvedAt;s.resultSource=old.resultSource;}if(old.paper){s.paper=true;s.sessionId=old.sessionId;s.stake=old.stake;s.potentialProfit=old.potentialProfit;}a.set(i,s);f=true;break;}if(!f)a.add(0,s);a.sort((x,y)->Long.compare(y.updatedAt,x.updatedAt));saveSignals(a);}
    public synchronized List<Signal> loadObserved(){ArrayList<Signal> out=new ArrayList<>();try{JSONArray a=new JSONArray(sp.getString("observed","[]"));for(int i=0;i<a.length();i++)out.add(Signal.fromJson(a.getJSONObject(i)));}catch(Exception ignored){}out.sort((a,b)->Long.compare(b.updatedAt,a.updatedAt));return out;}
    public synchronized void saveObserved(List<Signal> list){JSONArray a=new JSONArray();long now=System.currentTimeMillis();int n=0;for(Signal s:list){if(now-s.updatedAt>120000)continue;if(n++>=400)break;a.put(s.toJson());}sp.edit().putString("observed",a.toString()).apply();}
    public synchronized void upsertObserved(Signal s){List<Signal>a=loadObserved();boolean f=false;for(int i=0;i<a.size();i++)if(a.get(i).id.equals(s.id)){a.set(i,s);f=true;break;}if(!f)a.add(0,s);a.sort((x,y)->Long.compare(y.updatedAt,x.updatedAt));saveObserved(a);}

    public synchronized List<Signal> currentPaperSignals(){
        ArrayList<Signal> out=new ArrayList<>();
        HashSet<String> seen=new HashSet<>();
        String sid=paperSessionId();
        if(sid==null||sid.isEmpty())return out;
        for(Signal s:loadSignals()){
            if(!s.paper||s.sessionId==null||!sid.equals(s.sessionId))continue;
            if(seen.add(s.id))out.add(s);
        }
        return out;
    }
    public synchronized int signalsNotCountingForBankroll(){
        int n=0;
        for(Signal s:loadSignals())if(!s.paper||s.sessionId==null||s.sessionId.isEmpty())n++;
        return n;
    }
    public synchronized boolean hasOpenPaper(String baseId){
        String sid=paperSessionId();
        for(Signal s:loadSignals()){
            if(!(s.paper||s.stake>0))continue;
            if(!(sid.isEmpty()||s.sessionId==null||s.sessionId.isEmpty()||sid.equals(s.sessionId)))continue;
            if(baseId.equals(s.baseId)&&"PENDIENTE".equals(s.status))return true;
        }
        return false;
    }
    public synchronized boolean hasAnyOpenPaper(){
        String sid=paperSessionId();
        for(Signal s:loadSignals()){
            if(!(s.paper||s.stake>0))continue;
            if(!(sid.isEmpty()||s.sessionId==null||s.sessionId.isEmpty()||sid.equals(s.sessionId)))continue;
            if("PENDIENTE".equals(s.status))return true;
        }
        return false;
    }
    public String trackingSignalId(){return sp.getString("tracking_signal","");}
    public long trackingSince(){return sp.getLong("tracking_since",0);}
    public synchronized Signal trackingSignal(){
        String id=trackingSignalId();if(id.isEmpty())return null;
        long since=trackingSince();
        for(Signal s:loadSignals())if(id.equals(s.id)&&"PENDIENTE".equals(s.status)){
            if(since>0&&System.currentTimeMillis()-since>=TRACKING_TIMEOUT_MS){
                releaseTrackingSignal("⏱️ Timeout de tracking (15 min): "+s.event+" queda PENDIENTE para revisión; buscando la siguiente señal.");
                return null;
            }
            return s;
        }
        clearTrackingSignal();return null;
    }
    public void setTrackingSignal(Signal s){
        if(s==null||s.id==null||s.id.isEmpty())return;
        sp.edit().putString("tracking_signal",s.id).putLong("tracking_since",System.currentTimeMillis()).putString("result_status","🔒 Siguiendo hasta el final: "+s.event+" • timeout 15 min").apply();
    }
    public void clearTrackingSignal(){sp.edit().remove("tracking_signal").remove("tracking_since").apply();}
    public void releaseTrackingSignal(String message){
        clearTrackingSignal();clearOpenTarget();
        setResultStatus(message==null||message.isEmpty()?"Señal liberada; sigue PENDIENTE para revisión manual.":message);
    }
    public synchronized double paperSettledProfit(){double x=0;for(Signal s:currentPaperSignals())if(!"PENDIENTE".equals(s.status))x+=s.simulatedProfit;return x;}
    public synchronized double paperPendingStake(){double x=0;for(Signal s:currentPaperSignals())if("PENDIENTE".equals(s.status))x+=Math.max(s.stake,paperStake());return x;}
    public synchronized double paperBankroll(){return paperInitial()+paperSettledProfit();}
    public synchronized double paperAvailable(){return Math.max(0,paperBankroll()-paperPendingStake());}
    public synchronized boolean canPaperBet(){return paperActive()&&paperAvailable()+1e-9>=paperStake();}
    public synchronized int paperWins(){int n=0;for(Signal s:currentPaperSignals())if("GANADA".equals(s.status))n++;return n;}
    public synchronized int paperLosses(){int n=0;for(Signal s:currentPaperSignals())if("PERDIDA".equals(s.status))n++;return n;}
    public synchronized int paperPushes(){int n=0;for(Signal s:currentPaperSignals())if("PUSH".equals(s.status))n++;return n;}
    public synchronized int paperPending(){int n=0;for(Signal s:currentPaperSignals())if("PENDIENTE".equals(s.status))n++;return n;}
    public synchronized double paperTurnover(){double x=0;for(Signal s:currentPaperSignals())if(!"PENDIENTE".equals(s.status))x+=Math.max(s.stake,0);return x;}

    public synchronized void setResult(String id,String status){setResultInternal(id,status,"MANUAL");}
    public synchronized boolean setResultAuto(String id,String status){return setResultInternal(id,status,"AUTO");}
    private synchronized boolean setResultInternal(String id,String status,String source){
        List<Signal> a=loadSignals();
        boolean changed=false;
        for(Signal s:a){
            if(!s.id.equals(id))continue;
            if(!"PENDIENTE".equals(s.status))break;
            // Only signals created inside a virtual session affect that session's bankroll.
            // A manual result for a radar-only signal is still stored, but does not retroactively
            // become a paper bet.
            double stake=s.stake>0?s.stake:paperStake();
            boolean countsForBankroll=s.paper&&s.sessionId!=null&&!s.sessionId.isEmpty();
            if(countsForBankroll){
                if(stake<=0)stake=3.0;
                s.stake=stake;
                if(s.potentialProfit<=0)s.potentialProfit=Models.profitForStake(s.odds,stake);
            }
            s.status=status;
            s.resultSource=source;
            s.resolvedAt=System.currentTimeMillis();
            if(!countsForBankroll)s.simulatedProfit=0;
            else if("PERDIDA".equals(status))s.simulatedProfit=-stake;
            else if("GANADA".equals(status))s.simulatedProfit=Models.profitForStake(s.odds,stake);
            else s.simulatedProfit=0;
            changed=true;
            break;
        }
        if(changed){
            saveSignals(a);
            if("AUTO".equals(source)){
                String ev="";for(Signal z:a)if(z.id.equals(id)){ev=z.event;break;}
                sp.edit().putLong("result_exit_at",System.currentTimeMillis()).putString("result_exit_event",ev==null?"":ev).apply();
            }
            if(id.equals(trackingSignalId())){clearTrackingSignal();clearOpenTarget();}
        }
        return changed;
    }
    public synchronized void clearHistory(){sp.edit().remove("signals").remove("observed").remove("paper_session").remove("paper_started").remove("tracking_signal").remove("tracking_since").remove("target").remove("target_sport").remove("target_at").remove("result_exit_at").remove("result_exit_event").putBoolean("paper_active",false).putInt("paper_skipped",0).apply();}
}
