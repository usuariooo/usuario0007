package com.oddswatch.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class Store {
    private static final String PREF="oddswatch_v4";
    private final SharedPreferences sp;
    public Store(Context c){ sp=c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public boolean scannerOn(){ return sp.getBoolean("scanner_on",false); }
    public void setScannerOn(boolean v){ sp.edit().putBoolean("scanner_on",v).apply(); }
    public int minScore(){ return sp.getInt("min_score",72); }
    public void setMinScore(int v){ sp.edit().putInt("min_score",Math.max(1,Math.min(99,v))).apply(); }
    public int sportCycleSeconds(){ return sp.getInt("sport_cycle",6); }
    public void setSportCycleSeconds(int v){ sp.edit().putInt("sport_cycle",Math.max(3,v)).apply(); }
    public boolean pingPongPriority(){ return sp.getBoolean("ping_priority",true); }
    public void setPingPongPriority(boolean v){ sp.edit().putBoolean("ping_priority",v).apply(); }
    public boolean esportsPriority(){ return sp.getBoolean("esports_priority",true); }
    public void setEsportsPriority(boolean v){ sp.edit().putBoolean("esports_priority",v).apply(); }
    public String lastError(){ return sp.getString("last_error",""); }
    public void setLastError(String e){ sp.edit().putString("last_error",e==null?"":e).apply(); }
    public long lastScan(){ return sp.getLong("last_scan",0); }
    public void setLastScan(long t){ sp.edit().putLong("last_scan",t).apply(); }
    public int pages(){ return sp.getInt("pages",0); }
    public void incPages(){ sp.edit().putInt("pages",pages()+1).apply(); }
    public int payloads(){ return sp.getInt("payloads",0); }
    public void incPayloads(){ sp.edit().putInt("payloads",payloads()+1).apply(); }
    public int oddsSeen(){ return sp.getInt("odds_seen",0); }
    public void setOddsSeen(int v){ sp.edit().putInt("odds_seen",v).apply(); }
    public String currentSport(){ return sp.getString("current_sport","Table Tennis"); }
    public void setCurrentSport(String v){ sp.edit().putString("current_sport",v).apply(); }

    public synchronized List<Signal> loadSignals(){
        ArrayList<Signal> out=new ArrayList<>();
        try{
            JSONArray a=new JSONArray(sp.getString("signals","[]"));
            for(int i=0;i<a.length();i++) out.add(Signal.fromJson(a.getJSONObject(i)));
        }catch(Exception ignored){}
        out.sort((a,b)->Long.compare(b.updatedAt,a.updatedAt));
        return out;
    }

    public synchronized void saveSignals(List<Signal> list){
        JSONArray a=new JSONArray();
        int count=0;
        for(Signal s:list){ if(count++>=500) break; a.put(s.toJson()); }
        sp.edit().putString("signals",a.toString()).apply();
    }

    public synchronized void upsert(Signal s){
        List<Signal> list=loadSignals(); boolean found=false;
        for(int i=0;i<list.size();i++){
            if(list.get(i).id.equals(s.id)){ list.set(i,s); found=true; break; }
        }
        if(!found) list.add(0,s);
        list.sort((a,b)->Long.compare(b.updatedAt,a.updatedAt));
        saveSignals(list);
    }

    public synchronized void setResult(String id,String status){
        List<Signal> list=loadSignals();
        for(Signal s:list){
            if(s.id.equals(id)){
                s.status=status; s.resolvedAt=System.currentTimeMillis();
                s.simulatedProfit=profitFor(s,status); break;
            }
        }
        saveSignals(list);
    }

    private double profitFor(Signal s,String status){
        if("PUSH".equals(status)||"ANULADA".equals(status)) return 0;
        if("PERDIDA".equals(status)) return -1;
        if(!"GANADA".equals(status)) return 0;
        try{
            int a=Integer.parseInt(s.odds.replace("+","").trim());
            if(a>0) return a/100.0;
            if(a<0) return 100.0/Math.abs(a);
        }catch(Exception ignored){}
        return 0;
    }

    public synchronized void clearHistory(){ sp.edit().remove("signals").apply(); }
}
