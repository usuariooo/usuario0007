package com.oddswatch.mobile;

import android.accessibilityservice.*;
import android.content.*;
import android.graphics.Path;
import android.os.*;
import android.view.accessibility.*;
import java.util.*;
import java.util.regex.Pattern;

public class HardRockAccessibilityService extends AccessibilityService {
    private static HardRockAccessibilityService instance;
    private Store store;private Handler h;private long lastLaunch=0,lastLive=0,lastSport=0,lastScroll=0;private int scrollCount=0,sportIndex=0;
    private static final Pattern ODDS=Pattern.compile("(?<!\\d)[+-](?:100|[1-9]\\d{2,3})(?!\\d)");
    private static final String[] SPORTS={"Table Tennis","Ping Pong","Esports","eSports","Basketball","Soccer","Tennis","Baseball","Hockey","Volleyball","Darts","MMA","Boxing"};

    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;store=new Store(this);store.setReaderReady(true);h=new Handler(Looper.getMainLooper());h.post(tick);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){if(store==null)return;CharSequence p=event.getPackageName();if(p!=null)store.setForegroundPackage(p.toString());}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(store!=null)store.setReaderReady(false);if(h!=null)h.removeCallbacksAndMessages(null);if(instance==this)instance=null;super.onDestroy();}

    private final Runnable tick=new Runnable(){@Override public void run(){try{navigate();}catch(Exception ignored){}if(h!=null)h.postDelayed(this,850);}};
    private void navigate(){
        if(!store.scannerOn())return;long now=System.currentTimeMillis();String fg=store.foregroundPackage();
        if(!"com.hardrockdigital.client".equals(fg)){
            if(store.dedicated()&&now-lastLaunch>4000){launchHardRock(this);lastLaunch=now;}
            return;
        }
        AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
        String target=store.openTarget();
        if(!target.isEmpty()&&now-store.openTargetAt()<60000){if(now-lastScroll>900){scroll(root,true);lastScroll=now;}return;}
        if(now-lastLive>18000){if(clickText(root,new String[]{"LIVE","Live","EN VIVO","En vivo"})){lastLive=now;return;}lastLive=now;}
        if(now-lastSport>45000){String wanted=SPORTS[sportIndex++%SPORTS.length];if(clickText(root,new String[]{wanted})){lastSport=now;scrollCount=0;store.setNavStep(sportIndex);return;}lastSport=now;}
        if(now-lastScroll>1250){boolean down=(scrollCount%18)<14;scroll(root,down);scrollCount++;lastScroll=now;}
    }

    private boolean clickText(AccessibilityNodeInfo root,String[] wanted){
        ArrayDeque<AccessibilityNodeInfo> q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=text(n);
            if(!t.isEmpty()&&!ODDS.matcher(t).find())for(String w:wanted)if(t.equalsIgnoreCase(w)||t.toLowerCase(Locale.US).contains(w.toLowerCase(Locale.US))){AccessibilityNodeInfo c=n;for(int i=0;i<4&&c!=null;i++){if(c.isClickable()){c.performAction(AccessibilityNodeInfo.ACTION_CLICK);return true;}c=c.getParent();}}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }return false;
    }
    private String text(AccessibilityNodeInfo n){String a=n.getText()==null?"":n.getText().toString();String b=n.getContentDescription()==null?"":n.getContentDescription().toString();return (a+" "+b).trim();}
    private boolean scroll(AccessibilityNodeInfo root,boolean down){AccessibilityNodeInfo sc=findScrollable(root);if(sc!=null&&sc.performAction(down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))return true;int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;Path p=new Path();p.moveTo(w*.5f,down?hg*.78f:hg*.32f);p.lineTo(w*.5f,down?hg*.32f:hg*.78f);return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,350)).build(),null,null);}
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root){ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);while(!q.isEmpty()){AccessibilityNodeInfo n=q.removeFirst();if(n.isScrollable())return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return null;}

    public static void launchHardRock(Context c){String pkg="com.hardrockdigital.client";try{Intent i=c.getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);c.startActivity(i);return;}}catch(Exception ignored){}try{c.startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("market://details?id="+pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){}}
    public static void tapSafeEvent(int x,int y){HardRockAccessibilityService s=instance;if(s==null)return;Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();s.dispatchGesture(g,null,null);}
}
