package com.oddswatch.mobile;

import android.accessibilityservice.*;
import android.content.*;
import android.graphics.Path;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.TextView;
import java.util.*;
import java.util.regex.Pattern;

public class HardRockAccessibilityService extends AccessibilityService {
    private static HardRockAccessibilityService instance;
    private Store store;private Handler h;private long lastLaunch=0,lastLive=0,lastSport=0,lastScroll=0,lastBack=0,deadEndSince=0,detailSince=0;private int scrollCount=0,sportIndex=0;
    private static final Pattern ODDS=Pattern.compile("(?<!\\d)[+-](?:100|[1-9]\\d{2,3})(?!\\d)");
    private static final String[] SPORTS={"Table Tennis","Ping Pong","Table Tennis","Ping Pong","Esports","eSports","Table Tennis","Ping Pong","Basketball","Soccer","Tennis","Baseball","Hockey","Volleyball","Darts","MMA","Boxing"};

    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;store=new Store(this);store.setReaderReady(true);h=new Handler(Looper.getMainLooper());h.post(tick);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){if(store==null)return;CharSequence p=event.getPackageName();if(p!=null)store.setForegroundPackage(p.toString());}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(store!=null)store.setReaderReady(false);if(h!=null)h.removeCallbacksAndMessages(null);if(instance==this)instance=null;super.onDestroy();}

    private final Runnable tick=new Runnable(){@Override public void run(){try{navigate();}catch(Exception ignored){}if(h!=null)h.postDelayed(this,850);}};
    private void navigate(){
        if(!store.scannerOn())return;long now=System.currentTimeMillis();String fg=store.foregroundPackage();
        if(!"com.hardrockdigital.client".equals(fg)){
            deadEndSince=0;detailSince=0;
            if(store.dedicated()&&now-lastLaunch>4000){launchHardRock(this);lastLaunch=now;}
            return;
        }
        AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
        String visible=rootText(root).toLowerCase(Locale.US);
        if(isDeadEnd(visible)){
            if(deadEndSince==0)deadEndSince=now;
            if(now-deadEndSince>2800&&now-lastBack>3200){performGlobalAction(GLOBAL_ACTION_BACK);lastBack=now;deadEndSince=0;detailSince=0;}
            return;
        }else deadEndSince=0;
        // If the radar accidentally opens an event detail, give OCR enough time to read it, then escape.
        // This prevents a single unavailable/finished event from freezing the entire overnight scan.
        if(store.dedicated()&&looksLikeEventDetail(visible)){
            if(detailSince==0)detailSince=now;
            if(now-detailSince>12000&&now-lastBack>3200){performGlobalAction(GLOBAL_ACTION_BACK);lastBack=now;detailSince=0;return;}
        }else detailSince=0;
        String target=store.openTarget();
        if(!target.isEmpty()&&now-store.openTargetAt()<30000){if(now-lastScroll>900){scroll(root,true);lastScroll=now;}return;}
        if(!target.isEmpty()){store.clearOpenTarget();}
        if(now-lastLive>12000){if(clickText(root,new String[]{"LIVE","Live","EN VIVO","En vivo"})){lastLive=now;return;}lastLive=now;}
        if(now-lastSport>25000){String wanted=SPORTS[sportIndex++%SPORTS.length];if(clickText(root,new String[]{wanted})){lastSport=now;scrollCount=0;store.setNavStep(sportIndex);return;}lastSport=now;}
        if(now-lastScroll>1250){boolean down=(scrollCount%18)<14;scroll(root,down);scrollCount++;lastScroll=now;}
    }

    private boolean isDeadEnd(String l){return l.contains("no bets currently available")||l.contains("check back again soon")||l.contains("this game has ended")||l.contains("match completed")||l.contains("final whistle has blown")||l.contains("view upcoming games")||l.contains("no wagers currently available");}
    private boolean looksLikeEventDetail(String l){boolean tabs=l.contains("popular")&&((l.contains("parlays")||l.contains("halves")||l.contains("goals")||l.contains("sets")||l.contains("points")));return tabs||l.contains("match completed")||l.contains("this game has ended")||l.contains("no bets currently available");}
    private String rootText(AccessibilityNodeInfo root){StringBuilder out=new StringBuilder();ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);int seen=0;while(!q.isEmpty()&&seen++<700){AccessibilityNodeInfo n=q.removeFirst();String t=text(n);if(!t.isEmpty())out.append(t).append(' ');for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return out.toString();}

    private boolean clickText(AccessibilityNodeInfo root,String[] wanted){
        ArrayDeque<AccessibilityNodeInfo> q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=text(n);
            if(!t.isEmpty()&&!ODDS.matcher(t).find())for(String w:wanted)if(t.equalsIgnoreCase(w)||t.toLowerCase(Locale.US).contains(w.toLowerCase(Locale.US))){AccessibilityNodeInfo c=n;for(int i=0;i<4&&c!=null;i++){if(c.isClickable()){c.performAction(AccessibilityNodeInfo.ACTION_CLICK);return true;}c=c.getParent();}}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }return false;
    }
    private String text(AccessibilityNodeInfo n){String a=n.getText()==null?"":n.getText().toString();String b=n.getContentDescription()==null?"":n.getContentDescription().toString();return (a+" "+b).trim();}
    private boolean scroll(AccessibilityNodeInfo root,boolean down){AccessibilityNodeInfo sc=findScrollable(root);if(sc!=null&&sc.performAction(down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))return true;int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;Path p=new Path();p.moveTo(w*.5f,down?hg*.78f:hg*.32f);p.lineTo(w*.5f,down?hg*.32f:hg*.78f);return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,350)).build(),null,null);}
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root){ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);while(!q.isEmpty()){AccessibilityNodeInfo n=q.removeFirst();if(n.isScrollable())return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return null;}

    private void showHighlight(int x,int y,String label,boolean test){
        try{
            WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            final TextView v=new TextView(this);v.setText(label);v.setTextColor(Color.WHITE);v.setTextSize(15);v.setPadding(22,14,22,14);v.setElevation(18f);
            GradientDrawable bg=new GradientDrawable();bg.setColor(test?0xDD6A4C00:0xDD087F73);bg.setCornerRadius(28);bg.setStroke(5,test?0xFFFFC34A:0xFF35E4D1);v.setBackground(bg);
            int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP|Gravity.START;lp.x=Math.max(8,Math.min(w-420,x-330));lp.y=Math.max(80,Math.min(hg-180,y-60));wm.addView(v,lp);
            if(h!=null)h.postDelayed(()->{try{wm.removeView(v);}catch(Exception ignored){}},8000);
        }catch(Exception ignored){}
    }
    public static void highlightSelection(int x,int y,String label,boolean test){HardRockAccessibilityService s=instance;if(s==null)return;if(s.h!=null)s.h.post(()->s.showHighlight(x,y,label,test));}

    public static void launchHardRock(Context c){String pkg="com.hardrockdigital.client";try{Intent i=c.getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);c.startActivity(i);return;}}catch(Exception ignored){}try{c.startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("market://details?id="+pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){}}
    public static void tapSafeEvent(int x,int y){HardRockAccessibilityService s=instance;if(s==null)return;Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();s.dispatchGesture(g,null,null);}
}
