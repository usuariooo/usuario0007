package com.oddswatch.mobile;

import android.accessibilityservice.*;
import android.content.*;
import android.graphics.Path;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.TextView;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Navigation helper for the official Hard Rock app.
 * It never clicks an odds/price node. It only opens navigation labels, scrolls,
 * opens an event name when VisionParser explicitly asks for a result check, and
 * backs out of stale/dead-end/detail screens.
 */
public class HardRockAccessibilityService extends AccessibilityService {
    private static HardRockAccessibilityService instance;
    private Store store; private Handler h;
    private long lastLaunch=0,lastLive=0,lastSport=0,lastScroll=0,lastBack=0;
    private long deadEndSince=0,detailSince=0,subPageSince=0;
    private long sportEnteredAt=0,lastSportBarSwipe=0;
    private int scrollCount=0,sportIndex=0,lastPageHash=0,stagnantTicks=0,failedScrolls=0;
    private String activeSport="";

    private static final Pattern ODDS=Pattern.compile("(?<!\\d)(?:[+-](?:100|[1-9]\\d{2,3})|(?:1|[2-9]|[1-9]\\d)\\.\\d{2})(?!\\d)");
    private static final String[] SPORTS={
        // Ping pong + eSports dominate the cycle. The rest are sampled briefly.
        "Table Tennis","eSports","Table Tennis","E-Sports","Table Tennis","Esports",
        "Basketball","Soccer","Tennis","MLB","Baseball","Hockey","Football","PGA","Golf","Volleyball","Darts","MMA","Boxing"
    };

    @Override protected void onServiceConnected(){
        super.onServiceConnected(); instance=this; store=new Store(this); store.setReaderReady(true);
        h=new Handler(Looper.getMainLooper()); h.post(tick);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(store==null)return; CharSequence p=event.getPackageName(); if(p!=null)store.setForegroundPackage(p.toString());
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(store!=null)store.setReaderReady(false);if(h!=null)h.removeCallbacksAndMessages(null);if(instance==this)instance=null;super.onDestroy();}

    private final Runnable tick=new Runnable(){@Override public void run(){try{navigate();}catch(Exception ignored){}if(h!=null)h.postDelayed(this,900);}};

    private void navigate(){
        if(!store.scannerOn())return;
        long now=System.currentTimeMillis(); String fg=store.foregroundPackage();
        if(!"com.hardrockdigital.client".equals(fg)){
            resetPageTimers();
            if(store.dedicated()&&now-lastLaunch>3500){launchHardRock(this);lastLaunch=now;}
            return;
        }
        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return;
        String visible=normalize(rootText(root)); String low=visible.toLowerCase(Locale.US);
        String selected=selectedSport(root);
        if(!selected.isEmpty()){activeSport=selected;if(sportEnteredAt==0)sportEnteredAt=now;store.setNavSport(canonicalSport(selected));}

        int pageHash=stableFingerprint(low).hashCode();
        if(pageHash==lastPageHash)stagnantTicks++;else{lastPageHash=pageHash;stagnantTicks=0;failedScrolls=0;}

        if(isDeadEnd(low)){
            if(deadEndSince==0)deadEndSince=now;
            if(now-deadEndSince>1600&&now-lastBack>1800){goBack();deadEndSince=0;detailSince=0;subPageSince=0;}
            return;
        } else deadEndSince=0;

        String target=store.openTarget();
        boolean targetActive=!target.isEmpty()&&now-store.openTargetAt()<45000;

        boolean detail=looksLikeEventDetail(low);
        boolean subPage=looksLikeCompetitionSubPage(low);
        if(detail||subPage){
            if(detailSince==0)detailSince=now;
            long budget=targetActive?9000:5500;
            if(store.dedicated()&&now-detailSince>budget&&now-lastBack>1800){goBack();detailSince=0;subPageSince=0;return;}
        } else detailSince=0;

        // Result-check searches temporarily own navigation, but never for more than a few seconds.
        if(targetActive){
            if(now-lastScroll>1100){boolean ok=scroll(root,true);if(!ok)failedScrolls++;else failedScrolls=0;lastScroll=now;}
            if(failedScrolls>=3&&now-lastBack>2200){goBack();failedScrolls=0;}
            return;
        }
        if(!target.isEmpty())store.clearOpenTarget();

        // HARD watchdog: dynamic odds must not keep Baseball/MLB or any other sport open forever.
        // Table tennis/eSports get longer because they are the priority; all other sports are sampled briefly.
        if(!activeSport.isEmpty()&&sportEnteredAt>0){
            long budget=isPrioritySport(activeSport)?15000:6000;
            if(now-sportEnteredAt>budget){
                activeSport="";sportEnteredAt=0;scrollCount=0;failedScrolls=0;stagnantTicks=0;
                if(!isLiveHub(low)){
                    if(clickContainsText(root,new String[]{"Live","LIVE","En vivo","EN VIVO"})){lastLive=now;return;}
                    if(now-lastBack>1800){goBack();return;}
                }
                // Already on the LIVE hub: allow the next sport to be selected immediately.
                lastSport=0;
            }
        }

        // A static page that ignores multiple scroll attempts should never hold the overnight radar hostage.
        if(store.dedicated()&&stagnantTicks>=7&&now-lastBack>2800){
            if(!isLiveHub(low)){goBack();}
            else {activeSport="";sportEnteredAt=0;lastSport=0;}
            stagnantTicks=0;failedScrolls=0;return;
        }

        boolean liveHub=isLiveHub(low);
        if(!liveHub&&now-lastLive>4200){
            if(clickContainsText(root,new String[]{"Live","LIVE","En vivo","EN VIVO"})){lastLive=now;scrollCount=0;activeSport="";sportEnteredAt=0;return;}
            lastLive=now;
        }

        // Pick a sport every few seconds. Exact matching prevents Tennis from matching Table Tennis.
        if(now-lastSport>7000){
            String wanted=SPORTS[sportIndex++%SPORTS.length];
            if(clickExactText(root,new String[]{wanted})){
                lastSport=now;scrollCount=0;activeSport=wanted;sportEnteredAt=now;store.setNavStep(sportIndex);store.setNavSport(canonicalSport(wanted));return;
            }
            // The horizontal sports strip can hide labels off-screen. Nudge it sideways and retry on the next tick.
            if(now-lastSportBarSwipe>2200){swipeSportsBar((sportIndex%2)==0);lastSportBarSwipe=now;}
            lastSport=now;
        }

        if(now-lastScroll>1350){
            boolean down=(scrollCount%10)<7; boolean ok=scroll(root,down); scrollCount++; lastScroll=now;
            if(!ok)failedScrolls++;else failedScrolls=0;
            if(failedScrolls>=3&&now-lastBack>2400){
                if(!isLiveHub(low))goBack();else{activeSport="";sportEnteredAt=0;lastSport=0;}
                failedScrolls=0;
            }
        }
    }

    private boolean isPrioritySport(String s){String l=s==null?"":s.toLowerCase(Locale.US);return l.contains("table tennis")||l.contains("ping pong")||l.contains("sport");}
    private String canonicalSport(String s){String l=s==null?"":s.toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong"))return "Tenis de mesa";if(l.contains("sport"))return "eSports";if(l.equals("mlb")||l.contains("baseball"))return "Béisbol";if(l.contains("basketball"))return "Baloncesto";if(l.contains("soccer"))return "Fútbol";if(l.equals("tennis"))return "Tenis";if(l.contains("hockey"))return "Hockey";if(l.contains("football")||l.equals("nfl"))return "Fútbol americano";if(l.contains("pga")||l.contains("golf"))return "Golf";return s;}
    private String selectedSport(AccessibilityNodeInfo root){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));if((n.isSelected()||n.isChecked())&&!t.isEmpty()&&!ODDS.matcher(t).find()){for(String w:SPORTS)if(t.equalsIgnoreCase(w))return w;}for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}
        return "";
    }

    private boolean swipeSportsBar(boolean left){
        try{
            int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;
            Path p=new Path();float y=hg*.165f;p.moveTo(left?w*.78f:w*.22f,y);p.lineTo(left?w*.22f:w*.78f,y);
            return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,260)).build(),null,null);
        }catch(Exception e){return false;}
    }

    private void resetPageTimers(){deadEndSince=0;detailSince=0;subPageSince=0;stagnantTicks=0;failedScrolls=0;}
    private void goBack(){performGlobalAction(GLOBAL_ACTION_BACK);lastBack=System.currentTimeMillis();}

    private boolean isDeadEnd(String l){return l.contains("no bets currently available")||l.contains("check back again soon")||l.contains("this game has ended")||l.contains("match completed")||l.contains("final whistle has blown")||l.contains("view upcoming games")||l.contains("no wagers currently available")||l.contains("no markets currently available");}
    private boolean isLiveHub(String l){
        if(l.contains("live now")||l.contains("en vivo ahora"))return true;
        boolean shell=l.contains("home")&&l.contains("my bets");
        boolean tabs=l.contains("table tennis")||l.contains("ping pong")||l.contains("e-sports")||l.contains("esports")||l.contains("basketball")||l.contains("soccer")||l.contains("baseball");
        return shell&&tabs;
    }
    private boolean looksLikeEventDetail(String l){
        boolean tabs=l.contains("popular")&&(l.contains("parlays")||l.contains("halves")||l.contains("goals")||l.contains("sets")||l.contains("points"));
        boolean ended=l.contains("match completed")||l.contains("this game has ended")||l.contains("no bets currently available");
        return tabs||ended;
    }
    private boolean looksLikeCompetitionSubPage(String l){
        if(isLiveHub(l))return false;
        // Competition/league pages commonly have a title followed by a single "Games" tab.
        boolean gamesTab=l.contains(" games ")||l.endsWith(" games")||l.startsWith("games ");
        boolean leagueWords=l.contains(" series")||l.contains(" league")||l.contains(" germany")||l.contains(" cup")||l.contains(" tournament");
        boolean schedule=l.contains("streaming soon")||l.contains("today,")||l.contains("tomorrow,");
        return (gamesTab&&(leagueWords||schedule));
    }
    private String stableFingerprint(String l){String s=l.replaceAll("\\b\\d{1,2}:\\d{2}\\b","#").replaceAll("\\b\\d+\\.\\d{2}\\b","#");return s.length()>700?s.substring(0,700):s;}
    private String normalize(String s){return s==null?"":s.replace('\n',' ').replaceAll("\\s+"," ").trim();}

    private String rootText(AccessibilityNodeInfo root){StringBuilder out=new StringBuilder();ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);int seen=0;while(!q.isEmpty()&&seen++<900){AccessibilityNodeInfo n=q.removeFirst();String t=text(n);if(!t.isEmpty())out.append(t).append(' ');for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return out.toString();}

    private boolean clickExactText(AccessibilityNodeInfo root,String[] wanted){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));
            if(!t.isEmpty()&&!ODDS.matcher(t).find())for(String w:wanted)if(t.equalsIgnoreCase(normalize(w))){if(clickNodeOrParent(n))return true;}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }return false;
    }
    private boolean clickContainsText(AccessibilityNodeInfo root,String[] wanted){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));String low=t.toLowerCase(Locale.US);
            if(!t.isEmpty()&&!ODDS.matcher(t).find())for(String w:wanted){String z=w.toLowerCase(Locale.US);if(low.equals(z)||low.startsWith(z+" ")){if(clickNodeOrParent(n))return true;}}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }return false;
    }
    private boolean clickNodeOrParent(AccessibilityNodeInfo n){AccessibilityNodeInfo c=n;for(int i=0;i<5&&c!=null;i++){if(c.isClickable()){c.performAction(AccessibilityNodeInfo.ACTION_CLICK);return true;}c=c.getParent();}return false;}
    private String text(AccessibilityNodeInfo n){String a=n.getText()==null?"":n.getText().toString();String b=n.getContentDescription()==null?"":n.getContentDescription().toString();return (a+" "+b).trim();}

    private boolean scroll(AccessibilityNodeInfo root,boolean down){AccessibilityNodeInfo sc=findScrollable(root);if(sc!=null&&sc.performAction(down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))return true;int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;Path p=new Path();p.moveTo(w*.5f,down?hg*.76f:hg*.34f);p.lineTo(w*.5f,down?hg*.34f:hg*.76f);return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,320)).build(),null,null);}
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root){ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);while(!q.isEmpty()){AccessibilityNodeInfo n=q.removeFirst();if(n.isScrollable())return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return null;}

    private void showHighlight(int x,int y,String label,boolean test){
        try{
            WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);final TextView v=new TextView(this);v.setText(label);v.setTextColor(Color.WHITE);v.setTextSize(15);v.setPadding(22,14,22,14);v.setElevation(18f);
            GradientDrawable bg=new GradientDrawable();bg.setColor(test?0xDD6A4C00:0xDD087F73);bg.setCornerRadius(28);bg.setStroke(5,test?0xFFFFC34A:0xFF35E4D1);v.setBackground(bg);
            int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP|Gravity.START;lp.x=Math.max(8,Math.min(w-420,x-330));lp.y=Math.max(80,Math.min(hg-180,y-60));wm.addView(v,lp);
            if(h!=null)h.postDelayed(()->{try{wm.removeView(v);}catch(Exception ignored){}},8000);
        }catch(Exception ignored){}
    }
    public static void highlightSelection(int x,int y,String label,boolean test){HardRockAccessibilityService s=instance;if(s==null)return;if(s.h!=null)s.h.post(()->s.showHighlight(x,y,label,test));}

    public static void launchHardRock(Context c){String pkg="com.hardrockdigital.client";try{Intent i=c.getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);c.startActivity(i);return;}}catch(Exception ignored){}try{c.startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("market://details?id="+pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){}}
    public static void tapSafeEvent(int x,int y){HardRockAccessibilityService s=instance;if(s==null)return;Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();s.dispatchGesture(g,null,null);}
    public static void tapNavigation(int x,int y,String sport){HardRockAccessibilityService s=instance;if(s==null)return;Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,75)).build();s.dispatchGesture(g,null,null);s.activeSport=sport;s.sportEnteredAt=System.currentTimeMillis();s.scrollCount=0;s.lastSport=System.currentTimeMillis();}
    public static void swipeSportsFromVision(boolean left){HardRockAccessibilityService s=instance;if(s!=null)s.swipeSportsBar(left);}
}
