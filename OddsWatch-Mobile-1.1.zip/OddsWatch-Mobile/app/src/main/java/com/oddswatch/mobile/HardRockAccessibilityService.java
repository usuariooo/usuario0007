package com.oddswatch.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.*;
import android.content.*;
import android.graphics.Rect;
import android.os.*;
import android.view.accessibility.*;
import android.widget.Toast;
import org.json.*;
import java.util.*;
import java.util.regex.*;

/**
 * V7 primary reader. Reads ONLY the official Hard Rock Bet Android package through
 * Android Accessibility. It never clicks an odds/selection node and never places a wager.
 * Optional auto-explore is limited to LIVE/sport navigation and scrolling.
 */
public class HardRockAccessibilityService extends AccessibilityService implements SignalEngine.Listener {
    public static final String HARD_ROCK_PKG="com.hardrockdigital.client";
    public static final String ACTION_UPDATE="com.oddswatch.mobile.UPDATE";
    private static final Pattern AMERICAN=Pattern.compile("(?<!\\d)([+-](?:100|[1-9]\\d{2,3}))(?!\\d)");
    private final Handler h=new Handler(Looper.getMainLooper());
    private Store store; private SignalEngine engine;
    private boolean pending=false; private long lastExplore=0,lastScroll=0,lastLive=0;
    private int targetIndex=0;
    private final String[] targets={"Table Tennis","Table Tennis","eSports","Table Tennis","eSports","Basketball","Soccer","Table Tennis","Tennis","Baseball","Hockey","Volleyball","Football","Rugby","Handball","Darts","MMA","Boxing","Golf","Cricket","Auto Racing"};

    @Override protected void onServiceConnected(){
        store=new Store(this); engine=new SignalEngine(this,this);
        AccessibilityServiceInfo i=getServiceInfo();
        i.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS|AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;
        setServiceInfo(i);
        store.setReaderReady(true);
        store.setLastError("");
        h.post(loop);
        sendUpdate();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null||event.getPackageName()==null)return;
        if(!HARD_ROCK_PKG.contentEquals(event.getPackageName()))return;
        if(!store.scannerOn())return;
        scheduleScan(120);
    }
    @Override public void onInterrupt(){ }
    @Override public void onDestroy(){store=new Store(this);store.setReaderReady(false);h.removeCallbacksAndMessages(null);super.onDestroy();}

    private final Runnable loop=new Runnable(){@Override public void run(){
        try{
            if(store==null)store=new Store(HardRockAccessibilityService.this);
            if(store.scannerOn()){
                AccessibilityNodeInfo root=getRootInActiveWindow();
                if(root!=null&&root.getPackageName()!=null&&HARD_ROCK_PKG.contentEquals(root.getPackageName())){
                    scan(root);
                    long now=System.currentTimeMillis();
                    String openTarget=store.openTarget();
                    if(!openTarget.isEmpty()){
                        if(now-store.openTargetAt()>15000)store.clearOpenTarget();
                        else if(tryOpenEvent(root,openTarget)){store.clearOpenTarget();Toast.makeText(HardRockAccessibilityService.this,"Partido localizado en Hard Rock",Toast.LENGTH_SHORT).show();}
                    }
                    if(store.autoExplore()){
                        if(now-lastLive>12000){clickExactSafe(root,new String[]{"Live","En vivo"});lastLive=now;}
                        if(now-lastExplore>7000){String t=targets[targetIndex++%targets.length]; if(clickSportSafe(root,t))store.setCurrentSport(t); lastExplore=now;}
                        if(now-lastScroll>2300){scrollSafe(root);lastScroll=now;}
                    }
                } else if(store.scannerOn()){
                    store.setLastError("Para el modo gratis V7, deja la app oficial de Hard Rock abierta. OddsWatch la lee mediante Accesibilidad y te avisa por notificación.");
                }
            }
        }catch(Exception e){if(store!=null)store.setLastError("Lector V7: "+e.getMessage());}
        h.postDelayed(this,1000);
    }};

    private void scheduleScan(long delay){
        if(pending)return;pending=true;
        h.postDelayed(()->{pending=false;try{AccessibilityNodeInfo r=getRootInActiveWindow();if(r!=null)scan(r);}catch(Exception ignored){}},delay);
    }

    private void scan(AccessibilityNodeInfo root){
        if(root==null)return;
        try{
            JSONArray out=new JSONArray(); StringBuilder page=new StringBuilder(); HashSet<String> seen=new HashSet<>();
            walk(root,out,page,seen,0);
            String all=page.toString(); detectSport(all);
            int n=engine.ingestDom("hardrock-app://accessibility",out.toString());
            engine.ingestText("hardrock-app://accessibility","Hard Rock Bet",all);
            store.setLastScan(System.currentTimeMillis());store.setOddsSeen(n);store.setAccessNodesSeen(out.length());
            store.setCurrentUrl("hardrock-app://accessibility");
            if(n>0)store.setLastError("");
            else store.setLastError("Hard Rock está abierto, pero el árbol de Accesibilidad todavía no expone una cuota completa. Abre LIVE → Tenis de mesa o eSports y deja visibles los botones con +/− cuota.");
            sendUpdate();
        }catch(Exception e){store.setLastError("Lectura de interfaz: "+e.getMessage());}
    }

    private void walk(AccessibilityNodeInfo node,JSONArray out,StringBuilder page,Set<String>seen,int depth)throws Exception{
        if(node==null||depth>22||out.length()>1400)return;
        String own=label(node); if(!own.isEmpty()){if(page.length()<70000)page.append(own).append('\n');}
        String compact=compactSubtree(node,1,450);
        boolean candidate=AMERICAN.matcher(own).find()||((node.isClickable()||looksInteractive(node))&&AMERICAN.matcher(compact).find());
        if(candidate){
            AccessibilityNodeInfo p=node.getParent(),g=p==null?null:p.getParent();
            String button=AMERICAN.matcher(own).find()?own:compact;
            String parent=p==null?"":compactSubtree(p,1,650);
            String grand=g==null?"":compactSubtree(g,1,950);
            String context=chooseContext(node,1100);
            String key=button+"|"+context;
            if(seen.add(key)){
                JSONObject o=new JSONObject();o.put("button",button);o.put("parent",parent);o.put("grand",grand);o.put("context",context);o.put("href","");
                JSONObject a=new JSONObject();
                if(node.getViewIdResourceName()!=null)a.put("data-view-id",node.getViewIdResourceName());
                if(node.getClassName()!=null)a.put("data-class",String.valueOf(node.getClassName()));
                Rect r=new Rect();node.getBoundsInScreen(r);a.put("data-bounds",r.flattenToString());a.put("data-clickable",node.isClickable());
                o.put("attrs",a);out.put(o);
            }
        }
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo c=node.getChild(i);if(c!=null){walk(c,out,page,seen,depth+1);c.recycle();}}
    }

    private String chooseContext(AccessibilityNodeInfo n,int max){
        AccessibilityNodeInfo cur=AccessibilityNodeInfo.obtain(n);String best=compactSubtree(cur,2,max);
        for(int i=0;i<5;i++){
            AccessibilityNodeInfo p=cur.getParent();cur.recycle();if(p==null)break;cur=p;
            String t=compactSubtree(cur,2,max);int odds=countOdds(t);
            if(t.length()>=8&&t.length()<=max)best=t;
            if(odds>=2&&containsMarketWord(t))break;
        }
        cur.recycle();return best;
    }
    private int countOdds(String s){Matcher m=AMERICAN.matcher(s==null?"":s);int n=0;while(m.find()&&n<20)n++;return n;}
    private boolean containsMarketWord(String s){String x=(s==null?"":s).toLowerCase(Locale.US);String[]k={"winner","ganador","total","over","under","spread","handicap","set","game","round","match","moneyline","más de","menos de"};for(String z:k)if(x.contains(z))return true;return false;}
    private boolean looksInteractive(AccessibilityNodeInfo n){String c=n.getClassName()==null?"":String.valueOf(n.getClassName()).toLowerCase(Locale.US);return c.contains("button")||c.contains("chip")||c.contains("radio");}
    private String label(AccessibilityNodeInfo n){StringBuilder b=new StringBuilder();if(n.getText()!=null)b.append(n.getText());if(n.getContentDescription()!=null){if(b.length()>0)b.append(' ');b.append(n.getContentDescription());}return clean(b.toString());}
    private String compactSubtree(AccessibilityNodeInfo n,int levels,int max){StringBuilder b=new StringBuilder();collect(n,b,0,levels,max);String x=b.toString().replace(" | ","\n");return x.replaceAll("[\t ]+"," ").replaceAll("\n+","\n").trim();}
    private void collect(AccessibilityNodeInfo n,StringBuilder b,int d,int maxD,int max){if(n==null||d>maxD||b.length()>=max)return;String t=label(n);if(!t.isEmpty()){if(b.length()>0)b.append(" | ");b.append(t);}for(int i=0;i<n.getChildCount()&&b.length()<max;i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null){collect(c,b,d+1,maxD,max);c.recycle();}}}
    private String clean(String x){return x==null?"":x.replaceAll("\\s+"," ").trim();}

    private void detectSport(String all){String x=(all==null?"":all).toLowerCase(Locale.US);if(x.contains("table tennis")||x.contains("ping pong")||x.contains("tenis de mesa"))store.setCurrentSport("Table Tennis");else if(x.contains("esports")||x.contains("e-sports")||x.contains("ebasketball")||x.contains("esoccer")||x.contains("efootball"))store.setCurrentSport("eSports");}


    private boolean tryOpenEvent(AccessibilityNodeInfo root,String event){
        if(event==null||event.isEmpty())return false;
        String[] p=event.split("(?i)\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2);
        String a=p.length>0?p[0].trim():event.trim(), b=p.length>1?p[1].trim():"";
        List<AccessibilityNodeInfo> ns=root.findAccessibilityNodeInfosByText(a);
        if(ns==null)return false;
        for(AccessibilityNodeInfo n:ns){
            String around=compactSubtree(n,2,500).toLowerCase(Locale.US);
            boolean both=b.isEmpty()||around.contains(b.toLowerCase(Locale.US));
            if(both&&!AMERICAN.matcher(label(n)).find()&&safeClick(n)){for(AccessibilityNodeInfo z:ns)z.recycle();return true;}
        }
        for(AccessibilityNodeInfo z:ns)z.recycle();return false;
    }

    /** Never click any node that contains a betting price. */
    private boolean safeClick(AccessibilityNodeInfo n){if(n==null)return false;String t=compactSubtree(n,1,220);if(AMERICAN.matcher(t).find())return false;AccessibilityNodeInfo cur=AccessibilityNodeInfo.obtain(n);for(int i=0;i<4;i++){if(cur.isClickable()){boolean ok=cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);cur.recycle();return ok;}AccessibilityNodeInfo p=cur.getParent();cur.recycle();if(p==null)return false;cur=p;}cur.recycle();return false;}
    private boolean clickExactSafe(AccessibilityNodeInfo root,String[]names){for(String name:names){List<AccessibilityNodeInfo>ns=root.findAccessibilityNodeInfosByText(name);if(ns==null)continue;for(AccessibilityNodeInfo n:ns){String t=label(n);if(t.equalsIgnoreCase(name)&&safeClick(n)){for(AccessibilityNodeInfo z:ns)z.recycle();return true;}}for(AccessibilityNodeInfo z:ns)z.recycle();}return false;}
    private boolean clickSportSafe(AccessibilityNodeInfo root,String sport){if("Table Tennis".equals(sport))return clickExactSafe(root,new String[]{"Table Tennis","Ping Pong","Tenis de mesa"});if("eSports".equals(sport))return clickExactSafe(root,new String[]{"eSports","Esports","E-Sports"});return clickExactSafe(root,new String[]{sport});}
    private boolean scrollSafe(AccessibilityNodeInfo root){AccessibilityNodeInfo best=findScrollable(root,0);if(best==null)return false;boolean ok=best.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);best.recycle();return ok;}
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n,int depth){if(n==null||depth>18)return null;if(n.isScrollable())return AccessibilityNodeInfo.obtain(n);for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null){AccessibilityNodeInfo r=findScrollable(c,depth+1);c.recycle();if(r!=null)return r;}}return null;}

    @Override public void onNewSignal(Signal s){notifySignal(s);}
    @Override public void onDataChanged(){sendUpdate();}
    private void sendUpdate(){sendBroadcast(new Intent(ACTION_UPDATE).setPackage(getPackageName()));}
    private void notifySignal(Signal s){
        NotificationManager nm=getSystemService(NotificationManager.class);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("signals","Señales OddsWatch",NotificationManager.IMPORTANCE_HIGH));
        Intent x=new Intent(this,MainActivity.class).putExtra("tab","detected");PendingIntent pi=PendingIntent.getActivity(this,s.id.hashCode(),x,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        String text=s.instruction.isEmpty()?(s.selection+" "+s.odds):s.instruction;
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"signals"):new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle("OddsWatch • "+s.sport).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(s.event+"\n"+text+"\nScore "+Math.round(s.score)+"/99")).setContentIntent(pi).setAutoCancel(true);
        nm.notify(s.id.hashCode(),b.build());
    }
}
