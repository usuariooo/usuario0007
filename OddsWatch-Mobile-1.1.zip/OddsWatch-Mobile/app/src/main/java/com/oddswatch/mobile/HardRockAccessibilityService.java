package com.oddswatch.mobile;

import android.accessibilityservice.*;
import android.content.*;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.TextView;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Navigation helper for the official Hard Rock app.
 * It never clicks an odds/price node. It only opens navigation labels, scrolls,
 * opens an event name when VisionParser explicitly asks for a result check, and
 * backs out of stale/dead-end/detail screens.
 */
public class HardRockAccessibilityService extends AccessibilityService {
    private static HardRockAccessibilityService instance;
    private Store store; private Handler h;
    private long lastLaunch=0,lastLive=0,lastSport=0,lastScroll=0,lastBack=0;
    private long deadEndSince=0,detailSince=0,subPageSince=0;
    private long sportEnteredAt=0,lastSportBarSwipe=0,lastLiveSeek=0,lastHomeReset=0,lastLiveConfirmed=0;
    private int scrollCount=0,sportIndex=0,lastPageHash=0,stagnantTicks=0,failedScrolls=0;
    private long resolvedExitGestureAt=0;
    private int resolvedExitAttempts=0;
    private String activeSport="";
    private boolean liveMode=false;
    private boolean sportSwitchPending=false;
    private int liveSeekScrolls=0;


    private static final Pattern ODDS=Pattern.compile("(?<!\\d)(?:[+-](?:100|[1-9]\\d{2,3})|(?:1|[2-9]|[1-9]\\d)\\.\\d{2})(?!\\d)");
    // Deportes que el radar recorre en orden. Table Tennis y eSports quedan primero
    // porque son los mercados prioritarios y normalmente están disponibles 24/7.
    private static final String[] PRIORITY_SPORTS={
        "Table Tennis","E-Sports","Baseball","Basketball","Soccer","Tennis"
    };
    private static final String[] SPORTS=PRIORITY_SPORTS;

    @Override protected void onServiceConnected(){
        super.onServiceConnected(); instance=this; store=new Store(this); store.setReaderReady(true);
        h=new Handler(Looper.getMainLooper()); h.post(tick);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(store==null)return; CharSequence p=event.getPackageName(); if(p!=null)store.setForegroundPackage(p.toString());
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(store!=null)store.setReaderReady(false);if(h!=null)h.removeCallbacksAndMessages(null);if(instance==this)instance=null;super.onDestroy();}

    private final Runnable tick=new Runnable(){@Override public void run(){try{navigate();}catch(Exception ignored){}if(h!=null)h.postDelayed(this,900);}};

    private void navigate(){
        if(!store.scannerOn())return;
        long now=System.currentTimeMillis(); String fg=store.foregroundPackage();
        if(!"com.hardrockdigital.client".equals(fg)){
            resetPageTimers();
            if(store.dedicated()&&now-lastLaunch>3500){launchHardRock(this);lastLaunch=now;liveMode=false;activeSport="";sportEnteredAt=0;}
            return;
        }
        // ESCAPE POR TIMEOUT: este chequeo va al principio del ciclo para que la
        // navegación física tenga prioridad antes de cualquier búsqueda de LIVE/deportes.
        Signal timeoutTrackingEarly=store.trackingSignal();
        if(store.paperActive()&&timeoutTrackingEarly!=null&&"TIMEOUT_ESPERA".equals(timeoutTrackingEarly.status)){
            store.setResultStatus("🔄 NAVEGANDO ATRÁS: Límite de tiempo agotado. Abortando...");

            // Salida física segura: solo toca la flecha superior izquierda de Hard Rock.
            // No usamos GLOBAL_ACTION_BACK porque desde Home puede cerrar la aplicación.
            tapTopLeftBackGesture();

            // CANCELADA es solo el estado local de esta copia transitoria. El registro
            // histórico queda PENDIENTE para revisión y no altera el bankroll.
            timeoutTrackingEarly.status="CANCELADA";
            store.clearTrackingSignal();
            store.clearOpenTarget();

            activeSport=""; sportEnteredAt=0; scrollCount=0; failedScrolls=0; sportSwitchPending=false;
            resetPageTimers();
            return;
        }

        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return;
        String visible=normalize(rootText(root)); String low=visible.toLowerCase(Locale.US);
        String selected=selectedSport(root);
        if(!selected.isEmpty()&&!sportSwitchPending){
            activeSport=selected;
            if(sportEnteredAt==0)sportEnteredAt=now;
            store.setNavSport(canonicalSport(selected));
        }

        int pageHash=stableFingerprint(low).hashCode();
        if(pageHash==lastPageHash)stagnantTicks++;else{lastPageHash=pageHash;stagnantTicks=0;failedScrolls=0;}

        // RESULTADO RESUELTO: salir del detalle (Match/Games) con calma.
        // Un solo toque de flecha por intento, espaciado, para no saturar Hard Rock
        // ni interferir con el OCR. Nunca toca cuotas ni el bottom bar (Home/Games).
        long resultExitAt=store.resultExitAt();
        if(resultExitAt>0){
            String ev=store.resultExitEvent();
            boolean onResolvedEvent=trackingEventVisible(low,ev)||looksLikeEventDetail(low)||looksLikeCompetitionSubPage(low)||isDeadEnd(low)
                    ||looksLikeTableTennisEventPage(low);

            if(!onResolvedEvent){
                // Ya no estamos en el detalle: listo, el radar puede seguir.
                store.clearResultExit();
                resolvedExitGestureAt=0; resolvedExitAttempts=0;
                activeSport=""; sportEnteredAt=0; scrollCount=0; failedScrolls=0;
                detailSince=0; deadEndSince=0;
            } else {
                store.setResultStatus("✅ Resultado guardado. Saliendo del partido...");

                // Máx. 6 intentos, 2 s entre cada uno, UN solo toque ← por ciclo.
                boolean canTry=resolvedExitGestureAt==0 || now-resolvedExitGestureAt>=2000;
                if(canTry && resolvedExitAttempts<6){
                    boolean sent=clickExplicitBackControl(root);
                    if(!sent)sent=clickTopLeftClickable(root);
                    if(!sent)sent=tapTopLeftBackGesture();
                    resolvedExitGestureAt=now;
                    resolvedExitAttempts++;
                    lastBack=now;
                }

                // Tras ~12 s o 5 intentos soltamos la bandera. No spamear más gestos aquí.
                if(now-resultExitAt>12000 || resolvedExitAttempts>=5){
                    store.clearResultExit();
                    resolvedExitGestureAt=0; resolvedExitAttempts=0;
                    detailSince=now; // el timeout de detalle (abajo) hará UN reintento espaciado
                }
                return;
            }
        }

        // 1. ANCLA DE MARCADOR EN APUESTA ACTIVA
        Signal tracking = store.trackingSignal();
        if (tracking != null && "PENDIENTE".equals(tracking.status)) {
            boolean eventHere = trackingEventVisible(low, tracking.event);
            boolean finalHere = isDeadEnd(low) || low.contains("match completed") || low.contains("this game has ended") || low.contains("finished") || low.contains("finalizado") || low.contains("completed");

            if (finalHere) {
                if (deadEndSince == 0) deadEndSince = now;
                activeSport = tracking.sport; sportEnteredAt = now; store.setNavSport(tracking.sport);
                store.setResultStatus("🔒 Leyendo resultado final: " + tracking.event);
                if (now - deadEndSince < 6500) return;

                store.releaseTrackingSignal("⚠️ Final visible pero no pude confirmar automáticamente el mercado: " + tracking.event + " queda PENDIENTE; radar liberado.");
                tracking = null;
                safeBack(root, low); deadEndSince = 0; detailSince = 0; subPageSince = 0;
                return;
            }

            // SI ESTAMOS DENTRO DEL EVENTO (Match/Games Setka incluido):
            // Congelar navegación para que el OCR lea el marcador sin toques de salida.
            if (looksLikeEventDetail(low) || looksLikeTableTennisEventPage(low)) {
                activeSport = tracking.sport; sportEnteredAt = now; store.setNavSport(tracking.sport);

                // REGLA DEL ANCLA: Si bajó y perdimos de vista el marcador/nombres, sube INMEDIATAMENTE
                if (!eventHere && now - lastScroll > 1200) {
                    scroll(root, false); // false = Scroll HACIA ARRIBA
                    lastScroll = now;
                }

                // Se queda congelado ARRIBA para que VisionParser lea los puntos en vivo
                // y emita la notificación AUTO. Ningún safeBack aquí.
                return;
            }

            if (store.openTarget().isEmpty() || now - store.openTargetAt() > 32000) {
                store.setOpenTarget(tracking.event, tracking.sport);
            }
        }

        if(isDeadEnd(low)){
            if(tracking!=null&&"PENDIENTE".equals(tracking.status)){
                // Completed screens are handled above with a bounded grace period.
                store.setResultStatus("🔒 Leyendo resultado final: "+tracking.event);
                return;
            }
            if(deadEndSince==0)deadEndSince=now;
            if(now-deadEndSince>1600&&now-lastBack>1800){safeBack(root,low);deadEndSince=0;detailSince=0;subPageSince=0;}
            return;
        } else deadEndSince=0;

        // ============================================================================
        // 3. AUTO-ESCAPE DE SUB-LIGA PRE-MATCH
        // ============================================================================
        // Las palabras "upcoming"/"today at" también pueden aparecer en tarjetas del hub.
        // Por eso exigimos estructura de sub-liga real antes de salir; nunca lanzamos
        // GLOBAL_ACTION_BACK desde una pantalla no confirmada.
        if(looksLikePreMatchCompetitionSubPage(low)){
            store.setResultStatus("⚠️ Detectada sub-liga pre-match. Regresando a LIVE...");
            if(now-lastBack>1600)safeBack(root,low);
            return;
        }

        String target=store.openTarget();
        boolean targetActive=!target.isEmpty()&&now-store.openTargetAt()<45000;

        boolean detail=(looksLikeEventDetail(low)||looksLikeTableTennisEventPage(low))
                &&!hasConfirmedLiveHub(root,low);
        boolean subPage=looksLikeCompetitionSubPage(low)&&!hasConfirmedLiveHub(root,low);
        if(detail||subPage){
            if(detailSince==0)detailSince=now;
            boolean trackingPending=tracking!=null&&"PENDIENTE".equals(tracking.status);
            if(!trackingPending){
                long budget=targetActive?9000:4500;
                if(now-detailSince>budget&&now-lastBack>2200){
                    store.setResultStatus("↩️ Saliendo del detalle ←");
                    safeBack(root,low);
                    detailSince=now;
                    subPageSince=0;
                    return;
                }
            }
        } else detailSince=0;

        // Result checks temporarily own navigation. First reach LIVE, then the signal's sport,
        // then search for the event. This is independent of whatever sport the normal radar is on.
        if(targetActive){
            String targetSport=store.openTargetSport();
            boolean targetLive=hasConfirmedLiveHub(root,low)||looksLikeLiveContent(low)||(liveMode&&now-lastLiveConfirmed<3000);
            if(!targetLive){
                if(now-lastLive>1200&&tapLiveNowLabel(root)){lastLive=now;liveMode=false;return;}
                if(now-lastLiveSeek>900){scroll(root,false);lastLiveSeek=now;liveSeekScrolls++;}
                return;
            }
            liveMode=true;
            if(!targetSport.isEmpty()&&!sameSportLabel(activeSport,targetSport)){
                if(selectSportByName(root,targetSport)){
                    activeSport=targetSport;sportEnteredAt=now;store.setNavSport(targetSport);lastSport=now;scrollCount=0;
                    sportSwitchPending=false;
                    return;
                }
                if(now-lastSportBarSwipe>1800){swipeSportsBar(true);lastSportBarSwipe=now;}
                return;
            }
            // Si ya estamos en el detalle del evento buscado, no seguir scrolleando.
            if(looksLikeEventDetail(low)||looksLikeTableTennisEventPage(low)){
                if(trackingEventVisible(low,target)){
                    store.setResultStatus("🔒 Dentro del partido: "+target);
                    return;
                }
                // Entramos a un detalle equivocado: salir con la flecha ← y seguir buscando.
                if(now-lastBack>2000){
                    store.setResultStatus("↩️ Detalle incorrecto. Volviendo con ←");
                    safeBack(root,low);
                }
                return;
            }
            // Intentar tocar el nombre del evento visible (Accessibility) antes de scrollear.
            if(now-lastScroll>800&&tryTapEventName(root,target)){
                lastScroll=now;
                store.setResultStatus("👆 Abriendo partido: "+target);
                return;
            }
            // Scroll más pausado al buscar el partido (no 900 ms): evita pasar de largo.
            if(now-lastScroll>1500){
                boolean ok=scroll(root,(scrollCount++%8)<6);
                if(!ok)failedScrolls++;else failedScrolls=0;
                lastScroll=now;
            }
            if(now-store.openTargetAt()>38000){store.setResultStatus("No encontré aún: "+target);store.clearOpenTarget();failedScrolls=0;}
            return;
        }
        if(!target.isEmpty())store.clearOpenTarget();

        // After creating a signal, freeze navigation briefly so the user can read/act on it
        // and so the saved screenshot corresponds to the same market instead of the next screen.
        if(now-store.lastSignalAt()<12000)return;

        // HARD watchdog: dynamic odds must not keep Baseball/MLB or any other sport open forever.
        // Table tennis/eSports get longer because they are the priority; all other sports are sampled briefly.
        if((liveMode||hasConfirmedLiveHub(root,low))&&!activeSport.isEmpty()&&sportEnteredAt>0){
            long budget=sportBudget(activeSport);
            if(now-sportEnteredAt>budget){
                activeSport="";sportEnteredAt=0;scrollCount=0;failedScrolls=0;stagnantTicks=0;
                if(!hasConfirmedLiveHub(root,low)){
                    if(tapLiveNowLabel(root)){lastLive=now;liveMode=false;return;}
                    if(now-lastBack>1800){safeBack(root,low);return;}
                }
                // Already on the LIVE hub: allow the next sport to be selected immediately.
                lastSport=0;
            }
        }

        // A static page that ignores multiple scroll attempts should never hold the overnight radar hostage.
        if(store.dedicated()&&(liveMode||hasConfirmedLiveHub(root,low))&&stagnantTicks>=20&&failedScrolls>=2&&now-lastBack>2800){
            activeSport="";sportEnteredAt=0;lastSport=0;
            stagnantTicks=0;failedScrolls=0;return;
        }

        boolean liveHub=hasConfirmedLiveHub(root,low)||looksLikeLiveContent(low)||(liveMode&&now-lastLiveConfirmed<2600);

        // When we are on Home/Discover, do ONLY one job: reach LIVE.
        // Previous builds treated any page that merely showed MLB/Table Tennis tabs as the LIVE hub,
        // so the radar could sit forever on the main sportsbook screen.
        if(!liveHub){
            activeSport="";sportEnteredAt=0;scrollCount=0;sportSwitchPending=false;
            if(now-lastLive>1500){
                if(tapLiveNowLabel(root)){
                    // An attempted tap is NOT confirmation. Wait until OCR/accessibility sees the real Live hub.
                    liveMode=false;lastLive=now;liveSeekScrolls=0;lastSport=0;return;
                }
                lastLive=now;
            }

            // Search the Home page vertically for the Live Now section instead of touching MLB or another sport.
            if(store.dedicated()&&now-lastLiveSeek>900){
                // Hard Rock commonly opens below Live Now. Seek upward first, then make two
                // controlled downward passes instead of wandering around MLB for minutes.
                boolean down=(liveSeekScrolls%6)>=4;
                scroll(root,down);liveSeekScrolls++;lastLiveSeek=now;
                return;
            }

            // If the Home screen is stuck for a long time, re-anchor on Home and try again.
            if(store.dedicated()&&liveSeekScrolls>=10&&now-lastHomeReset>7000){
                if(clickExactText(root,new String[]{"Home","Inicio"})){
                    liveMode=false;liveSeekScrolls=0;lastHomeReset=now;lastLive=0;return;
                }
            }
            return; // NEVER choose a sport until LIVE is confirmed.
        } else {
            liveMode=true;liveSeekScrolls=0;
        }

        // ============================================================================
        // 1. OMITIR PORTADA STREAM Y ENTRAR DIRECTO A UN DEPORTE REAL
        // ============================================================================
        // No usamos low.contains("stream") porque muchas tarjetas LIVE muestran
        // "Stream Now" aunque ya estemos dentro de Table Tennis/eSports. Solo actuamos
        // cuando el nodo superior "Stream" está realmente seleccionado/marcado.
        if(activeSport.isEmpty()&&isStreamTabSelected(root)){
            store.setResultStatus("⏭️ Omitiendo portada Stream... Yendo directo a Table Tennis");
            if(selectSportByName(root,"Table Tennis")){
                activeSport="Table Tennis";sportEnteredAt=now;lastSport=now;
                scrollCount=0;failedScrolls=0;sportIndex=0;sportSwitchPending=false;
                store.setNavStep(0);store.setNavSport(canonicalSport("Table Tennis"));
            }
            return;
        }

        // Pick the next sport by its visible Accessibility label. We do NOT move the
        // horizontal strip while a sport is being scanned vertically.
        if(activeSport.isEmpty()&&now-lastSport>1200){
            String wanted=PRIORITY_SPORTS[sportIndex%PRIORITY_SPORTS.length];
            store.setResultStatus("🎯 Buscando directamente: "+wanted);

            if(selectSportByName(root,wanted)){
                lastSport=now;scrollCount=0;failedScrolls=0;activeSport=wanted;sportEnteredAt=now;
                store.setNavStep(sportIndex);store.setNavSport(canonicalSport(wanted));
                sportSwitchPending=false;
                return;
            }

            // Fallback único: si el texto está fuera de la ventana visible, desplazamos
            // la barra suavemente hacia la derecha UNA vez por intento. Nunca invertimos
            // automáticamente de lado a lado. En el siguiente tick se vuelve a buscar
            // el nombre antes de considerar otro gesto.
            if(now-lastSportBarSwipe>3000){
                swipeSportsBar(true);
                lastSportBarSwipe=now;
            }
            lastSport=now;
            return;
        }

        // ============================================================================
        // 2. BARRIDO VERTICAL (lista LIVE del deporte activo)
        // ============================================================================
        // Solo congelamos el barrido si hay tracking PENDIENTE o estamos en un detalle real.
        boolean onRealDetail=(looksLikeEventDetail(low)||looksLikeTableTennisEventPage(low))
                &&!hasConfirmedLiveHub(root,low);
        if(tracking!=null&&"PENDIENTE".equals(tracking.status)&&onRealDetail){
            return; // el bloque de ancla (arriba) ya maneja el detalle
        }
        if(!onRealDetail){
            if(activeSport.isEmpty())return;

            // ~1.6 s entre scrolls: humano, no robot; suficiente para OCR.
            if(now-lastScroll>1600){
                boolean moved=scroll(root,true);
                lastScroll=now;

                if(moved){
                    scrollCount++;
                    failedScrolls=0;
                    store.setResultStatus("📜 Escaneando bloque "+scrollCount+" en "+activeSport);
                }else{
                    failedScrolls++;
                    store.setResultStatus("📜 Fin de lista? "+activeSport+" ("+failedScrolls+"/3)");
                }

                if(failedScrolls>=3||scrollCount>=6){
                    store.setResultStatus("🔝 Fin de "+activeSport+". Siguiente deporte...");
                    scroll(root,false);
                    scrollCount=0;failedScrolls=0;
                    activeSport="";sportEnteredAt=0;
                    sportIndex=(sportIndex+1)%PRIORITY_SPORTS.length;
                    String nextSport=PRIORITY_SPORTS[sportIndex];
                    store.setResultStatus("🎯 Cambiando a: "+nextSport);
                    if(selectSportByName(root,nextSport)){
                        activeSport=nextSport;sportEnteredAt=now;lastSport=now;
                        store.setNavStep(sportIndex);store.setNavSport(canonicalSport(nextSport));
                        sportSwitchPending=false;
                    }else if(now-lastSportBarSwipe>3000){
                        swipeSportsBar(true);
                        lastSportBarSwipe=now;
                        lastSport=0;
                    }else{
                        lastSport=0;
                    }
                    return;
                }
            }
            return;
        }
    }

    // ============================================================================
    // NAVEGACIÓN DIRECTA POR TEXTO EN LA BARRA DE DEPORTES (SIN REBOTES)
    // ============================================================================
    private boolean selectSportByName(AccessibilityNodeInfo root,String sportName){
        if(root==null||sportName==null||sportName.trim().isEmpty())return false;
        int hgt=getResources().getDisplayMetrics().heightPixels;
        String[] aliases=labelsForSport(sportName);
        for(String alias:aliases){
            List<AccessibilityNodeInfo> nodes=root.findAccessibilityNodeInfosByText(alias);
            if(nodes==null)continue;
            for(AccessibilityNodeInfo node:nodes){
                if(node==null)continue;
                String nodeText=normalize(text(node));
                // findAccessibilityNodeInfosByText is substring based. Require the real sport
                // label so "Tennis" cannot accidentally select "Table Tennis".
                if(!sameSportLabel(nodeText,sportName))continue;
                Rect b=new Rect();node.getBoundsInScreen(b);
                // Sports tabs live in the upper strip. Ignore matching event/team text below it.
                if(b.centerY()>hgt*.30f)continue;
                AccessibilityNodeInfo target=node;
                int hops=0;
                while(target!=null&&!target.isClickable()&&hops++<5)target=target.getParent();
                if(target!=null&&target.isClickable()){
                    boolean ok=target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    if(ok)return true;
                }
            }
        }
        return false;
    }

    // Devuelve true únicamente cuando la pestaña superior Stream está seleccionada.
    // Esto evita confundir la pestaña con textos de tarjetas como "Stream Now".
    private boolean isStreamTabSelected(AccessibilityNodeInfo root){
        if(root==null)return false;
        int hgt=getResources().getDisplayMetrics().heightPixels;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();
            String t=normalize(text(n));
            Rect b=new Rect();n.getBoundsInScreen(b);
            if(t.equalsIgnoreCase("Stream")&&!b.isEmpty()&&b.centerY()<hgt*.30f&&(n.isSelected()||n.isChecked()))return true;
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        return false;
    }

    // Encabezados de liga/sección nunca deben tratarse como partidos individuales.
    private boolean isLeagueHeader(String text){
        if(text==null)return false;
        String t=normalize(text).toLowerCase(Locale.US);
        return t.contains("conference")||t.contains("esportsbattle")||t.contains("league")
                ||t.contains("setka cup")||t.contains("tt cup")||t.equals(">")||t.endsWith(" >");
    }

    private boolean trackingEventVisible(String low,String event){
        if(low==null||event==null||event.isEmpty())return false;
        String[] p=event.toLowerCase(Locale.US).split("(?i)\\s+vs\\s+",2);
        if(p.length!=2)return low.contains(event.toLowerCase(Locale.US));
        String a=firstUsefulWord(p[0]),b=firstUsefulWord(p[1]);
        return !a.isEmpty()&&!b.isEmpty()&&low.contains(a)&&low.contains(b);
    }
    private String firstUsefulWord(String s){
        if(s==null)return "";for(String w:s.toLowerCase(Locale.US).replaceAll("[^a-z0-9à-ÿ._ -]"," ").split("\\s+"))if(w.length()>=3)return w;return "";
    }

    private boolean sameSportLabel(String a,String b){
        String x=canonicalSport(a==null?"":a).toLowerCase(Locale.US),y=canonicalSport(b==null?"":b).toLowerCase(Locale.US);
        if(x.isEmpty()||y.isEmpty())return false;
        if(x.contains("mesa")&&y.contains("mesa"))return true;
        if(x.contains("esport")&&y.contains("esport"))return true;
        return x.equals(y);
    }
    private String[] labelsForSport(String sport){
        String l=sport==null?"":sport.toLowerCase(Locale.US);
        if(l.contains("mesa")||l.contains("table tennis")||l.contains("ping pong"))return new String[]{"Table Tennis","Ping Pong"};
        if(l.contains("esport"))return new String[]{"eSports","E-Sports","Esports"};
        if(l.contains("béisbol")||l.contains("beisbol")||l.contains("baseball")||l.equals("mlb"))return new String[]{"MLB","Baseball"};
        if(l.contains("baloncesto")||l.contains("basketball"))return new String[]{"Basketball"};
        if(l.contains("fútbol americano")||l.contains("football"))return new String[]{"Football","NFL"};
        if(l.contains("fútbol")||l.contains("futbol")||l.contains("soccer"))return new String[]{"Soccer"};
        if(l.equals("tenis")||l.equals("tennis"))return new String[]{"Tennis"};
        if(l.contains("hockey"))return new String[]{"Hockey"};
        if(l.contains("golf")||l.contains("pga"))return new String[]{"PGA","Golf"};
        return new String[]{sport};
    }
    private long sportBudget(String s){String l=s==null?"":s.toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong")||l.contains("mesa"))return 90000; if(l.contains("sport"))return 60000; return 12000;}
    private String canonicalSport(String s){String l=s==null?"":s.toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong"))return "Tenis de mesa";if(l.contains("sport"))return "eSports";if(l.equals("mlb")||l.contains("baseball"))return "Béisbol";if(l.contains("basketball"))return "Baloncesto";if(l.contains("soccer"))return "Fútbol";if(l.equals("tennis"))return "Tenis";if(l.contains("hockey"))return "Hockey";if(l.contains("football")||l.equals("nfl"))return "Fútbol americano";if(l.contains("pga")||l.contains("golf"))return "Golf";return s;}
    private String selectedSport(AccessibilityNodeInfo root){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));if((n.isSelected()||n.isChecked())&&!t.isEmpty()&&!ODDS.matcher(t).find()){for(String w:SPORTS)if(sameSportLabel(t,w))return w;}for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}
        return "";
    }

    private boolean swipeSportsBar(boolean left){
        try{
            int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;
            Path p=new Path();float y=hg*.165f;p.moveTo(left?w*.78f:w*.22f,y);p.lineTo(left?w*.22f:w*.78f,y);
            return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,260)).build(),null,null);
        }catch(Exception e){return false;}
    }

    private void resetPageTimers(){deadEndSince=0;detailSince=0;subPageSince=0;stagnantTicks=0;failedScrolls=0;}

    // BACK POLICY: preferimos controles explícitos/gestos de la flecha superior izquierda.
    // GLOBAL_ACTION_BACK queda reservado como rompecircuitos cuando la pantalla lleva
    // varios ticks estancada y no se ha confirmado el Hub principal de LIVE.
    private void safeBack(AccessibilityNodeInfo root,String low){
        if(root==null)return;
        long now=System.currentTimeMillis();
        if(now-lastBack<2000)return;

        boolean provenSubPage=isDeadEnd(low)||looksLikeEventDetail(low)||looksLikeCompetitionSubPage(low)||looksLikeTableTennisEventPage(low);
        // Watchdog de escape: si llevamos varios ticks estancados en una pantalla no reconocida
        // (menú equivocado, ajustes o subpágina rara), permitimos intentar salir.
        // Nunca usamos Back global desde la raíz de Hard Rock.
        boolean onRoot=isHardRockRoot(root,low);
        if(!provenSubPage){
            if(onRoot||stagnantTicks<4)return;
        }

        // 1) Nodo Back real si Accessibility lo expone.
        boolean sent=clickExplicitBackControl(root);
        // 2) Cualquier clickable pequeño en la esquina superior izquierda (flecha ←).
        if(!sent)sent=clickTopLeftClickable(root);
        // 3) Gesto en la zona de la flecha ←.
        if(!sent)sent=tapTopLeftBackGesture();
        // 4) Último recurso: sólo fuera de la raíz y tras varios ticks realmente estancados.
        if(!sent&&!onRoot&&stagnantTicks>=8){
            performGlobalAction(GLOBAL_ACTION_BACK);
            sent=true;
        }

        if(sent){
            lastBack=now;activeSport="";sportEnteredAt=0;scrollCount=0;failedScrolls=0;
        }
    }

    private boolean tapTopLeftBackGesture(){
        try{
            int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;
            // Coordenadas Y más bajas (~6.5–9 %) para esquivar la status bar y pegar en la
            // flecha real de Hard Rock en distintos dispositivos.
            float[][] pts={{0.07f,0.08f},{0.09f,0.075f},{0.06f,0.09f},{0.08f,0.065f},{0.07f,0.055f},{0.10f,0.085f}};
            int idx=Math.floorMod(Math.max(resolvedExitAttempts,0),pts.length);
            Path p=new Path();
            p.moveTo(w*pts[idx][0],hgt*pts[idx][1]);
            return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,110)).build(),null,null);
        }catch(Exception e){return false;}
    }

    /** Clickable pequeño en la esquina superior izquierda = flecha atrás de Hard Rock. */
    private boolean clickTopLeftClickable(AccessibilityNodeInfo root){
        if(root==null)return false;
        int w=getResources().getDisplayMetrics().widthPixels;
        int hgt=getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo best=null;int bestArea=Integer.MAX_VALUE;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();
            Rect b=new Rect();n.getBoundsInScreen(b);
            // Zona ensanchada: en algunos dispositivos la flecha queda por debajo de la
            // status bar y puede bajar aproximadamente hasta el 17 % del alto.
            boolean topLeft=!b.isEmpty()&&b.centerX()<w*0.22f&&b.centerY()<hgt*0.17f;
            boolean smallEnough=b.width()>0&&b.width()<w*0.28f&&b.height()>0&&b.height()<hgt*0.16f;
            if(!b.isEmpty()&&n.isClickable()&&topLeft&&smallEnough){
                int area=b.width()*b.height();
                if(area<bestArea){bestArea=area;best=n;}
            }
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        if(best==null)return false;
        return best.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    /** Toca un nodo de Accessibility cuyo texto coincide con el evento buscado (no cuotas). */
    private boolean tryTapEventName(AccessibilityNodeInfo root,String event){
        if(root==null||event==null||event.isEmpty())return false;
        String[] parts=event.split("(?i)\s+vs\s+",2);
        int hgt=getResources().getDisplayMetrics().heightPixels;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        AccessibilityNodeInfo best=null;int bestScore=-1;
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();
            String t=normalize(text(n));
            if(t.isEmpty()||ODDS.matcher(t).find()||isLeagueHeader(t)){
                for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
                continue;
            }
            Rect b=new Rect();n.getBoundsInScreen(b);
            if(b.isEmpty()||b.centerY()<hgt*0.12f||b.centerY()>hgt*0.88f){
                for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
                continue;
            }
            String low=t.toLowerCase(Locale.US);
            int score=0;
            if(parts.length==2){
                String a=firstUsefulWord(parts[0]),bb=firstUsefulWord(parts[1]);
                if(!a.isEmpty()&&low.contains(a))score+=4;
                if(!bb.isEmpty()&&low.contains(bb))score+=4;
            }else if(low.contains(event.toLowerCase(Locale.US)))score+=6;
            if(score>=4&&score>bestScore){bestScore=score;best=n;}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        if(best==null)return false;
        AccessibilityNodeInfo target=best;int hops=0;
        while(target!=null&&!target.isClickable()&&hops++<6)target=target.getParent();
        if(target!=null&&target.isClickable())return target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        // Fallback: gesto en el centro del nodo de texto.
        Rect b=new Rect();best.getBoundsInScreen(b);
        Path p=new Path();p.moveTo(b.centerX(),b.centerY());
        return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build(),null,null);
    }

    private boolean clickExplicitBackControl(AccessibilityNodeInfo root){
        if(root==null)return false;
        int w=getResources().getDisplayMetrics().widthPixels;
        int hgt=getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo best=null;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();
            Rect b=new Rect();n.getBoundsInScreen(b);
            String t=normalize(text(n)).toLowerCase(Locale.US);
            boolean topLeft=!b.isEmpty()&&b.centerX()<w*.22&&b.centerY()<hgt*.18;
            boolean named=t.equals("back")||t.equals("navigate up")||t.equals("atrás")||t.equals("volver")||t.contains("navigate up");
            if(topLeft&&named){best=n;break;}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        if(best==null)return false;
        if(best.isClickable())return best.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        AccessibilityNodeInfo p=best.getParent();
        for(int i=0;i<3&&p!=null;i++){if(p.isClickable())return p.performAction(AccessibilityNodeInfo.ACTION_CLICK);p=p.getParent();}
        return false;
    }

    private boolean isHardRockRoot(AccessibilityNodeInfo root,String low){
        if(low==null)low="";
        // Bottom navigation labels are the strongest signal that we are at the sportsbook
        // root/home shell rather than inside an event or league detail page.
        boolean home=hasExactText(root,new String[]{"Home","Inicio"});
        boolean discover=hasExactText(root,new String[]{"Discover","Descubrir"});
        boolean games=hasExactText(root,new String[]{"Games","Juegos"});
        boolean account=hasExactText(root,new String[]{"Account","Cuenta"});
        boolean shell=(home&&discover&&account)||(home&&games&&account);
        if(!shell)return false;
        if(looksLikeEventDetail(low)||looksLikeCompetitionSubPage(low)||isDeadEnd(low))return false;
        return true;
    }

    private boolean hasExactText(AccessibilityNodeInfo root,String[] wanted){
        if(root==null)return false;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));
            if(!t.isEmpty())for(String w:wanted)if(t.equalsIgnoreCase(normalize(w)))return true;
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        return false;
    }

    private boolean isDeadEnd(String l){return l.contains("no bets currently available")||l.contains("check back again soon")||l.contains("this game has ended")||l.contains("match completed")||l.contains("final whistle has blown")||l.contains("view upcoming games")||l.contains("no wagers currently available")||l.contains("no markets currently available");}
    private boolean hasConfirmedLiveHub(AccessibilityNodeInfo root,String l){
        if(looksLikeLiveContent(l))return true;
        if(root==null)return false;
        int hgt=getResources().getDisplayMetrics().heightPixels;
        boolean topLive=false;int sportTabs=0;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));String low=t.toLowerCase(Locale.US);
            Rect b=new Rect();n.getBoundsInScreen(b);
            if((low.equals("live now")||low.equals("en vivo ahora"))&&b.top>=0&&b.top<hgt*.18)topLive=true;
            if(b.top>=0&&b.top<hgt*.30)for(String w:SPORTS)if(low.equals(w.toLowerCase(Locale.US))){sportTabs++;break;}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        return topLive&&sportTabs>=2;
    }

    private boolean tapLiveNowLabel(AccessibilityNodeInfo root){
        if(root==null)return false;
        int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo best=null;Rect bestBox=null;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));String low=t.toLowerCase(Locale.US);
            if(low.equals("live now")||low.equals("en vivo ahora")){
                Rect b=new Rect();n.getBoundsInScreen(b);
                // Never tap the top-right search/header zone, and do not re-tap the Live-page title at the top.
                if(!b.isEmpty()&&b.centerX()<w*.82&&b.top>hgt*.15&&b.top<hgt*.88){
                    if(best==null||b.top<bestBox.top){best=n;bestBox=b;}
                }
            }
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        if(bestBox==null)return false;
        // Tap the text bounds directly. Do NOT climb to a large clickable parent (that previously hit Search).
        Path p=new Path();p.moveTo(bestBox.centerX(),bestBox.centerY());
        return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build(),null,null);
    }
    private boolean looksLikeLiveContent(String l){
        // Solo señales del hub LIVE / tarjetas en vivo. NO usar "1st set" etc.:
        // eso también aparece en el detalle del partido y bloqueaba el scroll y la salida.
        if(l==null)return false;
        return l.contains("stream now")||l.contains("match completed")||l.contains("this game has ended");
    }
    private boolean looksLikeEventDetail(String l){
        if(l==null||l.isEmpty())return false;
        // Lista LIVE / hub: no es detalle de partido.
        if(l.contains("live now")||l.contains("en vivo ahora"))return false;
        boolean tabs=l.contains("popular")&&(l.contains("parlays")||l.contains("halves")||l.contains("goals")||l.contains("sets")||l.contains("points"));
        boolean ended=l.contains("match completed")||l.contains("this game has ended")||l.contains("no bets currently available");
        boolean tableDetail=looksLikeTableTennisEventPage(l);
        return tabs||ended||tableDetail;
    }

    /**
     * Setka / table-tennis EVENT DETAIL only (scoreboard + Match/Games under-tabs).
     * Must NOT match the LIVE list: bottom nav always has "Games", and league cards say "Setka".
     * Strong signals: "1st/2nd/…/6th Set" stage label, or Match+Games together with Setka AND no Live hub.
     */
    private boolean looksLikeTableTennisEventPage(String l){
        if(l==null||l.isEmpty())return false;
        // Live hub / sport list — never treat as event detail.
        if(l.contains("live now")||l.contains("en vivo ahora"))return false;
        boolean league=l.contains("setka")||l.contains("tt cup")||l.contains("liga pro table");
        boolean strongStage=l.contains("1st set")||l.contains("2nd set")||l.contains("3rd set")
                ||l.contains("4th set")||l.contains("5th set")||l.contains("6th set")||l.contains("7th set");
        // Under-tabs of the event page (not the bottom-nav "Games" alone).
        boolean matchAndGames=l.contains("match")&&l.contains("games");
        if(strongStage&&(league||matchAndGames))return true;
        // Match + Games + Setka without stage text (some devices omit "6th Set" in a11y).
        if(league&&matchAndGames)return true;
        return false;
    }
    private boolean looksLikeCompetitionSubPage(String l){
        if(looksLikeLiveContent(l))return false;
        // Competition/league pages commonly have a title followed by a single "Games" tab.
        boolean gamesTab=l.contains(" games ")||l.endsWith(" games")||l.startsWith("games ");
        boolean leagueWords=l.contains(" series")||l.contains(" league")||l.contains(" germany")||l.contains(" cup")||l.contains(" tournament")||l.contains("conference")||l.contains("esportsbattle");
        boolean schedule=l.contains("streaming soon")||l.contains("today,")||l.contains("tomorrow,")||l.contains("starts in")||l.contains("upcoming")||l.contains("today at");
        return gamesTab&&(leagueWords||schedule);
    }

    private boolean looksLikePreMatchCompetitionSubPage(String l){
        if(l==null||l.isEmpty()||looksLikeEventDetail(l)||looksLikeLiveContent(l))return false;
        boolean schedule=l.contains("starts in")||l.contains("upcoming")||l.contains("today at")||l.contains("streaming soon")||l.contains("tomorrow,");
        return schedule&&looksLikeCompetitionSubPage(l);
    }
    private String stableFingerprint(String l){String s=l.replaceAll("\\b\\d{1,2}:\\d{2}\\b","#").replaceAll("\\b\\d+\\.\\d{2}\\b","#");return s.length()>700?s.substring(0,700):s;}
    private String normalize(String s){return s==null?"":s.replace('\n',' ').replaceAll("\\s+"," ").trim();}

    private String rootText(AccessibilityNodeInfo root){StringBuilder out=new StringBuilder();ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);int seen=0;while(!q.isEmpty()&&seen++<900){AccessibilityNodeInfo n=q.removeFirst();String t=text(n);if(!t.isEmpty())out.append(t).append(' ');for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return out.toString();}

    private boolean clickExactText(AccessibilityNodeInfo root,String[] wanted){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));
            if(!t.isEmpty()&&!ODDS.matcher(t).find())for(String w:wanted)if(t.equalsIgnoreCase(normalize(w))){if(clickNodeOrParent(n))return true;}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }return false;
    }
    private boolean clickContainsText(AccessibilityNodeInfo root,String[] wanted){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));String low=t.toLowerCase(Locale.US);
            if(!t.isEmpty()&&!ODDS.matcher(t).find())for(String w:wanted){String z=w.toLowerCase(Locale.US);if(low.equals(z)||low.startsWith(z+" ")){if(clickNodeOrParent(n))return true;}}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }return false;
    }
    private boolean clickNodeOrParent(AccessibilityNodeInfo n){
        if(n==null||isLeagueHeader(text(n)))return false;
        AccessibilityNodeInfo c=n;
        for(int i=0;i<5&&c!=null;i++){
            if(c.isClickable()){c.performAction(AccessibilityNodeInfo.ACTION_CLICK);return true;}
            c=c.getParent();
        }
        return false;
    }
    private String text(AccessibilityNodeInfo n){String a=n.getText()==null?"":n.getText().toString();String b=n.getContentDescription()==null?"":n.getContentDescription().toString();return (a+" "+b).trim();}

    private boolean scroll(AccessibilityNodeInfo root,boolean down){AccessibilityNodeInfo sc=findScrollable(root);if(sc!=null&&sc.performAction(down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))return true;int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;Path p=new Path();p.moveTo(w*.5f,down?hg*.76f:hg*.34f);p.lineTo(w*.5f,down?hg*.34f:hg*.76f);return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,320)).build(),null,null);}
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root){ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);while(!q.isEmpty()){AccessibilityNodeInfo n=q.removeFirst();if(n.isScrollable())return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return null;}

    private void showHighlight(int x,int y,String label,boolean test){
        try{
            WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);final TextView v=new TextView(this);v.setText(label);v.setTextColor(Color.WHITE);v.setTextSize(15);v.setPadding(22,14,22,14);v.setElevation(18f);
            GradientDrawable bg=new GradientDrawable();bg.setColor(test?0xDD6A4C00:0xDD087F73);bg.setCornerRadius(28);bg.setStroke(5,test?0xFFFFC34A:0xFF35E4D1);v.setBackground(bg);
            int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP|Gravity.START;lp.x=Math.max(8,Math.min(w-420,x-330));lp.y=Math.max(80,Math.min(hg-180,y-60));wm.addView(v,lp);
            if(h!=null)h.postDelayed(()->{try{wm.removeView(v);}catch(Exception ignored){}},8000);
        }catch(Exception ignored){}
    }
    public static void highlightSelection(int x,int y,String label,boolean test){HardRockAccessibilityService s=instance;if(s==null)return;if(s.h!=null)s.h.post(()->s.showHighlight(x,y,label,test));}

    public static void launchHardRock(Context c){String pkg="com.hardrockdigital.client";try{Intent i=c.getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);c.startActivity(i);return;}}catch(Exception ignored){}try{c.startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("market://details?id="+pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){}}
    public static void tapSafeEvent(int x,int y){HardRockAccessibilityService s=instance;if(s==null)return;Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();s.dispatchGesture(g,null,null);}
    public static void tapNavigation(int x,int y,String sport){
        HardRockAccessibilityService s=instance;if(s==null)return;
        if("__LIVE__".equals(sport)){
            AccessibilityNodeInfo root=s.getRootInActiveWindow();
            boolean tapped=false;
            // First prefer the exact Accessibility node when Hard Rock exposes it.
            if(root!=null)tapped=s.tapLiveNowLabel(root);
            // Hard Rock often does NOT expose the Home "Live Now" card to Accessibility.
            // In that case Vision OCR has already verified the literal text and supplied its
            // screen coordinates. Use those coordinates, but only inside a conservative safe
            // content area so we can never hit the top-right Search icon.
            if(!tapped)s.tapVerifiedLiveOcrPoint(x,y);
            s.liveMode=false;s.activeSport="";s.sportEnteredAt=0;s.scrollCount=0;s.lastLive=System.currentTimeMillis();s.lastSport=0;s.liveSeekScrolls=0;
            return;
        }
        Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,75)).build();s.dispatchGesture(g,null,null);
        s.liveMode=true;s.lastLiveConfirmed=System.currentTimeMillis();s.activeSport=sport;s.sportEnteredAt=System.currentTimeMillis();s.scrollCount=0;s.lastSport=System.currentTimeMillis();s.sportSwitchPending=false;
        if(s.store!=null)s.store.setNavSport(s.canonicalSport(sport));
    }
    private boolean tapVerifiedLiveOcrPoint(int x,int y){
        try{
            int w=getResources().getDisplayMetrics().widthPixels;
            int hg=getResources().getDisplayMetrics().heightPixels;
            // OCR must point to the content area. Search/header controls live outside this box.
            if(x<=0||y<=0||x>w*.76f||y<hg*.10f||y>hg*.88f)return false;
            // Bias slightly toward the center of the Live Now row. This avoids tapping on the
            // left edge of the text while still staying far away from the search icon.
            float tx=Math.max(w*.18f,Math.min(w*.68f,x));
            float ty=Math.max(hg*.11f,Math.min(hg*.87f,y));
            Path p=new Path();p.moveTo(tx,ty);
            return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,90)).build(),null,null);
        }catch(Exception e){return false;}
    }

    public static void confirmLiveVisible(){HardRockAccessibilityService s=instance;if(s!=null){s.liveMode=true;s.lastLiveConfirmed=System.currentTimeMillis();s.liveSeekScrolls=0;}}
}
