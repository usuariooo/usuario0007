package com.oddswatch.mobile;

import android.content.Context;
import android.util.Base64;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public final class WhatsAppSender {
    public static String sendAlert(Context c,MarketAlert a)throws Exception{
        String full="⚡ OddsWatch • "+a.oneLine()+" • "+a.probabilityLine()+" • "+a.detail;
        return send(c,full,a.whatsappPart1(),a.whatsappPart2());
    }

    public static String sendTest(Context c)throws Exception{
        return send(c,"OddsWatch WhatsApp test: connection OK.","OddsWatch connection test","API + WhatsApp path is working");
    }

    private static String send(Context c,String body,String var1,String var2)throws Exception{
        String sid=Prefs.twSid(c).trim(), token=Prefs.twToken(c).trim();
        if(sid.isEmpty()||token.isEmpty())throw new IllegalStateException("Twilio Account SID/Auth Token missing. Enter a fresh token in Settings.");
        String from=norm(Prefs.twFrom(c)),to=norm(Prefs.waTo(c));
        if(from.length()<8||to.length()<8)throw new IllegalStateException("Twilio sender/recipient number is invalid.");
        String endpoint="https://api.twilio.com/2010-04-01/Accounts/"+URLEncoder.encode(sid,"UTF-8")+"/Messages.json";

        String contentSid=Prefs.twContentSid(c).trim();
        String base="From="+enc("whatsapp:"+from)+"&To="+enc("whatsapp:"+to);
        if(!contentSid.isEmpty()){
            String vars="{\"1\":\""+json(flat(var1,150))+"\",\"2\":\""+json(flat(var2,220))+"\"}";
            String withVars=base+"&ContentSid="+enc(contentSid)+"&ContentVariables="+enc(vars);
            PostResult r=post(endpoint,sid,token,withVars);
            if(r.ok())return r.body;
            // Twilio Tryout/Trial may restrict which template fields can be changed. Retry with the approved template alone.
            if(r.code>=400&&r.code<500){
                PostResult fallback=post(endpoint,sid,token,base+"&ContentSid="+enc(contentSid));
                if(fallback.ok())return fallback.body;
                throw new IOException("Twilio HTTP "+fallback.code+": "+shorten(fallback.body,500));
            }
            throw new IOException("Twilio HTTP "+r.code+": "+shorten(r.body,500));
        }else{
            PostResult r=post(endpoint,sid,token,base+"&Body="+enc(body));
            if(!r.ok())throw new IOException("Twilio HTTP "+r.code+": "+shorten(r.body,500));
            return r.body;
        }
    }

    private static PostResult post(String endpoint,String sid,String token,String data)throws Exception{
        HttpURLConnection h=(HttpURLConnection)new URL(endpoint).openConnection();
        h.setRequestMethod("POST");h.setDoOutput(true);h.setConnectTimeout(12000);h.setReadTimeout(18000);
        String auth=Base64.encodeToString((sid+":"+token).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
        h.setRequestProperty("Authorization","Basic "+auth);h.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
        try(OutputStream os=h.getOutputStream()){os.write(data.getBytes(StandardCharsets.UTF_8));}
        int code=h.getResponseCode();InputStream in=(code>=200&&code<300)?h.getInputStream():h.getErrorStream();
        PostResult r=new PostResult();r.code=code;r.body=read(in);return r;
    }

    private static class PostResult{int code;String body="";boolean ok(){return code>=200&&code<300;}}
    private static String norm(String s){s=s==null?"":s.trim();String d=s.replaceAll("[^0-9]","");return d.isEmpty()?"":"+"+d;}
    private static String flat(String s,int max){if(s==null)return"";s=s.replace('\n',' ').replace('\r',' ').trim();return s.length()<=max?s:s.substring(0,max-1)+"…";}
    private static String json(String s){return s.replace("\\","\\\\").replace("\"","\\\"");}
    private static String enc(String s)throws Exception{return URLEncoder.encode(s==null?"":s,"UTF-8");}
    private static String read(InputStream in)throws Exception{if(in==null)return"";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[2048];int n;while((n=in.read(z))>0)b.write(z,0,n);return b.toString(StandardCharsets.UTF_8.name());}
    private static String shorten(String s,int max){if(s==null)return"";s=s.replace('\n',' ').replace('\r',' ');return s.length()<=max?s:s.substring(0,max)+"…";}
    private WhatsAppSender(){}
}
