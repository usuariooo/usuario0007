package com.oddswatch.mobile;

import android.content.Context;
import android.util.Base64;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class WhatsAppSender {
    public static String send(Context c,String body) throws Exception {
        String sid=Prefs.twSid(c).trim(), token=Prefs.twToken(c).trim();
        if(sid.isEmpty()||token.isEmpty()) throw new IllegalStateException("Twilio SID/Auth Token missing");
        String endpoint="https://api.twilio.com/2010-04-01/Accounts/"+URLEncoder.encode(sid,"UTF-8")+"/Messages.json";

        StringBuilder data=new StringBuilder();
        data.append("From=").append(enc("whatsapp:"+Prefs.twFrom(c)));
        data.append("&To=").append(enc("whatsapp:"+Prefs.waTo(c)));

        String contentSid=Prefs.twContentSid(c).trim();
        if(!contentSid.isEmpty()) {
            // Twilio trial WhatsApp currently requires a pre-approved Content Template.
            // OddsWatch uses a two-variable template such as "Appointment Reminders".
            data.append("&ContentSid=").append(enc(contentSid));
            String shortBody=body==null?"OddsWatch alert":body.replace('\n',' ').trim();
            if(shortBody.length()>450) shortBody=shortBody.substring(0,450);
            String vars="{\"1\":\""+json("OddsWatch")+"\",\"2\":\""+json(shortBody)+"\"}";
            data.append("&ContentVariables=").append(enc(vars));
        } else {
            // Works for senders/accounts where free-form Body messaging is allowed.
            data.append("&Body=").append(enc(body));
        }

        HttpURLConnection h=(HttpURLConnection)new URL(endpoint).openConnection();
        h.setRequestMethod("POST");h.setDoOutput(true);h.setConnectTimeout(10000);h.setReadTimeout(15000);
        String auth=Base64.encodeToString((sid+":"+token).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
        h.setRequestProperty("Authorization","Basic "+auth);h.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
        try(OutputStream os=h.getOutputStream()){os.write(data.toString().getBytes(StandardCharsets.UTF_8));}
        int code=h.getResponseCode();InputStream in=(code>=200&&code<300)?h.getInputStream():h.getErrorStream();String resp=read(in);
        if(code<200||code>=300)throw new IOException("Twilio HTTP "+code+": "+resp);
        return resp;
    }
    private static String json(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\r"," ").replace("\n"," ");}
    private static String enc(String s)throws Exception{return URLEncoder.encode(s==null?"":s,"UTF-8");}
    private static String read(InputStream in)throws Exception{if(in==null)return"";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[2048];int n;while((n=in.read(z))>0)b.write(z,0,n);return b.toString(StandardCharsets.UTF_8.name());}
    private WhatsAppSender(){}
}
