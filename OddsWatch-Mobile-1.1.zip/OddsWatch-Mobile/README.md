# OddsWatch 6 — Actual Sportsbook App Reader

This build fixes the root cause of the V5 `0 selections` problem.

## Root cause fixed
V5 loaded `https://www.hardrock.bet/sportsbook`, which is the public marketing/education site. V6 loads `https://app.hardrock.bet/`, the JavaScript sportsbook app.

## V6 changes
- $0 external odds APIs; no The Odds API and no Twilio.
- Opens the actual Hard Rock Bet web app.
- Can select Florida from the state picker and shares WebView cookies/session between the HARD ROCK tab and the background scanner.
- Requests location permission because the sportsbook can use geolocation/state context.
- Reads actual clickable odds from document DOM, open shadow roots and same-origin iframes.
- Captures fetch/XHR JSON after the real app is loaded and uses it as a second source.
- Table Tennis and eSports are revisited much more frequently than other sports.
- Reads the current page every second.
- DETECTADAS now has two sections:
  1. model recommendations;
  2. real live markets currently read from the sportsbook (clearly labeled as not yet a recommendation).
- Exact Spanish fields: PARTIDO / MERCADO / SELECCIÓN / CUOTA.
- Selection IDs are converted to Hard Rock universal links using `https://app.hardrock.bet/?deep_link_value=betslip%2F<ID>` and opened with the installed Hard Rock Bet Android package when possible.
- Fresh storage namespace so false V4/V5 cards do not contaminate V6 history.

## First run
1. Open HARD ROCK inside OddsWatch.
2. If a state picker appears, choose Florida.
3. Log in there if Hard Rock requires it.
4. Open LIVE and Table Tennis once to confirm the real sportsbook lobby is visible.
5. Return to INICIO and enable the scanner.
6. DETECTADAS should first show `Mercados reales leídos ahora`; recommendations appear only when the local model has enough score/market data.

## Limitation
Hard Rock does not expose a documented public full-sportsbook developer API. This build reads only data the real web app exposes locally to the device. It does not place or confirm wagers. A recommendation is a model estimate, not a guarantee of a winning wager.
