# OddsWatch Free 3.0

No paid odds API. No Twilio. No embedded secrets.

## What it does
- Loads Hard Rock Bet in an Android WebView and reads what the page itself renders.
- Captures visible text plus JSON/XHR/fetch responses that the Hard Rock page exposes to its own browser session.
- Generic market parser: Match Winner, Set/Game Winner, totals, points, spreads/handicaps, correct score, props and other odds-like values.
- Table Tennis / Ping Pong and eSports (eBasketball, eSoccer, eFootball) receive priority, but all detected sports are accepted.
- Stores price history locally and waits for a second snapshot before showing a green `TOCAR` signal. First sightings are baseline/watch only.
- `DETECTED` tab shows the selection, odds, implied probability, movement, score, reason, and the latest Hard Rock page capture.
- Local Android notifications only. `SHARE` can send the signal through WhatsApp manually without a paid API.
- Does not log credentials, does not click bet/odds buttons, and does not place wagers.

## Important limitation
Hard Rock does not publish a free official developer odds feed. This app uses a local browser-reader approach. Website changes, login/geolocation requirements, or anti-automation behavior can break extraction. The DEBUG screen explicitly reports what was actually read instead of silently returning zero.

## Build using your existing GitHub workflow
The ZIP can be named `OddsWatch-Mobile-1.1.zip` and its project folder is `OddsWatch-Mobile`, so the v1.1 GitHub Action already used in this repository can compile it without changing the workflow.
