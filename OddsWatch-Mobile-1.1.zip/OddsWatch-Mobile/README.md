# OddsWatch 7 — lector local Hard Rock

V7 cambia completamente el método de lectura.

## Qué hace
- No usa The Odds API, Twilio ni ninguna API de pago.
- No usa app.hardrock.bet como fuente principal.
- Lee **solo la interfaz visible de la app oficial Hard Rock Bet** mediante un AccessibilityService restringido al paquete `com.hardrockdigital.client`.
- Prioriza Table Tennis / Ping Pong y eSports, pero rota por otros deportes si sus categorías están visibles.
- Relee cada segundo mientras Hard Rock está abierto.
- Puede hacer scroll y tocar solo categorías como LIVE/Table Tennis/eSports; el código bloquea cualquier clic automático sobre nodos que contengan una cuota americana.
- Guarda mercados detectados, señales, historial, resultados y estadísticas.
- El botón de una señal abre Hard Rock y el lector intenta localizar el evento por nombre, sin tocar la selección.

## Limitación importante
La opción 100% gratis necesita que **Hard Rock permanezca abierto en primer plano**. Android no permite a OddsWatch inspeccionar de forma fiable la interfaz de otra app mientras esa otra app está cerrada o en segundo plano. Para un radar 24/7 real sin mantener Hard Rock abierto haría falta una fuente de datos externa/servidor.

## Primer uso
1. Instala OddsWatch 7.
2. En OddsWatch toca `ACTIVAR LECTOR HARD ROCK`.
3. En Android Accesibilidad busca OddsWatch 7 / Lector Hard Rock y actívalo.
4. Vuelve a OddsWatch, enciende el scanner y toca `ABRIR HARD ROCK Y ESCANEAR`.
5. Deja Hard Rock abierto en LIVE. V7 intentará navegar categorías y hacer scroll sin pulsar cuotas.
6. Las señales llegan como notificación y quedan en DETECTADAS/HISTORIAL.

No realiza apuestas automáticamente.
