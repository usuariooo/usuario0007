# OddsWatch 4.0 — Español / Gratis

Rebuild focused on the requested workflow:

- Spanish UI.
- No The Odds API, no paid API key, no Twilio.
- Local Hard Rock browser reader.
- Reads current page every 1 second.
- Cycles sports automatically, with Table Tennis and eSports repeated in the cycle.
- DETECTADAS menu shows exactly PARTIDO / MERCADO / SELECCIÓN / CUOTA.
- Stores a screenshot of the Hard Rock page when a new signal appears.
- HISTORIAL persists every signal.
- Automatic outcome attempts for winner markets and totals when a final result becomes visible.
- Manual GANADA / PERDIDA / PUSH correction buttons.
- ESTADÍSTICAS: win rate, wins/losses/pending, simulated units, simulated ROI (1 unit per signal).
- ABRIR PARTIDO targets the installed Hard Rock Bet Android package (`com.hardrockdigital.client`) instead of intentionally opening a browser. When a specific event/deep-link is available, it is passed to the app; otherwise it falls back to opening the Hard Rock app.
- New dark navy + turquoise + gold design and adaptive launcher icon.

## Important

This free build can only analyze information that Hard Rock renders to the local browser/WebView. Hard Rock can change its site at any time. If the scanner gets 10 consecutive reads with zero odds, it shows an explicit diagnostic message instead of silently pretending that zero games were successfully analyzed.

The probability model is not a guarantee. Table-tennis signals use a local score-based estimator when a score can be read. Other sports use a deliberately conservative experimental score model. The Statistics screen is intended to verify whether the signals actually perform over time.

## Build

The repository includes `.github/workflows/build-apk-v4.yml`.

With Gradle 8.7 / Java 17:

```bash
gradle :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`
