# OddsWatch • Noche Virtual

Versión de simulación para dejar un dispositivo dedicado trabajando con Hard Rock Bet visible.

## Modo de prueba nocturna
- Bankroll virtual inicial: $30 (editable)
- Stake virtual fijo: $3 por señal (editable)
- Dinero real utilizado por OddsWatch: $0
- No pulsa cuotas, no añade selecciones al betslip y no confirma apuestas.
- OCR local aproximadamente cada segundo.
- Reconoce cuotas americanas (-120/+135) y decimales (1.45/2.60).
- Una señal se registra antes de conocer el resultado cuando la probabilidad implícita visible se mueve por encima del umbral.
- Limita las apuestas virtuales abiertas según el bankroll disponible.
- Guarda señal, captura, stake, ganancia potencial, resultado y P/L.
- Intenta resolver automáticamente mercados de ganador cuando el resultado final todavía es visible; lo no confirmado queda pendiente.

## Para dejarlo toda la noche
1. Instala/actualiza OddsWatch y mantén activo su servicio de Accesibilidad.
2. En OddsWatch toca **INICIAR NOCHE VIRTUAL**.
3. Acepta el permiso de captura de pantalla.
4. Inicia sesión normalmente en Hard Rock Bet si hace falta.
5. Deja el dispositivo conectado al cargador y Hard Rock visible.
6. OddsWatch intenta mantener LIVE abierto, prioriza Table Tennis/Ping Pong y eSports, y hace scroll automáticamente.
7. Por la mañana abre **ESTADÍSTICAS** y **HISTORIAL**.

Importante: esto es paper testing. El porcentaje observado en una sola noche no demuestra rentabilidad futura.

## Parser nocturno corregido
- Rechaza O/U, líneas, SGP y periodos como nombres de equipos/jugadores.
- Exige dos competidores reales antes de crear una señal.
- Etiqueta LIVE/PRE.
- Guarda un recorte vertical del evento/mercado, no la pantalla completa.
- En tenis de mesa intenta resolver automáticamente ganador de partido, ganador de set y total de puntos por set cuando el marcador visible permite confirmarlo.
