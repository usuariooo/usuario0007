# OddsWatch Final 2.0

Android-native personal sports-odds monitor for **Hard Rock Bet Florida**.

## What this version does

- Uses **real odds only**. There is no fake/demo market feed in v2.0.
- Targets The Odds API bookmaker key `hardrockbet_fl`.
- Compares Hard Rock FL with peer books such as DraftKings, FanDuel, BetMGM, BetRivers and theScore/ESPN Bet when available.
- Scans moneyline (`h2h`), spreads and totals.
- Covers live and pre-game events.
- Default major-sports mode; optional **ALL active sports** mode.
- Calculates:
  - Hard Rock implied probability
  - peer no-vig consensus probability
  - probability gap
  - expected-value estimate from the consensus probability
  - line gap vs peer median
  - quote-staleness difference vs peer updates
  - 0-99 anomaly score
- Foreground Android scanner with local notifications.
- WhatsApp alert support through Twilio.
- API quota display and a configurable reserve so a small API plan is not accidentally drained.
- API key and Twilio Auth Token are stored with the Android Keystore instead of being hard-coded in source.

## Important limitations

1. **A The Odds API key is required for real odds.** The app intentionally ships with no API key.
2. Hard Rock Bet Florida can occasionally be absent from a provider response if that bookmaker/market is temporarily unavailable.
3. Twilio Trial uses Twilio-provided approved WhatsApp templates. Trial accounts may not allow changing the full message body or all template variables. The app retries with the approved template if dynamic variables are rejected. Full alert details always remain available in the Android notification and inside OddsWatch.
4. Android can impose time limits on long-running foreground data-sync services. For guaranteed 24/7 monitoring even when Android stops the process, move the scanner to a server and use this app as the dashboard/notification client.
5. An anomaly is a market discrepancy, not a guaranteed winner.
6. This app does **not** sign into Hard Rock and does **not** place wagers.

## Security

Do not commit API keys, Twilio Auth Tokens, passwords or private signing keys to GitHub. If a Twilio Auth Token was ever pasted into a chat, screenshot, public repository or other exposed place, rotate it in Twilio before entering the replacement token in OddsWatch.

OddsWatch leaves all secrets blank at build time. Enter them once in the app; sensitive values are encrypted using the Android Keystore.

## Recommended first setup

1. Install the APK.
2. Enter your The Odds API key.
3. Tap **TEST REAL ODDS API**.
4. Configure Live/Pre, scan interval, anomaly threshold and API reserve.
5. For WhatsApp, enter recipient, Twilio sender, Account SID, a freshly rotated Auth Token and Content SID.
6. Tap **TEST WHATSAPP**.
7. Tap **SCAN REAL DATA NOW**.
8. When real Hard Rock markets are returned, the dashboard shows probabilities and anomaly metrics.
9. Turn **Scanner ON** after testing.

## GitHub build

The included project is standard Gradle/Android source. A workflow is included for repositories where the source is uploaded as files. If you upload the whole project as a ZIP instead, use the separate `build-oddswatch-final-v20.yml` supplied with this package/chat to unzip it and build the APK.

## Package

- App name: `OddsWatch Final`
- Application ID: `com.oddswatch.finalapp`
- Version: `2.0.0`
- Min Android SDK: 26
- Target/compile SDK: 35


COMPATIBILITY PACKAGE: This archive is OddsWatch Final 2.0 packaged as OddsWatch-Mobile-1.1.zip so the existing GitHub build-apk-v11 workflow can compile it without edits.
