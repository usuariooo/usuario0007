# OddsWatch

Versión única del proyecto Android.

## Cambios de recuperación/resultados
- El radar sale automáticamente de pantallas `Match Completed`, `This game has ended`, `No bets currently available` y similares para no quedarse atrapado toda la noche.
- En modo dedicado también abandona una pantalla de detalle después de ~12 s y vuelve al recorrido.
- Los resultados automáticos se guardan con origen `AUTO` y generan una notificación.
- El lector reconoce finales como `4 MAN vs LIV 6`, además de marcadores convencionales, y usa coincidencia/abreviaturas para asociarlos con señales pendientes.
- Tenis de mesa sigue resolviendo ganador del partido, ganador de set y totales de set cuando el marcador visible permite confirmarlo.
- Los resultados que no puedan comprobarse con certeza permanecen `PENDIENTE`.

No coloca apuestas reales ni pulsa cuotas.
