# OddsWatch 5 — Strict Market Reader

This build fixes the false-card problem seen in OddsWatch 4.

## What changed

- Spanish UI.
- No paid odds API and no Twilio dependency.
- The scanner no longer treats arbitrary Hard Rock page text/articles/examples as wagers.
- DOM scanner only accepts interactive controls (button/link/role=button) containing real American odds.
- Rejects editorial/tutorial phrases such as “for example”, “what kind of betting markets”, “how to bet”, FAQ/guide copy, etc.
- Requires a real two-side event + recognized market + recognized selection before a candidate is eligible.
- Exact signal card: PARTIDO / MERCADO / TOCA / CUOTA.
- Common markets translated to Spanish: match/set/game/round winner, totals, over/under, handicap/spread, correct score.
- Table-tennis local models now support current-set/game winner, total points, and point handicap when a visible score and numeric line can be read.
- Keeps history, win/loss/push manual correction, automatic result attempts, win rate and simulated ROI.
- Reads current visible betting controls every second.
- Does not follow Hard Rock SEO/article sport links when cycling sports.
- Deep-link support: when a real Hard Rock selection/outcome ID is exposed in DOM/network data, OddsWatch builds `hardrock://betslip/<selectionId>` and the button opens that selection in the installed Hard Rock Bet package. If no selection/event deep link is available, the UI explicitly says so and falls back to opening the app.

## Important limitation

Hard Rock does not expose a documented public developer API for its full sportsbook UI. This free build can only use information rendered/exposed locally to the phone. A specific event/selection deep link can only be opened when Hard Rock exposes enough identifiers/links for that market. The app does not place or confirm wagers.
