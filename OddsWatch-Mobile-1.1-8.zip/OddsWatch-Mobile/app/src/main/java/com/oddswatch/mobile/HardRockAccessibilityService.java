package com.oddswatch.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.*;
import android.content.*;
import android.graphics.Rect;
import android.os.*;
import android.view.accessibility.*;
import android.widget.Toast;
import org.json.*;
import java.util.*;
import java.util.regex.*;

/**
 * V8: free reader for the official Hard Rock Bet Android app.
 * It can navigate tabs/categories and scroll, but NEVER clicks any node containing a betting price.
 * Parsing is spatial: odds are linked to nearby participant and market labels on the visible event card.
 */
public class HardRockAccessibilityService extends AccessibilityService implements SignalEngine.Listener {
    public static final String HARD_ROCK_PKG="com.hardrockdigital.client";
    public static final String ACTION_UPDATE="com.oddswatch.mobile.UPDATE";
    private static final Pattern AMERICAN=Pattern.compile("(?<!\\d)([+-](?:100|[1-9]\\d{2,3}))(?!\\d)");
    private static final Pattern EVENT_LINE=Pattern.compile("(?i)^(.{2,55}?)\\s+(?:vs\\.?|v\\.?|@|contra)\\s+(.{2,55})$");
    private final Handler h=new Handler(Looper.getMainLooper());
    private Store store; private SignalEngine engine;
    private boolean pending=false, scrollForward=true;
    private long lastLive=0,lastScroll=0,lastSport=0,lastLaunch=0,lastOpenSearch=0;
    private int targetIndex=0;
    private final String[] targets={"Table Tennis","Table Tennis","eSports","Table Tennis","eSports","Basketball","Soccer","Tennis","Baseball","Hockey","Volleyball","Football","Rugby","Handball","Darts","MMA","Boxing","Golf","Cricket"};

    static class NodeRec {
        String text; Rect r; boolean clickable; String cls;
        NodeRec(String t,Rect b,boolean c,String k){text=t;r=b;clickable=c;cls=k;}
        int cy(){return (r.top+r.bottom)/2;} int cx(){return (r.left+r.right)/2;}
    }

    @Override protected void onServiceConnected(){
        store=new Store(this); engine=new SignalEngine(this,this);
        AccessibilityServiceInfo i=getServiceInfo();
        i.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS|AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;
        setServiceInfo(i);
        store.setReaderReady(true); store.setLastError(""); h.post(loop); sendUpdate();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null||event.getPackageName()==null)return;
        if(!HARD_ROCK_PKG.contentEquals(event.getPackageName()))return;
        if(!store.scannerOn())return;
        scheduleScan(80);
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(store!=null)store.setReaderReady(false);h.removeCallbacksAndMessages(null);super.onDestroy();}

    private final Runnable loop=new Runnable(){@Override public void run(){
        try{
            if(store==null)store=new Store(HardRockAccessibilityService.this);
            if(store.scannerOn()){
                AccessibilityNodeInfo root=getRootInActiveWindow(); long now=System.currentTimeMillis();
                if(isHardRock(root)){
                    scan(root);
                    String openTarget=store.openTarget();
                    if(!openTarget.isEmpty()){
                        if(now-store.openTargetAt()>60000){store.clearOpenTarget();store.setLastError("No pude localizar ese partido en 60 s. Puede haber terminado o Hard Rock no lo tiene visible en LIVE.");}
                        else {
                            if(tryOpenEvent(root,openTarget)){store.clearOpenTarget();Toast.makeText(HardRockAccessibilityService.this,"Partido abierto en Hard Rock",Toast.LENGTH_SHORT).show();}
                            else if(now-lastOpenSearch>750){ensureLive(root);scrollBrowse(root);lastOpenSearch=now;}
                        }
                    } else if(store.autoExplore()) {
                        if(now-lastLive>9000){ensureLive(root);lastLive=now;}
                        // Sports are a bonus. Main coverage comes from scanning the entire LIVE list while scrolling.
                        if(now-lastSport>18000){String t=targets[targetIndex++%targets.length];if(clickSportContainsSafe(root,t))store.setCurrentSport(t);lastSport=now;}
                        if(now-lastScroll>1250){scrollBrowse(root);lastScroll=now;}
                    }
                } else if(store.autoExplore() && now-lastLaunch>6000){
                    launchHardRock(); lastLaunch=now;
                    store.setLastError("Modo automático: abriendo Hard Rock para recorrer LIVE. No necesitas buscar los partidos manualmente.");
                }
            }
        }catch(Exception e){if(store!=null)store.setLastError("Radar V8: "+e.getMessage());}
        h.postDelayed(this,700);
    }};

    private boolean isHardRock(AccessibilityNodeInfo root){return root!=null&&root.getPackageName()!=null&&HARD_ROCK_PKG.contentEquals(root.getPackageName());}
    private void launchHardRock(){try{Intent i=getPackageManager().getLaunchIntentForPackage(HARD_ROCK_PKG);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}}catch(Exception ignored){}}

    private void scheduleScan(long delay){if(pending)return;pending=true;h.postDelayed(()->{pending=false;try{AccessibilityNodeInfo r=getRootInActiveWindow();if(isHardRock(r))scan(r);}catch(Exception ignored){}},delay);}

    private void scan(AccessibilityNodeInfo root){
        try{
            ArrayList<NodeRec> nodes=new ArrayList<>();StringBuilder page=new StringBuilder();collectFlat(root,nodes,page,0);
            Collections.sort(nodes,(a,b)->{int y=Integer.compare(a.r.top,b.r.top);return y!=0?y:Integer.compare(a.r.left,b.r.left);});
            JSONArray out=new JSONArray();HashSet<String>seen=new HashSet<>();int priceNodes=0;
            for(NodeRec nr:nodes){
                Matcher om=AMERICAN.matcher(nr.text);if(!om.find())continue;priceNodes++;
                String odds=om.group(1);String selection=selectionNear(nr,nodes,odds);String market=marketNear(nr,nodes);String event=eventNear(nr,nodes,selection);String ctx=contextNear(nr,nodes);
                if(event.isEmpty()||selection.isEmpty())continue;
                if(market.isEmpty()) market=inferMarket(nr,nodes,event,selection);
                JSONObject o=new JSONObject();o.put("button",nr.text);o.put("parent",ctx);o.put("grand",ctx);o.put("context",ctx);o.put("event",event);o.put("market",market);o.put("selection",selection);o.put("href","");
                JSONObject a=new JSONObject();a.put("data-bounds",nr.r.flattenToString());a.put("data-clickable",nr.clickable);a.put("data-class",nr.cls);o.put("attrs",a);
                String k=event+"|"+market+"|"+selection+"|"+odds;if(seen.add(k))out.put(o);
            }
            String all=page.toString();detectSport(all);
            int valid=engine.ingestDom("hardrock-app://accessibility-v8",out.toString());engine.ingestText("hardrock-app://accessibility-v8","Hard Rock Bet",all);
            store.setLastScan(System.currentTimeMillis());store.setOddsSeen(valid);store.setAccessNodesSeen(priceNodes);store.setCurrentUrl("hardrock-app://accessibility-v8");
            if(priceNodes==0)store.setLastError("Hard Rock está abierto, pero esta pantalla no muestra botones con cuota. OddsWatch intentará entrar a LIVE y seguir recorriendo automáticamente.");
            else if(valid==0)store.setLastError("Veo "+priceNodes+" precios, pero todavía no pude unirlos con nombres + mercado. V8 seguirá recorriendo la lista para capturar tarjetas completas.");
            else store.setLastError("");
            sendUpdate();
        }catch(Exception e){store.setLastError("Lectura V8: "+e.getMessage());}
    }

    private void collectFlat(AccessibilityNodeInfo n,List<NodeRec>out,StringBuilder page,int depth){
        if(n==null||depth>28||out.size()>2600)return;String t=label(n);if(!t.isEmpty()){
            Rect r=new Rect();n.getBoundsInScreen(r);if(!r.isEmpty()){String cls=n.getClassName()==null?"":String.valueOf(n.getClassName());out.add(new NodeRec(t,r,n.isClickable(),cls));}
            if(page.length()<100000)page.append(t).append('\n');
        }
        for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null){collectFlat(c,out,page,depth+1);c.recycle();}}
    }

    private String selectionNear(NodeRec price,List<NodeRec>nodes,String odds){
        String own=clean(price.text.replace(odds,""));if(validSelection(own))return own;
        NodeRec best=null;double bs=1e9;
        for(NodeRec n:nodes){if(n==price||hasOdds(n.text)||!validSelection(n.text))continue;int dy=Math.abs(n.cy()-price.cy());if(dy>115)continue;int dx=Math.abs(n.cx()-price.cx());double sc=dy*3+dx;if(n.r.right<price.r.left)sc-=120;if(sc<bs){bs=sc;best=n;}}
        return best==null?"":clean(best.text);
    }

    private String eventNear(NodeRec price,List<NodeRec>nodes,String selection){
        // Best case: Hard Rock exposes "A vs B" as one label.
        NodeRec bestLine=null;int bestDy=99999;
        for(NodeRec n:nodes){int dy=price.r.top-n.r.bottom;if(dy<0||dy>850)continue;if(EVENT_LINE.matcher(n.text).matches()&&validEventLine(n.text)){if(dy<bestDy){bestDy=dy;bestLine=n;}}}
        if(bestLine!=null)return normalizeEvent(bestLine.text);

        // Otherwise pair the two closest competitor-looking labels above the price in the same event card.
        ArrayList<NodeRec> cands=new ArrayList<>();
        for(NodeRec n:nodes){int dy=price.r.top-n.r.bottom;if(dy<20||dy>620)continue;if(!looksCompetitor(n.text))continue;if(n.r.right<price.r.left-260||n.r.left>price.r.right+260)continue;cands.add(n);}
        cands.sort((a,b)->Integer.compare(b.r.bottom,a.r.bottom));
        ArrayList<String> names=new ArrayList<>();
        if(validSelection(selection)&&looksCompetitor(selection))names.add(clean(selection));
        for(NodeRec n:cands){String z=clean(n.text);boolean dup=false;for(String q:names)if(similar(q,z))dup=true;if(!dup)names.add(z);if(names.size()>=4)break;}
        if(names.size()>=2){String a=names.get(0),b=names.get(1);if(similar(a,selection)&&names.size()>=3)b=names.get(2);return a+" vs "+b;}
        return "";
    }

    private String marketNear(NodeRec price,List<NodeRec>nodes){
        NodeRec best=null;int bd=99999;
        for(NodeRec n:nodes){int dy=price.r.top-n.r.bottom;if(dy<0||dy>360)continue;if(!containsMarketWord(n.text)||hasOdds(n.text))continue;if(dy<bd){bd=dy;best=n;}}
        return best==null?"":clean(best.text);
    }

    private String inferMarket(NodeRec price,List<NodeRec>nodes,String event,String selection){
        int sameRow=0;for(NodeRec n:nodes)if(hasOdds(n.text)&&Math.abs(n.cy()-price.cy())<90)sameRow++;
        if(sameRow>=2)return "Match Winner";
        String ctx=contextNear(price,nodes).toLowerCase(Locale.US);
        if(ctx.contains("set"))return "Set Winner";if(ctx.contains("game"))return "Game Winner";if(ctx.contains("round"))return "Round Winner";
        return "Match Winner";
    }

    private String contextNear(NodeRec p,List<NodeRec>nodes){StringBuilder b=new StringBuilder();for(NodeRec n:nodes){if(n.r.bottom<p.r.top-650||n.r.top>p.r.bottom+160)continue;if(b.length()>0)b.append('\n');b.append(n.text);if(b.length()>1800)break;}return b.toString();}

    private boolean validEventLine(String s){Matcher m=EVENT_LINE.matcher(clean(s));return m.matches()&&looksCompetitor(m.group(1))&&looksCompetitor(m.group(2));}
    private String normalizeEvent(String x){return clean(x).replaceAll("(?i)\\s+(?:v\\.?|contra)\\s+"," vs ").replaceAll("\\s+@\\s+"," vs ");}
    private boolean validSelection(String x){x=clean(x);if(x.length()<1||x.length()>65||hasOdds(x)||isNavJunk(x))return false;return !containsMarketWord(x)||x.matches("(?i).*(over|under|más de|menos de|[+-]\\d+(?:\\.\\d+)?).*?");}
    private boolean looksCompetitor(String x){x=clean(x);if(x.length()<2||x.length()>55||hasOdds(x)||containsMarketWord(x)||isNavJunk(x))return false;if(x.matches(".*\\b\\d{1,2}:\\d{2}\\b.*")||x.matches("^\\d+[-:]\\d+$"))return false;String l=x.toLowerCase(Locale.US);String[]bad={"league","liga","cup","tour","live","today","tomorrow","popular","featured","sports","table tennis","ping pong","esports","basketball","soccer","baseball","hockey","football","rugby","handball","tennis","volleyball"};for(String z:bad)if(l.equals(z)||l.startsWith(z+" "))return false;return x.split("\\s+").length<=7;}
    private boolean isNavJunk(String x){String l=clean(x).toLowerCase(Locale.US);String[]bad={"live","en vivo","sports","deportes","home","inicio","my bets","mis apuestas","betslip","bet slip","search","buscar","more","más","all","todos","close","back","login","sign in","join","cash out","boost","promotions","promos"};for(String z:bad)if(l.equals(z))return true;return false;}
    private boolean similar(String a,String b){a=clean(a).toLowerCase(Locale.US);b=clean(b).toLowerCase(Locale.US);return a.equals(b)||a.contains(b)||b.contains(a);}
    private boolean hasOdds(String s){return AMERICAN.matcher(s==null?"":s).find();}
    private boolean containsMarketWord(String s){String x=(s==null?"":s).toLowerCase(Locale.US);String[]k={"winner","ganador","total","over","under","spread","handicap","hándicap","set","game","round","match winner","moneyline","más de","menos de","correct score"};for(String z:k)if(x.contains(z))return true;return false;}
    private String label(AccessibilityNodeInfo n){StringBuilder b=new StringBuilder();if(n.getText()!=null)b.append(n.getText());if(n.getContentDescription()!=null){if(b.length()>0)b.append(' ');b.append(n.getContentDescription());}return clean(b.toString());}
    private String clean(String x){return x==null?"":x.replaceAll("\\s+"," ").trim();}

    private void detectSport(String all){String x=(all==null?"":all).toLowerCase(Locale.US);if(x.contains("table tennis")||x.contains("ping pong")||x.contains("tenis de mesa")||x.contains("tt cup")||x.contains("setka"))store.setCurrentSport("Table Tennis");else if(x.contains("esports")||x.contains("e-sports")||x.contains("ebasketball")||x.contains("esoccer")||x.contains("efootball"))store.setCurrentSport("eSports");}

    private boolean ensureLive(AccessibilityNodeInfo root){return clickContainsSafe(root,new String[]{"Live","En vivo","Live Now"});}
    private boolean clickSportContainsSafe(AccessibilityNodeInfo root,String sport){if("Table Tennis".equals(sport))return clickContainsSafe(root,new String[]{"Table Tennis","Ping Pong","Tenis de mesa"});if("eSports".equals(sport))return clickContainsSafe(root,new String[]{"eSports","Esports","E-Sports","eBasketball","eSoccer","eFootball"});return clickContainsSafe(root,new String[]{sport});}
    private boolean clickContainsSafe(AccessibilityNodeInfo root,String[]names){
        ArrayList<AccessibilityNodeInfo> all=new ArrayList<>();collectClickable(root,all,0);
        for(String name:names){String q=name.toLowerCase(Locale.US);for(AccessibilityNodeInfo n:all){String t=label(n).toLowerCase(Locale.US);if((t.equals(q)||t.contains(q))&&!hasOdds(t)&&safeClick(n)){recycle(all);return true;}}}
        recycle(all);return false;
    }
    private void collectClickable(AccessibilityNodeInfo n,List<AccessibilityNodeInfo>out,int d){if(n==null||d>20)return;if(n.isClickable()&&!label(n).isEmpty())out.add(AccessibilityNodeInfo.obtain(n));for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null){collectClickable(c,out,d+1);c.recycle();}}}
    private void recycle(List<AccessibilityNodeInfo>x){for(AccessibilityNodeInfo n:x)try{n.recycle();}catch(Exception ignored){}}

    /** Never click a node/ancestor whose local subtree contains an American betting price. */
    private boolean safeClick(AccessibilityNodeInfo n){if(n==null)return false;AccessibilityNodeInfo cur=AccessibilityNodeInfo.obtain(n);for(int i=0;i<5;i++){String t=compactSubtree(cur,1,350);if(hasOdds(t)){cur.recycle();return false;}if(cur.isClickable()){boolean ok=cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);cur.recycle();return ok;}AccessibilityNodeInfo p=cur.getParent();cur.recycle();if(p==null)return false;cur=p;}cur.recycle();return false;}
    private String compactSubtree(AccessibilityNodeInfo n,int levels,int max){StringBuilder b=new StringBuilder();collect(n,b,0,levels,max);return b.toString();}
    private void collect(AccessibilityNodeInfo n,StringBuilder b,int d,int maxD,int max){if(n==null||d>maxD||b.length()>=max)return;String t=label(n);if(!t.isEmpty()){if(b.length()>0)b.append(" | ");b.append(t);}for(int i=0;i<n.getChildCount()&&b.length()<max;i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null){collect(c,b,d+1,maxD,max);c.recycle();}}}

    private void scrollBrowse(AccessibilityNodeInfo root){AccessibilityNodeInfo sc=findScrollable(root,0);if(sc==null)return;int action=scrollForward?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD;boolean ok=sc.performAction(action);if(!ok){scrollForward=!scrollForward;sc.performAction(scrollForward?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);}sc.recycle();}
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n,int depth){if(n==null||depth>20)return null;if(n.isScrollable())return AccessibilityNodeInfo.obtain(n);for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null){AccessibilityNodeInfo r=findScrollable(c,depth+1);c.recycle();if(r!=null)return r;}}return null;}

    private boolean tryOpenEvent(AccessibilityNodeInfo root,String event){
        String[] p=event.split("(?i)\\s+(?:vs\\.?|v\\.?|@|contra)\\s+",2);if(p.length<2)return false;String a=clean(p[0]),b=clean(p[1]);
        List<AccessibilityNodeInfo> ns=root.findAccessibilityNodeInfosByText(a);if(ns==null||ns.isEmpty())return false;
        for(AccessibilityNodeInfo n:ns){Rect ra=new Rect();n.getBoundsInScreen(ra);if(findTextNear(root,b,ra,650)){if(clickEventContainer(n,a,b)){recycle(ns);return true;}}}
        recycle(ns);return false;
    }
    private boolean findTextNear(AccessibilityNodeInfo root,String q,Rect around,int maxDy){List<AccessibilityNodeInfo>ns=root.findAccessibilityNodeInfosByText(q);if(ns==null)return false;for(AccessibilityNodeInfo n:ns){Rect r=new Rect();n.getBoundsInScreen(r);if(Math.abs(((r.top+r.bottom)-(around.top+around.bottom))/2)<maxDy){recycle(ns);return true;}}recycle(ns);return false;}
    private boolean clickEventContainer(AccessibilityNodeInfo n,String a,String b){AccessibilityNodeInfo cur=AccessibilityNodeInfo.obtain(n);for(int i=0;i<7;i++){String t=compactSubtree(cur,3,1400).toLowerCase(Locale.US);if(t.contains(a.toLowerCase(Locale.US))&&t.contains(b.toLowerCase(Locale.US))&&!hasOdds(label(cur))&&cur.isClickable()){boolean ok=cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);cur.recycle();return ok;}AccessibilityNodeInfo p=cur.getParent();cur.recycle();if(p==null)return false;cur=p;}cur.recycle();return false;}

    @Override public void onNewSignal(Signal s){notifySignal(s);}
    @Override public void onDataChanged(){sendUpdate();}
    private void sendUpdate(){sendBroadcast(new Intent(ACTION_UPDATE).setPackage(getPackageName()));}
    private void notifySignal(Signal s){
        NotificationManager nm=getSystemService(NotificationManager.class);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("signals","Señales OddsWatch",NotificationManager.IMPORTANCE_HIGH));
        Intent x=new Intent(this,MainActivity.class).putExtra("tab","detected");PendingIntent pi=PendingIntent.getActivity(this,s.id.hashCode(),x,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        String text=s.instruction.isEmpty()?(s.selection+" "+s.odds):s.instruction;Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"signals"):new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat).setContentTitle("OddsWatch 8 • "+s.sport).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(s.event+"\n"+text+"\nScore "+Math.round(s.score)+"/99")).setContentIntent(pi).setAutoCancel(true);nm.notify(s.id.hashCode(),b.build());
    }
}
