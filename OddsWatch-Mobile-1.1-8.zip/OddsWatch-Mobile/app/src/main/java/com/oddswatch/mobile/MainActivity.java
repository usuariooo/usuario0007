package com.oddswatch.mobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(6,14,28), CARD=Color.rgb(17,32,55), CARD2=Color.rgb(25,45,72), ACC=Color.rgb(54,214,190), GOLD=Color.rgb(255,190,73), PURPLE=Color.rgb(149,117,255), RED=Color.rgb(255,105,120), TEXT=Color.rgb(248,250,255), MUTED=Color.rgb(157,176,198);
    private Store store; private LinearLayout root,content,nav; private TextView status; private Handler ui=new Handler(Looper.getMainLooper()); private String tab="home"; private BroadcastReceiver receiver;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);store=new Store(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);buildShell();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},20);
        String open=getIntent().getStringExtra("tab");if(open!=null)tab=open;render();
        receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){refreshStatus();if(!"browser".equals(tab))render();}};
        IntentFilter f=new IntentFilter(ScannerService.ACTION_UPDATE);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);ui.post(clock);
    }
    @Override public void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){}ui.removeCallbacksAndMessages(null);super.onDestroy();}
    private final Runnable clock=new Runnable(){public void run(){refreshStatus();if("detected".equals(tab)||"stats".equals(tab))render();ui.postDelayed(this,1000);}};

    private void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(16),dp(10),dp(16),dp(8));setContentView(root);
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);root.addView(head,new LinearLayout.LayoutParams(-1,-2));
        head.addView(txt("ODDSWATCH 8",30,true,TEXT));head.addView(txt("Lector de la app oficial • Ping pong + eSports • Español • $0 APIs",13,false,MUTED));
        status=txt("",14,true,ACC);status.setPadding(0,dp(8),0,dp(8));head.addView(status);refreshStatus();
        ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(4),0,dp(16));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);hs.addView(nav);root.addView(hs,new LinearLayout.LayoutParams(-1,dp(56)));
        navButton("INICIO","home");navButton("DETECTADAS","detected");navButton("HISTORIAL","history");navButton("ESTADÍSTICAS","stats");navButton("HARD ROCK","browser");navButton("AJUSTES","settings");
    }
    private void navButton(String name,String key){Button b=button(name,false);b.setOnClickListener(v->{tab=key;render();});nav.addView(b,new LinearLayout.LayoutParams(dp(132),dp(48)));}
    private void render(){if(content==null)return;content.removeAllViews();switch(tab){case"detected":renderDetected();break;case"history":renderHistory();break;case"stats":renderStats();break;case"browser":renderBrowser();break;case"settings":renderSettings();break;default:renderHome();}}

    private void renderHome(){
        title("Radar V8 • app oficial");
        LinearLayout c=card();
        c.addView(txt(store.scannerOn()?"● SCANNER ENCENDIDO":"○ SCANNER APAGADO",20,true,store.scannerOn()?ACC:MUTED));
        c.addView(txt("V8 recorre automáticamente LIVE dentro de la app oficial de Hard Rock. Ya no tienes que entrar tú deporte por deporte. Lee las tarjetas visibles y relaciona cada cuota con los nombres y el mercado por su posición en pantalla.",15,false,TEXT));
        c.addView(txt("MODO $0: al encender el radar, OddsWatch abre Hard Rock solo, entra a LIVE cuando puede y recorre la lista arriba/abajo cada ~1 segundo. Prioriza Ping Pong y eSports cuando esas categorías son visibles. Nunca pulsa una cuota ni confirma una apuesta.",13,false,MUTED));
        c.addView(kv("Lector Hard Rock",accessibilityEnabled()?"ACTIVO":"FALTA ACTIVAR"));
        Button perm=button(accessibilityEnabled()?"ABRIR AJUSTES DE ACCESIBILIDAD":"ACTIVAR LECTOR HARD ROCK",false);perm.setOnClickListener(v->openAccessibilitySettings());c.addView(perm);
        Switch sw=new Switch(this);sw.setText("Scanner automático");sw.setTextColor(TEXT);sw.setChecked(store.scannerOn());sw.setOnCheckedChangeListener((x,on)->toggleScanner(on));c.addView(sw);
        Button now=button("INICIAR RADAR AUTOMÁTICO",true);now.setOnClickListener(v->{if(!accessibilityEnabled()){openAccessibilitySettings();return;}if(!store.scannerOn())toggleScanner(true);launchHardRock();Toast.makeText(this,"Radar automático iniciado. Hard Rock se recorrerá solo; las señales llegan por notificación",Toast.LENGTH_LONG).show();});c.addView(now);content.addView(c);

        title("Qué está leyendo");LinearLayout d=card();
        d.addView(kv("Deporte actual",spanishSport(store.currentSport())));
        d.addView(kv("Selecciones reales",String.valueOf(store.oddsSeen())));
        d.addView(kv("Nodos con cuota detectados",String.valueOf(store.accessNodesSeen())));
        d.addView(kv("Lector",store.readerReady()?"Conectado":"No conectado"));
        String err=store.lastError();if(!err.isEmpty())d.addView(txt("DIAGNÓSTICO: "+err,14,true,RED));content.addView(d);

        title("Formato de las señales");LinearLayout e=card();
        e.addView(txt("PARTIDO: Jugador A vs Jugador B",15,true,TEXT));
        e.addView(txt("MERCADO: Ganador del set 3",15,true,TEXT));
        e.addView(txt("TOCA: Jugador A",19,true,GOLD));
        e.addView(txt("CUOTA: +125",19,true,ACC));
        e.addView(txt("También: Más de 20.5 puntos • Total del set • -110; hándicap; ganador del juego/ronda; etc., cuando Hard Rock los exponga en pantalla.",13,false,MUTED));content.addView(e);
    }
    private void renderDetected(){
        title("Jugadas recomendadas ahora");
        List<Signal>all=store.loadSignals();long now=System.currentTimeMillis();ArrayList<Signal>a=new ArrayList<>();
        for(Signal s:all)if("PENDIENTE".equals(s.status)&&now-s.updatedAt<120000)a.add(s);
        if(a.isEmpty()){LinearLayout c=card();c.addView(txt("Todavía no hay una recomendación del modelo.",17,true,TEXT));c.addView(txt("Abajo sí verás los mercados reales que OddsWatch está leyendo. Una recomendación solo aparece cuando el marcador/mercado permite calcular una señal sin inventar probabilidades.",13,false,MUTED));content.addView(c);}else for(Signal s:a)signalCard(s,true);

        title("Mercados reales leídos ahora");
        List<Signal>obs=store.loadObserved();ArrayList<Signal>live=new ArrayList<>();
        for(Signal s:obs)if(now-s.updatedAt<45000)live.add(s);
        if(live.isEmpty()){LinearLayout c=card();c.addView(txt("0 mercados reales leídos todavía.",17,true,RED));c.addView(txt("Activa Accesibilidad y toca INICIAR RADAR AUTOMÁTICO. V8 abre Hard Rock y recorre LIVE sin que tengas que buscar partido por partido.",13,false,MUTED));content.addView(c);return;}
        int shown=0;for(Signal s:live){if(shown++>=40)break;observedCard(s);}
    }

    private void observedCard(Signal s){
        LinearLayout c=card();c.addView(txt(("Tenis de mesa".equals(s.sport)?"🏓 ":"🎮 ")+s.sport,13,true,ACC));
        c.addView(txt(s.event,18,true,TEXT));
        c.addView(field("MERCADO",s.market,TEXT));
        c.addView(field("SELECCIÓN REAL",s.selection,GOLD));
        c.addView(field("CUOTA",s.odds,ACC));
        c.addView(txt("Mercado real detectado; no lo marco como recomendación hasta que el modelo tenga datos suficientes.",11,false,MUTED));
        Button open=button((s.deepLink!=null&&!s.deepLink.isEmpty())?"ABRIR SELECCIÓN EN HARD ROCK":"BUSCAR ESTE PARTIDO EN HARD ROCK",true);open.setOnClickListener(v->openHardRock(s));c.addView(open);
        content.addView(c);
    }

    private void signalCard(Signal s,boolean active){
        LinearLayout c=card();LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.addView(txt(("Tenis de mesa".equals(s.sport)?"🏓 ":"🎯 ")+s.sport,14,true,ACC),new LinearLayout.LayoutParams(0,-2,1));top.addView(txt(Math.round(s.score)+"/99",14,true,GOLD));c.addView(top);
        c.addView(txt(s.event,20,true,TEXT));
        LinearLayout exact=new LinearLayout(this);exact.setOrientation(LinearLayout.VERTICAL);exact.setPadding(dp(14),dp(12),dp(14),dp(12));exact.setBackground(round(Color.rgb(30,42,73),15));
        exact.addView(txt("JUGADA EXACTA",12,true,PURPLE));exact.addView(field("PARTIDO",s.event,TEXT));exact.addView(field("MERCADO",s.market,TEXT));exact.addView(field("TOCA",s.selection,GOLD));exact.addView(field("CUOTA",s.odds,ACC));c.addView(exact);
        if(!s.instruction.isEmpty()){TextView ins=txt(s.instruction,17,true,GOLD);ins.setPadding(0,dp(10),0,dp(5));c.addView(ins);}
        c.addView(txt(String.format(Locale.US,"Prob. estimada %.1f%% • cuota implica %.1f%% • diferencia +%.1f pp",s.modelProbability*100,s.implied*100,s.edge*100),13,true,ACC));
        boolean direct=s.deepLink!=null&&!s.deepLink.isEmpty();boolean eventLink=s.url!=null&&!s.url.isEmpty();c.addView(txt(direct?"✓ ENLACE DIRECTO A LA SELECCIÓN CAPTURADO":eventLink?"✓ ENLACE DEL EVENTO CAPTURADO":"⚠ Hard Rock no expuso un enlace profundo para esta selección",12,true,direct?ACC:(eventLink?GOLD:MUTED)));
        if(!s.screenshot.isEmpty()&&new File(s.screenshot).exists()){Bitmap b=BitmapFactory.decodeFile(s.screenshot);if(b!=null){ImageView im=new ImageView(this);im.setImageBitmap(b);im.setScaleType(ImageView.ScaleType.CENTER_CROP);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(180));ip.setMargins(0,dp(8),0,0);c.addView(im,ip);}}
        c.addView(txt(s.reason,12,false,MUTED));
        LinearLayout buttons=new LinearLayout(this);Button open=button(direct?"ABRIR ESTA SELECCIÓN":eventLink?"ABRIR ESTE PARTIDO":"BUSCAR ESTE PARTIDO EN HARD ROCK",true);open.setOnClickListener(v->openHardRock(s));buttons.addView(open,new LinearLayout.LayoutParams(0,dp(50),1));Button share=button("COMPARTIR",false);share.setOnClickListener(v->share(s));buttons.addView(share,new LinearLayout.LayoutParams(0,dp(50),1));c.addView(buttons);
        if(!active)c.addView(resultButtons(s));content.addView(c);
    }
    private View field(String label,String value,int color){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(0,dp(3),0,dp(3));r.addView(txt(label,11,true,MUTED));r.addView(txt(value==null||value.isEmpty()?"—":value,18,true,color));return r;}

    private View resultButtons(Signal s){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(0,dp(8),0,0);box.addView(txt("RESULTADO: "+s.status+("PENDIENTE".equals(s.status)?" • seguirá intentando resolverlo":""),13,true,statusColor(s.status)));LinearLayout r=new LinearLayout(this);for(String x:new String[]{"GANADA","PERDIDA","PUSH"}){Button b=button(x,false);b.setOnClickListener(v->{store.setResult(s.id,x);render();});r.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));}box.addView(r);return box;}
    private void renderHistory(){title("Historial y resultados");List<Signal>a=store.loadSignals();if(a.isEmpty()){content.addView(txt("Aún no hay señales guardadas.",16,false,MUTED));return;}for(Signal s:a)signalCard(s,false);}
    private void renderStats(){title("Rendimiento del modelo");List<Signal>a=store.loadSignals();int w=0,l=0,p=0,pen=0;double units=0;for(Signal s:a){switch(s.status){case"GANADA":w++;units+=s.simulatedProfit;break;case"PERDIDA":l++;units+=s.simulatedProfit;break;case"PUSH":p++;break;default:pen++;}}int resolved=w+l;double wr=resolved==0?0:w*100.0/resolved,roi=resolved==0?0:units/resolved*100;LinearLayout c=card();c.addView(bigStat(String.format(Locale.US,"%.1f%%",wr),"GANADAS / RESUELTAS",wr>=50?ACC:GOLD));LinearLayout row=new LinearLayout(this);row.addView(smallStat(String.valueOf(w),"Ganadas",ACC),new LinearLayout.LayoutParams(0,-2,1));row.addView(smallStat(String.valueOf(l),"Perdidas",RED),new LinearLayout.LayoutParams(0,-2,1));row.addView(smallStat(String.valueOf(p),"Push",GOLD),new LinearLayout.LayoutParams(0,-2,1));row.addView(smallStat(String.valueOf(pen),"Pendientes",MUTED),new LinearLayout.LayoutParams(0,-2,1));c.addView(row);c.addView(bigStat(String.format(Locale.US,"%+.2f u",units),"RESULTADO SIMULADO • 1 UNIDAD",units>=0?ACC:RED));c.addView(txt(String.format(Locale.US,"ROI simulado: %+.1f%%",roi),16,true,roi>=0?ACC:RED));c.addView(txt("Sirve para comprobar si las señales realmente funcionan con una muestra grande. No es una garantía de ganancias futuras.",13,false,MUTED));content.addView(c);}

    private void renderBrowser(){
        title("Hard Rock Bet • app oficial");
        LinearLayout note=card();
        note.addView(txt("V8 trabaja con la aplicación oficial instalada en tu teléfono. No usa el website ni compra APIs.",15,true,TEXT));
        note.addView(txt("1) Activa el Lector Hard Rock en Accesibilidad.\n2) Toca ABRIR HARD ROCK.\n3) Entra a LIVE. El explorador intenta priorizar Tenis de mesa y eSports y hacer scroll sin tocar cuotas.",13,false,MUTED));
        Button perm=button("AJUSTES DE ACCESIBILIDAD",false);perm.setOnClickListener(v->openAccessibilitySettings());note.addView(perm);
        Button open=button("ABRIR HARD ROCK",true);open.setOnClickListener(v->launchHardRock());note.addView(open);content.addView(note);
    }
    private void renderSettings(){
        title("Ajustes");LinearLayout c=card();c.addView(txt("Idioma: Español",16,true,TEXT));
        Switch ping=new Switch(this);ping.setText("Prioridad máxima: tenis de mesa / ping pong");ping.setTextColor(TEXT);ping.setChecked(store.pingPongPriority());ping.setOnCheckedChangeListener((x,v)->store.setPingPongPriority(v));c.addView(ping);
        Switch esp=new Switch(this);esp.setText("Prioridad: eSports");esp.setTextColor(TEXT);esp.setChecked(store.esportsPriority());esp.setOnCheckedChangeListener((x,v)->store.setEsportsPriority(v));c.addView(esp);
        Switch explore=new Switch(this);explore.setText("Radar automático: abrir Hard Rock + LIVE + scroll");explore.setTextColor(TEXT);explore.setChecked(store.autoExplore());explore.setOnCheckedChangeListener((x,v)->store.setAutoExplore(v));c.addView(explore);
        c.addView(txt("El explorador NO pulsa botones que contengan una cuota americana (+120, -110, etc.).",12,false,MUTED));
        c.addView(txt("Score mínimo de señal (1-99):",13,false,MUTED));EditText score=input(String.valueOf(store.minScore()));c.addView(score);Button ss=button("GUARDAR SCORE",false);ss.setOnClickListener(v->{try{store.setMinScore(Integer.parseInt(score.getText().toString()));Toast.makeText(this,"Guardado",Toast.LENGTH_SHORT).show();}catch(Exception ignored){}});c.addView(ss);
        Button acc=button("ACTIVAR / REVISAR ACCESIBILIDAD",false);acc.setOnClickListener(v->openAccessibilitySettings());c.addView(acc);
        Button clear=button("BORRAR HISTORIAL",false);clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Borrar historial").setMessage("¿Borrar señales y estadísticas?").setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(d,w)->{store.clearHistory();render();}).show());c.addView(clear);content.addView(c);
        title("Diagnóstico");LinearLayout d=card();d.addView(kv("Último escaneo",fmt(store.lastScan())));d.addView(kv("Lector Android",accessibilityEnabled()?"Habilitado":"Deshabilitado"));d.addView(kv("Servicio lector",store.readerReady()?"Conectado":"Esperando"));d.addView(kv("Deporte",spanishSport(store.currentSport())));d.addView(kv("Selecciones válidas",String.valueOf(store.oddsSeen())));d.addView(kv("Nodos de interfaz con cuota",String.valueOf(store.accessNodesSeen())));d.addView(kv("Fuente",store.currentUrl().isEmpty()?"—":store.currentUrl()));d.addView(kv("Error",store.lastError().isEmpty()?"Ninguno":store.lastError()));content.addView(d);
    }


    private void toggleScanner(boolean on){
        store.setScannerOn(on);
        if(on){Intent i=new Intent(this,ScannerService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);if(!accessibilityEnabled())Toast.makeText(this,"Falta activar Lector Hard Rock en Accesibilidad",Toast.LENGTH_LONG).show();}
        else stopService(new Intent(this,ScannerService.class));
        refreshStatus();render();
    }

    private void openHardRock(Signal s){
        if(s!=null&&s.event!=null&&!s.event.isEmpty())store.setOpenTarget(s.event);
        launchHardRock();
        if(s!=null)Toast.makeText(this,"Buscando este partido dentro de Hard Rock durante hasta 60 segundos…",Toast.LENGTH_LONG).show();
    }
    private void launchHardRock(){
        String pkg="com.hardrockdigital.client";
        try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);return;}}catch(Exception ignored){}
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id="+pkg)));}catch(Exception ignored){}
    }
    private boolean accessibilityEnabled(){
        try{String enabled=android.provider.Settings.Secure.getString(getContentResolver(),android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);if(enabled==null)return false;String mine=getPackageName()+"/com.oddswatch.mobile.HardRockAccessibilityService";return enabled.toLowerCase(Locale.US).contains(mine.toLowerCase(Locale.US))||enabled.toLowerCase(Locale.US).contains("hardrockaccessibilityservice");}catch(Exception e){return false;}
    }
    private void openAccessibilitySettings(){try{startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception ignored){}}
    private void share(Signal s){String x="OddsWatch\nPARTIDO: "+s.event+"\nMERCADO: "+s.market+"\nTOCA: "+s.selection+"\nCUOTA: "+s.odds+"\nScore: "+Math.round(s.score)+"/99";Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,x);startActivity(Intent.createChooser(i,"Compartir señal"));}

    private void refreshStatus(){if(status==null)return;String t=store.scannerOn()?"● RADAR V8 • "+(store.readerReady()?"LECTOR LISTO":"ACTIVA ACCESIBILIDAD")+" • "+spanishSport(store.currentSport()):"○ SCANNER APAGADO";status.setText(t);status.setTextColor(store.scannerOn()?ACC:MUTED);}
    private String spanishSport(String x){if(x==null)return"";switch(x){case"Table Tennis":return"Tenis de mesa";case"Basketball":return"Baloncesto";case"Baseball":return"Béisbol";case"Soccer":return"Fútbol";case"Volleyball":return"Voleibol";case"Darts":return"Dardos";case"Boxing":return"Boxeo";case"Tennis":return"Tenis";default:return x;}}
    private String fmt(long t){return t==0?"Nunca":new SimpleDateFormat("MMM d • h:mm:ss a",Locale.getDefault()).format(new Date(t));}
    private void title(String s){TextView t=txt(s,21,true,TEXT);t.setPadding(0,dp(14),0,dp(8));content.addView(t);}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(16),dp(14),dp(16),dp(14));c.setBackground(round(CARD,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(10));c.setLayoutParams(p);return c;}
    private TextView txt(String s,int sp,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(0,1.08f);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private TextView kv(String a,String b){TextView t=txt(a+":  "+b,14,false,TEXT);t.setPadding(0,dp(3),0,dp(3));return t;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextColor(primary?BG:TEXT);b.setTextSize(12);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(primary?ACC:CARD2,14));return b;}
    private EditText input(String s){EditText e=new EditText(this);e.setText(s);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setSingleLine(true);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(round(CARD2,12));return e;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
    private int statusColor(String s){if("GANADA".equals(s))return ACC;if("PERDIDA".equals(s))return RED;if("PUSH".equals(s))return GOLD;return MUTED;}
    private View bigStat(String value,String label,int color){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(0,dp(8),0,dp(8));x.addView(txt(value,32,true,color));x.addView(txt(label,12,true,MUTED));return x;}
    private View smallStat(String value,String label,int color){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);x.addView(txt(value,22,true,color));x.addView(txt(label,11,false,MUTED));return x;}
}
