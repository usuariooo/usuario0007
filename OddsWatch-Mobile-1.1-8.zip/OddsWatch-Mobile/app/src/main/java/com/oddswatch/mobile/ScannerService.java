package com.oddswatch.mobile;

import android.app.*;
import android.content.*;
import android.os.*;

/** V8 coordinator. The Accessibility reader performs the free scanning/navigation. */
public class ScannerService extends Service {
    public static final String ACTION_UPDATE="com.oddswatch.mobile.UPDATE";
    private static final String CH="oddswatch_scanner";
    private final Handler h=new Handler(Looper.getMainLooper()); private Store store;
    @Override public void onCreate(){super.onCreate();store=new Store(this);createChannel();startForeground(8,notification("Radar automático listo"));h.post(tick);}
    private final Runnable tick=new Runnable(){@Override public void run(){try{if(!store.scannerOn()){stopSelf();return;}sendBroadcast(new Intent(ACTION_UPDATE).setPackage(getPackageName()));String t=store.readerReady()?"V8 recorriendo Hard Rock LIVE automáticamente":"Activa Lector Hard Rock en Accesibilidad";getSystemService(NotificationManager.class).notify(8,notification(t));}catch(Exception ignored){}h.postDelayed(this,1000);}};
    @Override public int onStartCommand(Intent i,int flags,int id){if(store==null)store=new Store(this);store.setScannerOn(true);return START_STICKY;}
    @Override public void onDestroy(){h.removeCallbacksAndMessages(null);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    private void createChannel(){NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel(CH,"Radar OddsWatch",NotificationManager.IMPORTANCE_LOW));}
    private Notification notification(String text){Intent x=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,x,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,CH).setSmallIcon(R.drawable.ic_stat).setContentTitle("OddsWatch 8 • Radar").setContentText(text).setContentIntent(pi).setOngoing(true).build();}
}
