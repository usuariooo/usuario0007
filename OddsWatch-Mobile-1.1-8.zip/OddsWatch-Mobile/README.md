# OddsWatch 8

Versión Android gratuita basada en la app oficial de Hard Rock Bet.

## Cambios principales de V8
- El radar abre Hard Rock automáticamente cuando está encendido.
- Intenta entrar a LIVE y recorrer la lista arriba/abajo sin que el usuario tenga que buscar deporte por deporte.
- Prioridad de navegación: Table Tennis/Ping Pong y eSports cuando esas categorías están visibles.
- Parser espacial: relaciona cada cuota con los textos cercanos de la misma tarjeta para recuperar PARTICIPANTES, MERCADO, SELECCIÓN y CUOTA.
- Al tocar una señal, busca el partido hasta 60 segundos dentro de Hard Rock y abre el contenedor del evento si lo encuentra.
- Nunca pulsa un nodo que sea una cuota; no confirma ni realiza apuestas.
- Sin The Odds API, sin Twilio, sin claves de pago.

## Requisito
Activar OddsWatch en Ajustes > Accesibilidad > Aplicaciones instaladas.

## Límite técnico
El modo $0 lee la interfaz visible de Hard Rock mediante Accesibilidad. Android no permite leer una aplicación totalmente oculta en segundo plano, así que el radar automático abre Hard Rock mientras recorre LIVE. Si Hard Rock cambia su interfaz o no expone ciertos textos al árbol de Accesibilidad, esos mercados pueden no ser legibles.
