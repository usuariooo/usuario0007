package com.oddswatch.mobile;

import android.accessibilityservice.*;
import android.content.*;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.TextView;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Navigation helper for the official Hard Rock app.
 * It never clicks an odds/price node. It only opens navigation labels, scrolls,
 * opens an event name when VisionParser explicitly asks for a result check, and
 * backs out of stale/dead-end/detail screens.
 */
public class HardRockAccessibilityService extends AccessibilityService {
    private static HardRockAccessibilityService instance;
    private Store store; private Handler h;
    private long lastLaunch=0,lastLive=0,lastSport=0,lastScroll=0,lastBack=0;
    private long deadEndSince=0,detailSince=0,subPageSince=0;
    private long sportEnteredAt=0,lastSportBarSwipe=0,lastLiveSeek=0,lastHomeReset=0,lastLiveConfirmed=0;
    private int scrollCount=0,sportIndex=0,lastPageHash=0,stagnantTicks=0,failedScrolls=0;
    private String activeSport="";
    private boolean liveMode=false;
    private int liveSeekScrolls=0;
    // Result-exit guard: at most two deliberate back attempts after AUTO settlement.
    private long resolvedExitGestureAt=0;
    private int resolvedExitAttempts=0;

    // Horizontal sports-bar guard: Hard Rock has a finite strip. Without a cap,
    // repeated gesture requests can keep hitting the same edge forever.
    private int failedSwipesCount=0;
    private static final int MAX_BAR_SWIPES=5;

    private static final Pattern ODDS=Pattern.compile("(?<!\\d)(?:[+-](?:100|[1-9]\\d{2,3})|(?:1|[2-9]|[1-9]\\d)\\.\\d{2})(?!\\d)");
    private static final String[] SPORTS={
        // Night test is intentionally pinned to the two high-volume targets.
        // Do not wander into Rugby/MLB/Cricket/etc. while trying to validate the model.
        "Table Tennis","eSports","Table Tennis","E-Sports","Table Tennis","Esports"
    };

    @Override protected void onServiceConnected(){
        super.onServiceConnected(); instance=this; store=new Store(this); store.setReaderReady(true);
        h=new Handler(Looper.getMainLooper()); h.post(tick);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(store==null)return; CharSequence p=event.getPackageName(); if(p!=null)store.setForegroundPackage(p.toString());
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(store!=null)store.setReaderReady(false);if(h!=null)h.removeCallbacksAndMessages(null);if(instance==this)instance=null;super.onDestroy();}

    private final Runnable tick=new Runnable(){@Override public void run(){try{navigate();}catch(Exception ignored){}if(h!=null)h.postDelayed(this,900);}};

    private void navigate(){
        if(!store.scannerOn())return;
        long now=System.currentTimeMillis(); String fg=store.foregroundPackage();
        if(!"com.hardrockdigital.client".equals(fg)){
            resetPageTimers();
            if(store.dedicated()&&now-lastLaunch>3500){launchHardRock(this);lastLaunch=now;liveMode=false;activeSport="";sportEnteredAt=0;}
            return;
        }
        // ESCAPE POR TIMEOUT: este chequeo va al principio del ciclo para que la
        // navegación física tenga prioridad antes de cualquier búsqueda de LIVE/deportes.
        Signal timeoutTrackingEarly=store.trackingSignal();
        if(store.paperActive()&&timeoutTrackingEarly!=null&&"TIMEOUT_ESPERA".equals(timeoutTrackingEarly.status)){
            store.setResultStatus("🔄 NAVEGANDO ATRÁS: Límite de tiempo agotado. Abortando...");

            // Salida física segura: solo toca la flecha superior izquierda de Hard Rock.
            // No usamos GLOBAL_ACTION_BACK porque desde Home puede cerrar la aplicación.
            tapTopLeftBackGesture();

            // CANCELADA es solo el estado local de esta copia transitoria. El registro
            // histórico queda PENDIENTE para revisión y no altera el bankroll.
            timeoutTrackingEarly.status="CANCELADA";
            store.clearTrackingSignal();
            store.clearOpenTarget();

            activeSport=""; sportEnteredAt=0; scrollCount=0; failedScrolls=0;
            resetPageTimers();
            return;
        }

        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return;
        String visible=normalize(rootText(root)); String low=visible.toLowerCase(Locale.US);
        String selected=selectedSport(root);
        if(!selected.isEmpty()){
            activeSport=selected;
            failedSwipesCount=0;
            if(sportEnteredAt==0)sportEnteredAt=now;
            store.setNavSport(canonicalSport(selected));
        }

        int pageHash=stableFingerprint(low).hashCode();
        if(pageHash==lastPageHash)stagnantTicks++;else{lastPageHash=pageHash;stagnantTicks=0;failedScrolls=0;}

        // RESULTADO AUTO GUARDADO: salir del detalle sin spamear la pantalla.
        // Store ya persistió GANADA/PERDIDA/PUSH y refrescó la UI antes de llegar aquí.
        long resultExitAt=store.resultExitAt();
        if(resultExitAt>0){
            String ev=store.resultExitEvent();
            boolean onResolvedEvent=trackingEventVisible(low,ev)||looksLikeEventDetail(low)||looksLikeCompetitionSubPage(low)||isDeadEnd(low);

            if(!onResolvedEvent){
                // Confirmamos que ya salimos del partido: recién ahora liberamos la bandera.
                store.clearResultExit();
                resolvedExitGestureAt=0;resolvedExitAttempts=0;
                activeSport="";sportEnteredAt=0;scrollCount=0;failedScrolls=0;
            }else{
                store.setResultStatus("✅ Resultado guardado. Saliendo del partido...");

                // Primer intento inmediato; un segundo intento sólo si la pantalla sigue igual
                // después de 2.5 s. Nunca hacemos una ráfaga de toques.
                boolean canTry=resolvedExitAttempts==0 || (resolvedExitAttempts==1 && now-resolvedExitGestureAt>=2500);
                if(canTry&&resolvedExitAttempts<2){
                    boolean sent=clickExplicitBackControl(root);
                    if(!sent)sent=tapTopLeftBackGesture();
                    resolvedExitGestureAt=now;
                    resolvedExitAttempts++;
                    if(sent){
                        lastBack=now;activeSport="";sportEnteredAt=0;scrollCount=0;failedScrolls=0;
                    }
                }
                return;
            }
        }

        // ONE-SIGNAL LOCK: once the simulation creates a signal, this event owns navigation
        // until the result is resolved. Do not rotate sports or back out merely because time passed.
        Signal tracking=store.trackingSignal();
        if(tracking!=null&&"PENDIENTE".equals(tracking.status)){
            boolean eventHere=trackingEventVisible(low,tracking.event);
            boolean finalHere=isDeadEnd(low)||low.contains("match completed")||low.contains("this game has ended")||low.contains("finished")||low.contains("finalizado")||low.contains("completed");

            // Si el marcador final ya está visible, NO liberamos la apuesta ni salimos.
            // VisionParser recibe un frame OCR cada ~850 ms y debe resolverla en cuanto el
            // 3-x / marcador final demuestre GANADA, PERDIDA o PUSH. Esto mantiene el evento
            // anclado hasta que Store haya guardado realmente el resultado.
            if(finalHere){
                if(deadEndSince==0)deadEndSince=now;
                activeSport=tracking.sport;sportEnteredAt=now;store.setNavSport(tracking.sport);
                store.setResultStatus("🏆 Final visible • confirmando resultado: "+tracking.event);
                return;
            }

            // NUEVA LÓGICA: Si estamos en la pantalla de detalle de un evento, nos adueñamos de la navegación.
            if(looksLikeEventDetail(low)){
                activeSport=tracking.sport;sportEnteredAt=now;store.setNavSport(tracking.sport);
                
                // Si perdimos de vista los nombres de los jugadores (estamos muy abajo), 
                // forzamos el scroll físico hacia ARRIBA para volver al marcador.
                if(!eventHere) {
                    if(now - lastScroll > 1200) {
                        scroll(root, false); // false = scroll hacia arriba (tope de la pantalla)
                        lastScroll = now;
                    }
                }
                
                // Nos quedamos bloqueados aquí para que el OCR lea el marcador tranquilamente.
                return;
            }
            // If we are not yet inside the event, keep result-search navigation pointed at it.
            if(store.openTarget().isEmpty()||now-store.openTargetAt()>32000)store.setOpenTarget(tracking.event,tracking.sport);
        }

        if(isDeadEnd(low)){
            if(tracking!=null&&"PENDIENTE".equals(tracking.status)){
                // Completed screens are handled above with a bounded grace period.
                store.setResultStatus("🔒 Leyendo resultado final: "+tracking.event);
                return;
            }
            if(deadEndSince==0)deadEndSince=now;
            if(now-deadEndSince>1600&&now-lastBack>1800){safeBack(root,low);deadEndSince=0;detailSince=0;subPageSince=0;}
            return;
        } else deadEndSince=0;

        String target=store.openTarget();
        boolean targetActive=!target.isEmpty()&&now-store.openTargetAt()<13L*60L*1000L;

        boolean detail=looksLikeEventDetail(low);
        boolean subPage=looksLikeCompetitionSubPage(low);
        if(detail||subPage){
            if(detailSince==0)detailSince=now;
            long budget=targetActive?9000:5500;
            if(store.dedicated()&&now-detailSince>budget&&now-lastBack>1800){safeBack(root,low);detailSince=0;subPageSince=0;return;}
        } else detailSince=0;

        // Result checks temporarily own navigation. First reach LIVE, then the signal's sport,
        // then search for the event. This is independent of whatever sport the normal radar is on.
        if(targetActive){
            String targetSport=store.openTargetSport();
            boolean targetLive=hasConfirmedLiveHub(root,low)||looksLikeLiveContent(low)||(liveMode&&now-lastLiveConfirmed<3000);
            if(!targetLive){
                if(now-lastLive>1200&&tapLiveNowLabel(root)){lastLive=now;liveMode=false;return;}
                if(now-lastLiveSeek>900){scroll(root,false);lastLiveSeek=now;liveSeekScrolls++;}
                return;
            }
            liveMode=true;
            if(!targetSport.isEmpty()&&!sameSportLabel(activeSport,targetSport)){
                String[] labels=labelsForSport(targetSport);
                if(clickExactText(root,labels)){
                    activeSport=labels[0];sportEnteredAt=now;store.setNavSport(targetSport);lastSport=now;scrollCount=0;
                    failedSwipesCount=0;
                    return;
                }
                if(now-lastSportBarSwipe>1200){attemptSportsBarSwipe(true);lastSportBarSwipe=now;}
                return;
            }
            if(now-lastScroll>900){boolean ok=scroll(root,(scrollCount++%8)<6);if(!ok)failedScrolls++;else failedScrolls=0;lastScroll=now;}
            // No abandonar el target a los 38 s. Mientras la señal siga PENDIENTE,
            // VisionParser vuelve a publicar openTarget y seguimos buscándola sin rotar deportes.
            if(now-store.openTargetAt()>60000)store.setResultStatus("🔎 Aún buscando el partido exacto: "+target);
            return;
        }
        if(!target.isEmpty())store.clearOpenTarget();

        // After creating a signal, freeze navigation briefly so the user can read/act on it
        // and so the saved screenshot corresponds to the same market instead of the next screen.
        if(now-store.lastSignalAt()<12000)return;

        // HARD watchdog: dynamic odds must not keep Baseball/MLB or any other sport open forever.
        // Table tennis/eSports get longer because they are the priority; all other sports are sampled briefly.
        if((liveMode||hasConfirmedLiveHub(root,low))&&!activeSport.isEmpty()&&sportEnteredAt>0){
            long budget=sportBudget(activeSport);
            if(now-sportEnteredAt>budget){
                activeSport="";sportEnteredAt=0;scrollCount=0;failedScrolls=0;stagnantTicks=0;
                if(!hasConfirmedLiveHub(root,low)){
                    if(tapLiveNowLabel(root)){lastLive=now;liveMode=false;return;}
                    if(now-lastBack>1800){safeBack(root,low);return;}
                }
                // Already on the LIVE hub: allow the next sport to be selected immediately.
                lastSport=0;
            }
        }

        // A static page that ignores multiple scroll attempts should never hold the overnight radar hostage.
        if(store.dedicated()&&(liveMode||hasConfirmedLiveHub(root,low))&&stagnantTicks>=20&&failedScrolls>=2&&now-lastBack>2800){
            activeSport="";sportEnteredAt=0;lastSport=0;
            stagnantTicks=0;failedScrolls=0;return;
        }

        boolean liveHub=hasConfirmedLiveHub(root,low)||looksLikeLiveContent(low)||(liveMode&&now-lastLiveConfirmed<2600);

        // When we are on Home/Discover, do ONLY one job: reach LIVE.
        // Previous builds treated any page that merely showed MLB/Table Tennis tabs as the LIVE hub,
        // so the radar could sit forever on the main sportsbook screen.
        if(!liveHub){
            activeSport="";sportEnteredAt=0;scrollCount=0;
            if(now-lastLive>1500){
                if(tapLiveNowLabel(root)){
                    // An attempted tap is NOT confirmation. Wait until OCR/accessibility sees the real Live hub.
                    liveMode=false;lastLive=now;liveSeekScrolls=0;lastSport=0;return;
                }
                lastLive=now;
            }

            // Search the Home page vertically for the Live Now section instead of touching MLB or another sport.
            if(store.dedicated()&&now-lastLiveSeek>900){
                // Hard Rock commonly opens below Live Now. Seek upward first, then make two
                // controlled downward passes instead of wandering around MLB for minutes.
                boolean down=(liveSeekScrolls%6)>=4;
                scroll(root,down);liveSeekScrolls++;lastLiveSeek=now;
                return;
            }

            // If the Home screen is stuck for a long time, re-anchor on Home and try again.
            if(store.dedicated()&&liveSeekScrolls>=10&&now-lastHomeReset>7000){
                if(clickExactText(root,new String[]{"Home","Inicio"})){
                    liveMode=false;liveSeekScrolls=0;lastHomeReset=now;lastLive=0;return;
                }
            }
            return; // NEVER choose a sport until LIVE is confirmed.
        } else {
            liveMode=true;liveSeekScrolls=0;
        }

        // Pick a sport every few seconds. Exact matching prevents Tennis from matching Table Tennis.
        if(activeSport.isEmpty()&&now-lastSport>1800){
            String wanted=SPORTS[sportIndex++%SPORTS.length];
            if(clickExactText(root,new String[]{wanted})){
                lastSport=now;scrollCount=0;activeSport=wanted;sportEnteredAt=now;store.setNavStep(sportIndex);store.setNavSport(canonicalSport(wanted));
                failedSwipesCount=0;
                return;
            }
            // The horizontal sports strip can hide labels off-screen. Limit consecutive swipes
            // so reaching a physical edge cannot trap the radar forever.
            if(now-lastSportBarSwipe>2200){attemptSportsBarSwipe((sportIndex%2)==0);lastSportBarSwipe=now;}
            lastSport=now;
        }

        // Hold each viewport long enough for 4+ OCR confirmations before moving.
        // The previous 1.35s scroll cadence outran the parser's 4-read stability rule.
        if(now-lastScroll>4300){
            boolean down=(scrollCount%10)<7; boolean ok=scroll(root,down); scrollCount++; lastScroll=now;
            if(!ok)failedScrolls++;else failedScrolls=0;
            if(failedScrolls>=3&&now-lastBack>2400){
                if(!hasConfirmedLiveHub(root,low))safeBack(root,low);else{activeSport="";sportEnteredAt=0;lastSport=0;}
                failedScrolls=0;
            }
        }
    }

    private boolean trackingEventVisible(String low,String event){
        if(low==null||event==null||event.isEmpty())return false;
        String[] p=event.toLowerCase(Locale.US).split("(?i)\\s+vs\\s+",2);
        if(p.length!=2)return low.contains(event.toLowerCase(Locale.US));
        String a=firstUsefulWord(p[0]),b=firstUsefulWord(p[1]);
        return !a.isEmpty()&&!b.isEmpty()&&low.contains(a)&&low.contains(b);
    }
    private String firstUsefulWord(String s){
        if(s==null)return "";for(String w:s.toLowerCase(Locale.US).replaceAll("[^a-z0-9à-ÿ._ -]"," ").split("\\s+"))if(w.length()>=3)return w;return "";
    }

    private boolean sameSportLabel(String a,String b){
        String x=canonicalSport(a==null?"":a).toLowerCase(Locale.US),y=canonicalSport(b==null?"":b).toLowerCase(Locale.US);
        if(x.isEmpty()||y.isEmpty())return false;
        if(x.contains("mesa")&&y.contains("mesa"))return true;
        if(x.contains("esport")&&y.contains("esport"))return true;
        return x.equals(y);
    }
    private String[] labelsForSport(String sport){
        String l=sport==null?"":sport.toLowerCase(Locale.US);
        if(l.contains("mesa")||l.contains("table tennis")||l.contains("ping pong"))return new String[]{"Table Tennis","Ping Pong"};
        if(l.contains("esport"))return new String[]{"eSports","E-Sports","Esports"};
        if(l.contains("béisbol")||l.contains("beisbol")||l.contains("baseball")||l.equals("mlb"))return new String[]{"MLB","Baseball"};
        if(l.contains("baloncesto")||l.contains("basketball"))return new String[]{"Basketball"};
        if(l.contains("fútbol americano")||l.contains("football"))return new String[]{"Football","NFL"};
        if(l.contains("fútbol")||l.contains("futbol")||l.contains("soccer"))return new String[]{"Soccer"};
        if(l.equals("tenis")||l.equals("tennis"))return new String[]{"Tennis"};
        if(l.contains("hockey"))return new String[]{"Hockey"};
        if(l.contains("golf")||l.contains("pga"))return new String[]{"PGA","Golf"};
        return new String[]{sport};
    }
    private boolean isPrioritySport(String s){String l=s==null?"":s.toLowerCase(Locale.US);return l.contains("table tennis")||l.contains("ping pong")||l.contains("sport")||l.contains("mesa");}
    private long sportBudget(String s){String l=s==null?"":s.toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong")||l.contains("mesa"))return 90000; if(l.contains("sport"))return 60000; return 12000;}
    private String canonicalSport(String s){String l=s==null?"":s.toLowerCase(Locale.US);if(l.contains("table tennis")||l.contains("ping pong"))return "Tenis de mesa";if(l.contains("sport"))return "eSports";if(l.equals("mlb")||l.contains("baseball"))return "Béisbol";if(l.contains("basketball"))return "Baloncesto";if(l.contains("soccer"))return "Fútbol";if(l.equals("tennis"))return "Tenis";if(l.contains("hockey"))return "Hockey";if(l.contains("football")||l.equals("nfl"))return "Fútbol americano";if(l.contains("pga")||l.contains("golf"))return "Golf";return s;}
    private String selectedSport(AccessibilityNodeInfo root){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));if((n.isSelected()||n.isChecked())&&!t.isEmpty()&&!ODDS.matcher(t).find()){for(String w:SPORTS)if(t.equalsIgnoreCase(w))return w;}for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}
        return "";
    }

    private boolean attemptSportsBarSwipe(boolean left){
        // Count attempts, not dispatchGesture's boolean: Android can report a gesture as
        // dispatched even when the strip is already against its edge.
        if(failedSwipesCount < MAX_BAR_SWIPES){
            boolean dispatched=swipeSportsBar(left);
            failedSwipesCount++;
            return dispatched;
        }

        // Edge recovery: stop hammering the same wall. Reset the budget and make one
        // controlled swipe in the opposite direction so the next cycles can search again.
        failedSwipesCount=0;
        store.setResultStatus("↔️ Barra de deportes: borde alcanzado; invirtiendo búsqueda.");
        return swipeSportsBar(!left);
    }

    private boolean swipeSportsBar(boolean left){
        try{
            int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;
            Path p=new Path();float y=hg*.165f;p.moveTo(left?w*.78f:w*.22f,y);p.lineTo(left?w*.22f:w*.78f,y);
            return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,260)).build(),null,null);
        }catch(Exception e){return false;}
    }

    private void resetPageTimers(){deadEndSince=0;detailSince=0;subPageSince=0;stagnantTicks=0;failedScrolls=0;failedSwipesCount=0;}

    // SAFETY RULE: OddsWatch never sends Android's GLOBAL_ACTION_BACK.
    // GLOBAL_ACTION_BACK can close Hard Rock when the app is already at its root screen,
    // and Hard Rock does not expose a reliable root/detail state on every device.
    // To leave a proven subpage we only click an explicit top-left Back/Navigate-up control.
    // If that control is not exposed, we fall back to the visible Home tab; otherwise we do
    // nothing and let the watchdog retry. This makes it impossible for this service to close
    // Hard Rock by issuing the system Back action.
    private void safeBack(AccessibilityNodeInfo root,String low){
        if(root==null)return;
        long now=System.currentTimeMillis();
        boolean provenSubPage=isDeadEnd(low)||looksLikeEventDetail(low)||looksLikeCompetitionSubPage(low);

        if(provenSubPage){
            if(clickExplicitBackControl(root)||tapTopLeftBackGesture()){
                lastBack=now;activeSport="";sportEnteredAt=0;scrollCount=0;failedScrolls=0;
                return;
            }
            // Never guess with the bottom navigation (Home/Games). If the explicit arrow is not
            // exposed, wait for the next frame and retry the fixed top-left back target.
            return;
        }

        // At an unproven/root screen do nothing. GLOBAL_BACK is intentionally never used.
        lastBack=now;
    }

    private boolean tapTopLeftBackGesture(){
        try{
            int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;
            float[][] pts={{0.07f,0.08f},{0.09f,0.075f}};
            int idx=Math.floorMod(resolvedExitAttempts,pts.length);
            Path p=new Path();p.moveTo(w*pts[idx][0],hgt*pts[idx][1]);
            return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,90)).build(),null,null);
        }catch(Exception e){return false;}
    }

    private boolean clickExplicitBackControl(AccessibilityNodeInfo root){
        if(root==null)return false;
        int w=getResources().getDisplayMetrics().widthPixels;
        int hgt=getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo best=null;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();
            Rect b=new Rect();n.getBoundsInScreen(b);
            String t=normalize(text(n)).toLowerCase(Locale.US);
            boolean topLeft=!b.isEmpty()&&b.centerX()<w*.22&&b.centerY()<hgt*.18;
            boolean named=t.equals("back")||t.equals("navigate up")||t.equals("atrás")||t.equals("volver")||t.contains("navigate up");
            if(topLeft&&named){best=n;break;}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        if(best==null)return false;
        if(best.isClickable())return best.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        AccessibilityNodeInfo p=best.getParent();
        for(int i=0;i<3&&p!=null;i++){if(p.isClickable())return p.performAction(AccessibilityNodeInfo.ACTION_CLICK);p=p.getParent();}
        return false;
    }

    private boolean isHardRockRoot(AccessibilityNodeInfo root,String low){
        if(low==null)low="";
        // Bottom navigation labels are the strongest signal that we are at the sportsbook
        // root/home shell rather than inside an event or league detail page.
        boolean home=hasExactText(root,new String[]{"Home","Inicio"});
        boolean discover=hasExactText(root,new String[]{"Discover","Descubrir"});
        boolean games=hasExactText(root,new String[]{"Games","Juegos"});
        boolean account=hasExactText(root,new String[]{"Account","Cuenta"});
        boolean shell=(home&&discover&&account)||(home&&games&&account);
        if(!shell)return false;
        if(looksLikeEventDetail(low)||looksLikeCompetitionSubPage(low)||isDeadEnd(low))return false;
        return true;
    }

    private boolean hasExactText(AccessibilityNodeInfo root,String[] wanted){
        if(root==null)return false;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));
            if(!t.isEmpty())for(String w:wanted)if(t.equalsIgnoreCase(normalize(w)))return true;
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        return false;
    }

    private boolean isDeadEnd(String l){return l.contains("no bets currently available")||l.contains("check back again soon")||l.contains("this game has ended")||l.contains("match completed")||l.contains("final whistle has blown")||l.contains("view upcoming games")||l.contains("no wagers currently available")||l.contains("no markets currently available");}
    private boolean hasConfirmedLiveHub(AccessibilityNodeInfo root,String l){
        if(looksLikeLiveContent(l))return true;
        if(root==null)return false;
        int hgt=getResources().getDisplayMetrics().heightPixels;
        boolean topLive=false;int sportTabs=0;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));String low=t.toLowerCase(Locale.US);
            Rect b=new Rect();n.getBoundsInScreen(b);
            if((low.equals("live now")||low.equals("en vivo ahora"))&&b.top>=0&&b.top<hgt*.18)topLive=true;
            if(b.top>=0&&b.top<hgt*.30)for(String w:SPORTS)if(low.equals(w.toLowerCase(Locale.US))){sportTabs++;break;}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        return topLive&&sportTabs>=2;
    }

    private boolean tapLiveNowLabel(AccessibilityNodeInfo root){
        if(root==null)return false;
        int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo best=null;Rect bestBox=null;
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));String low=t.toLowerCase(Locale.US);
            if(low.equals("live now")||low.equals("en vivo ahora")){
                Rect b=new Rect();n.getBoundsInScreen(b);
                // Never tap the top-right search/header zone, and do not re-tap the Live-page title at the top.
                if(!b.isEmpty()&&b.centerX()<w*.82&&b.top>hgt*.15&&b.top<hgt*.88){
                    if(best==null||b.top<bestBox.top){best=n;bestBox=b;}
                }
            }
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }
        if(bestBox==null)return false;
        // Tap the text bounds directly. Do NOT climb to a large clickable parent (that previously hit Search).
        Path p=new Path();p.moveTo(bestBox.centerX(),bestBox.centerY());
        return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build(),null,null);
    }
    private boolean looksLikeLiveContent(String l){
        return l.contains("stream now")||l.contains("4th set")||l.contains("3rd set")||l.contains("2nd set")||l.contains("1st set")
                ||l.contains("match completed")||l.contains("this game has ended");
    }
    private boolean looksLikeEventDetail(String l){
        boolean tabs=l.contains("popular")&&(l.contains("parlays")||l.contains("halves")||l.contains("goals")||l.contains("sets")||l.contains("points"));
        boolean ended=l.contains("match completed")||l.contains("this game has ended")||l.contains("no bets currently available");
        // Table-tennis event pages use a different layout: player scoreboard + Match/Games tabs.
        // Without recognizing this layout safeBack() refuses to leave, which is why completed
        // Setka matches could remain stuck on screen after the result was already 3-x.
        boolean tableDetail=(l.contains("setka")||l.contains("tt cup")||l.contains("table tennis")||l.contains("ping pong"))
                &&l.contains("match")&&l.contains("games")
                &&(l.contains("1st set")||l.contains("2nd set")||l.contains("3rd set")||l.contains("4th set")||l.contains("5th set")||l.contains(" set "));
        return tabs||ended||tableDetail;
    }
    private boolean looksLikeCompetitionSubPage(String l){
        if(looksLikeLiveContent(l))return false;
        // Competition/league pages commonly have a title followed by a single "Games" tab.
        boolean gamesTab=l.contains(" games ")||l.endsWith(" games")||l.startsWith("games ");
        boolean leagueWords=l.contains(" series")||l.contains(" league")||l.contains(" germany")||l.contains(" cup")||l.contains(" tournament");
        boolean schedule=l.contains("streaming soon")||l.contains("today,")||l.contains("tomorrow,");
        return (gamesTab&&(leagueWords||schedule));
    }
    private String stableFingerprint(String l){String s=l.replaceAll("\\b\\d{1,2}:\\d{2}\\b","#").replaceAll("\\b\\d+\\.\\d{2}\\b","#");return s.length()>700?s.substring(0,700):s;}
    private String normalize(String s){return s==null?"":s.replace('\n',' ').replaceAll("\\s+"," ").trim();}

    private String rootText(AccessibilityNodeInfo root){StringBuilder out=new StringBuilder();ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);int seen=0;while(!q.isEmpty()&&seen++<900){AccessibilityNodeInfo n=q.removeFirst();String t=text(n);if(!t.isEmpty())out.append(t).append(' ');for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return out.toString();}

    private boolean clickExactText(AccessibilityNodeInfo root,String[] wanted){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));
            if(!t.isEmpty()&&!ODDS.matcher(t).find())for(String w:wanted)if(t.equalsIgnoreCase(normalize(w))){if(clickNodeOrParent(n))return true;}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }return false;
    }
    private boolean clickContainsText(AccessibilityNodeInfo root,String[] wanted){
        ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);
        while(!q.isEmpty()){
            AccessibilityNodeInfo n=q.removeFirst();String t=normalize(text(n));String low=t.toLowerCase(Locale.US);
            if(!t.isEmpty()&&!ODDS.matcher(t).find())for(String w:wanted){String z=w.toLowerCase(Locale.US);if(low.equals(z)||low.startsWith(z+" ")){if(clickNodeOrParent(n))return true;}}
            for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}
        }return false;
    }
    private boolean clickNodeOrParent(AccessibilityNodeInfo n){AccessibilityNodeInfo c=n;for(int i=0;i<5&&c!=null;i++){if(c.isClickable()){c.performAction(AccessibilityNodeInfo.ACTION_CLICK);return true;}c=c.getParent();}return false;}
    private String text(AccessibilityNodeInfo n){String a=n.getText()==null?"":n.getText().toString();String b=n.getContentDescription()==null?"":n.getContentDescription().toString();return (a+" "+b).trim();}

    private boolean scroll(AccessibilityNodeInfo root,boolean down){AccessibilityNodeInfo sc=findScrollable(root);if(sc!=null&&sc.performAction(down?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))return true;int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;Path p=new Path();p.moveTo(w*.5f,down?hg*.76f:hg*.34f);p.lineTo(w*.5f,down?hg*.34f:hg*.76f);return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,320)).build(),null,null);}
    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root){ArrayDeque<AccessibilityNodeInfo>q=new ArrayDeque<>();q.add(root);while(!q.isEmpty()){AccessibilityNodeInfo n=q.removeFirst();if(n.isScrollable())return n;for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)q.add(c);}}return null;}

    private void showHighlight(int x,int y,String label,boolean test){
        try{
            WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);final TextView v=new TextView(this);v.setText(label);v.setTextColor(Color.WHITE);v.setTextSize(15);v.setPadding(22,14,22,14);v.setElevation(18f);
            GradientDrawable bg=new GradientDrawable();bg.setColor(test?0xDD6A4C00:0xDD087F73);bg.setCornerRadius(28);bg.setStroke(5,test?0xFFFFC34A:0xFF35E4D1);v.setBackground(bg);
            int w=getResources().getDisplayMetrics().widthPixels,hg=getResources().getDisplayMetrics().heightPixels;
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP|Gravity.START;lp.x=Math.max(8,Math.min(w-420,x-330));lp.y=Math.max(80,Math.min(hg-180,y-60));wm.addView(v,lp);
            if(h!=null)h.postDelayed(()->{try{wm.removeView(v);}catch(Exception ignored){}},8000);
        }catch(Exception ignored){}
    }
    public static void highlightSelection(int x,int y,String label,boolean test){HardRockAccessibilityService s=instance;if(s==null)return;if(s.h!=null)s.h.post(()->s.showHighlight(x,y,label,test));}

    public static void launchHardRock(Context c){String pkg="com.hardrockdigital.client";try{Intent i=c.getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);c.startActivity(i);return;}}catch(Exception ignored){}try{c.startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("market://details?id="+pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception ignored){}}
    public static void tapSafeEvent(int x,int y){HardRockAccessibilityService s=instance;if(s==null)return;Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();s.dispatchGesture(g,null,null);}
    public static void tapNavigation(int x,int y,String sport){
        HardRockAccessibilityService s=instance;if(s==null)return;
        if("__LIVE__".equals(sport)){
            AccessibilityNodeInfo root=s.getRootInActiveWindow();
            boolean tapped=false;
            // First prefer the exact Accessibility node when Hard Rock exposes it.
            if(root!=null)tapped=s.tapLiveNowLabel(root);
            // Hard Rock often does NOT expose the Home "Live Now" card to Accessibility.
            // In that case Vision OCR has already verified the literal text and supplied its
            // screen coordinates. Use those coordinates, but only inside a conservative safe
            // content area so we can never hit the top-right Search icon.
            if(!tapped)s.tapVerifiedLiveOcrPoint(x,y);
            s.liveMode=false;s.activeSport="";s.sportEnteredAt=0;s.scrollCount=0;s.lastLive=System.currentTimeMillis();s.lastSport=0;s.liveSeekScrolls=0;
            return;
        }
        Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,75)).build();s.dispatchGesture(g,null,null);
        s.liveMode=true;s.lastLiveConfirmed=System.currentTimeMillis();s.activeSport=sport;s.sportEnteredAt=System.currentTimeMillis();s.scrollCount=0;s.lastSport=System.currentTimeMillis();
        if(s.store!=null)s.store.setNavSport(s.canonicalSport(sport));
    }
    private boolean tapVerifiedLiveOcrPoint(int x,int y){
        try{
            int w=getResources().getDisplayMetrics().widthPixels;
            int hg=getResources().getDisplayMetrics().heightPixels;
            // OCR must point to the content area. Search/header controls live outside this box.
            if(x<=0||y<=0||x>w*.76f||y<hg*.10f||y>hg*.88f)return false;
            // Bias slightly toward the center of the Live Now row. This avoids tapping on the
            // left edge of the text while still staying far away from the search icon.
            float tx=Math.max(w*.18f,Math.min(w*.68f,x));
            float ty=Math.max(hg*.11f,Math.min(hg*.87f,y));
            Path p=new Path();p.moveTo(tx,ty);
            return dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,90)).build(),null,null);
        }catch(Exception e){return false;}
    }

    public static void confirmLiveVisible(){HardRockAccessibilityService s=instance;if(s!=null){s.liveMode=true;s.lastLiveConfirmed=System.currentTimeMillis();s.liveSeekScrolls=0;}}
    public static void swipeSportsFromVision(boolean left){HardRockAccessibilityService s=instance;if(s!=null)s.attemptSportsBarSwipe(left);}
}
