package com.oddswatch.mobile;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    LinearLayout list; TextView status,lastError; Switch power,demo,wa; EditText api,interval,threshold,sid,token,from,to; final ExecutorService exec=Executors.newSingleThreadExecutor();
    final BroadcastReceiver rx=new BroadcastReceiver(){public void onReceive(Context c,Intent i){refresh();}};
    @Override public void onCreate(Bundle b){super.onCreate(b); if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2); build(); load(); refresh();}
    @Override protected void onResume(){super.onResume();registerReceiver(rx,new IntentFilter(ScannerService.ACTION_UPDATED),Build.VERSION.SDK_INT>=33?Context.RECEIVER_NOT_EXPORTED:0);refresh();}
    @Override protected void onPause(){try{unregisterReceiver(rx);}catch(Exception ignored){}super.onPause();}
    private void build(){
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(Color.rgb(7,16,24));LinearLayout root=col();root.setPadding(dp(18),dp(24),dp(18),dp(50));sc.addView(root);setContentView(sc);
        TextView eyebrow=t("SPORTS MARKET MONITOR",11,Color.rgb(111,132,149),true);root.addView(eyebrow);root.addView(t("OddsWatch",32,Color.WHITE,true));status=t("SCANNER OFF",13,Color.rgb(244,184,96),true);status.setPadding(0,dp(8),0,dp(16));root.addView(status);
        LinearLayout hero=panel(); hero.addView(t("Hard Rock FL anomaly scanner",20,Color.WHITE,true)); hero.addView(t("Compares Hard Rock Bet Florida prices with a multi-book consensus, flags unusual prices/lines, and can send alerts to your phone and WhatsApp.",14,Color.rgb(157,176,191),false));
        power=new Switch(this);power.setText(" Scanner ON");power.setTextColor(Color.WHITE);power.setTextSize(17);hero.addView(power);root.addView(hero);
        root.addView(section("DATA"));demo=sw("Demo mode (works without an API key)");root.addView(demo);api=input("The Odds API key",false);root.addView(api);interval=input("Scan interval seconds (min 30)",false);interval.setInputType(InputType.TYPE_CLASS_NUMBER);root.addView(interval);threshold=input("Anomaly score threshold 0-99",false);threshold.setInputType(InputType.TYPE_CLASS_NUMBER);root.addView(threshold);
        root.addView(section("WHATSAPP ALERTS"));wa=sw("Send qualifying alerts to WhatsApp");root.addView(wa);to=input("Recipient number, E.164",false);root.addView(to);from=input("Twilio WhatsApp sender",false);root.addView(from);sid=input("Twilio Account SID",false);root.addView(sid);token=input("Twilio Auth Token",true);root.addView(token);
        Button save=btn("SAVE SETTINGS");root.addView(save);Button scan=btn("SCAN NOW");root.addView(scan);Button test=btn("TEST WHATSAPP");root.addView(test);
        lastError=t("",12,Color.rgb(255,107,107),false);root.addView(lastError);root.addView(section("TOP ANOMALIES"));list=col();root.addView(list);
        TextView foot=t("No wager placement or Hard Rock login automation. Scores are market-discrepancy estimates, not guarantees. API usage and Android background limits still apply.",11,Color.rgb(82,101,116),false);foot.setPadding(0,dp(20),0,0);root.addView(foot);
        save.setOnClickListener(v->{save();Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show();});
        power.setOnCheckedChangeListener((v,on)->{Prefs.p(this).edit().putBoolean("running",on).apply(); if(on){save();startScanner();}else stopService(new Intent(this,ScannerService.class)); refresh();});
        scan.setOnClickListener(v->{save();scanNow();}); test.setOnClickListener(v->{save();testWa();});
    }
    private void load(){demo.setChecked(Prefs.demo(this));api.setText(Prefs.apiKey(this));interval.setText(String.valueOf(Prefs.interval(this)));threshold.setText(String.valueOf(Prefs.threshold(this)));wa.setChecked(Prefs.whatsapp(this));to.setText(Prefs.waTo(this));from.setText(Prefs.twFrom(this));sid.setText(Prefs.twSid(this));token.setText(Prefs.twToken(this));power.setChecked(Prefs.running(this));if(Prefs.running(this))startScanner();}
    private void save(){int sec=parse(interval.getText().toString(),120),th=parse(threshold.getText().toString(),70);Prefs.p(this).edit().putBoolean("demo",demo.isChecked()).putString("api_key",api.getText().toString().trim()).putInt("interval_sec",Math.max(30,sec)).putInt("threshold",Math.max(0,Math.min(99,th))).putBoolean("whatsapp",wa.isChecked()).putString("wa_to",norm(to.getText().toString())).putString("tw_from",norm(from.getText().toString())).putString("tw_sid",sid.getText().toString().trim()).putString("tw_token",token.getText().toString().trim()).apply();}
    private String norm(String s){s=s.trim();return s.startsWith("+")?s:"+"+s.replaceAll("[^0-9]","");}
    private void startScanner(){Intent i=new Intent(this,ScannerService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    private void scanNow(){status.setText("SCANNING…");exec.submit(()->{try{AppState.set(OddsAnalyzer.scan(this));}catch(Exception e){AppState.error=e.getMessage();}runOnUiThread(this::refresh);});}
    private void testWa(){exec.submit(()->{try{WhatsAppSender.send(this,"✅ OddsWatch test message. WhatsApp alerts are connected.");runOnUiThread(()->Toast.makeText(this,"WhatsApp request sent",Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("WhatsApp test failed").setMessage(e.getMessage()+"\n\nTwilio Sandbox must be joined and credentials must be valid.").setPositiveButton("OK",null).show());}});}
    private void refresh(){boolean r=Prefs.running(this);status.setText(r?"● SCANNER RUNNING":"SCANNER OFF");status.setTextColor(r?Color.rgb(83,211,154):Color.rgb(244,184,96));lastError.setText(AppState.error==null||AppState.error.isEmpty()?"":("Last error: "+AppState.error));list.removeAllViews();List<MarketAlert>a=AppState.alerts;if(a==null||a.isEmpty()){list.addView(t("No anomalies loaded yet. Tap SCAN NOW or enable the scanner.",13,Color.rgb(128,148,163),false));return;}for(MarketAlert x:a){LinearLayout c=panel();c.addView(t((x.live?"LIVE  •  ":"PRE  •  ")+x.sport,12,x.live?Color.rgb(83,211,154):Color.rgb(141,161,177),true));c.addView(t(x.event,17,Color.WHITE,true));c.addView(t(x.market.toUpperCase(Locale.US)+"  •  "+x.selection+"  "+x.hardRockPrice,15,Color.WHITE,true));c.addView(t("ANOMALY "+x.score+"/100  •  edge model "+String.format(Locale.US,"%.1f%%",x.evPct)+"  •  "+x.peers+" peer books",12,Color.rgb(244,184,96),true));c.addView(t(x.detail,12,Color.rgb(157,176,191),false));list.addView(c);}}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private LinearLayout panel(){LinearLayout l=col();l.setPadding(dp(16),dp(16),dp(16),dp(16));GradientDrawableCompat.bg(l,Color.rgb(13,27,38),18);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));l.setLayoutParams(p);return l;}
    private TextView section(String s){TextView v=t(s,12,Color.rgb(111,132,149),true);v.setPadding(0,dp(18),0,dp(8));return v;} private TextView t(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);v.setPadding(0,dp(3),0,dp(3));if(bold)v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);return v;} private Switch sw(String s){Switch v=new Switch(this);v.setText(s);v.setTextColor(Color.WHITE);v.setPadding(0,dp(8),0,dp(8));return v;}
    private EditText input(String hint,boolean password){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(100,120,135));e.setTextColor(Color.WHITE);e.setSingleLine(true);e.setPadding(dp(12),dp(12),dp(12),dp(12));GradientDrawableCompat.bg(e,Color.rgb(17,31,42),12);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(8));e.setLayoutParams(p);if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;} private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);GradientDrawableCompat.bg(b,Color.rgb(23,56,41),14);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(7),0,0);b.setLayoutParams(p);return b;} private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} private int parse(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
    @Override protected void onDestroy(){exec.shutdownNow();super.onDestroy();}
}
