package com.oddswatch.mobile;
import android.graphics.drawable.GradientDrawable;import android.view.View;
public final class GradientDrawableCompat {public static void bg(View v,int color,int radiusDp){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radiusDp*v.getResources().getDisplayMetrics().density);g.setStroke(1,0xFF1F3140);v.setBackground(g);}private GradientDrawableCompat(){}}
