package com.oddswatch.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.*;
import java.util.concurrent.*;

public class ScannerService extends Service {
    public static final String CH="oddswatch_scanner", ACTION_UPDATED="com.oddswatch.mobile.UPDATED";
    private final ExecutorService exec=Executors.newSingleThreadExecutor(); private volatile boolean alive=true;

    @Override public void onCreate(){super.onCreate();createChannel();startForeground(41,baseNotification("Scanner starting…"));}
    @Override public int onStartCommand(Intent intent,int flags,int startId){ if(!Prefs.running(this)){stopSelf();return START_NOT_STICKY;} exec.submit(this::loop); return START_STICKY; }
    private void loop(){
        while(alive&&Prefs.running(this)){
            try{
                List<MarketAlert> alerts=OddsAnalyzer.scan(this); AppState.set(alerts);
                String line=alerts.isEmpty()?"No anomalies above threshold":alerts.get(0).oneLine();
                ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(41,baseNotification(line));
                sendBroadcast(new Intent(ACTION_UPDATED).setPackage(getPackageName()));
                maybeAlert(alerts);
            }catch(Exception e){AppState.error=e.getMessage();sendBroadcast(new Intent(ACTION_UPDATED).setPackage(getPackageName()));}
            try{Thread.sleep(Math.max(30,Prefs.interval(this))*1000L);}catch(InterruptedException e){break;}
        }
        stopSelf();
    }
    private void maybeAlert(List<MarketAlert> alerts){
        if(alerts.isEmpty())return; MarketAlert a=alerts.get(0); long now=System.currentTimeMillis();
        String k="sent_"+Integer.toHexString(a.id.hashCode()); long last=Prefs.p(this).getLong(k,0);
        if(now-last<30*60*1000L)return;
        notifyLocal(a);
        Prefs.p(this).edit().putLong(k,now).apply();
        if(Prefs.whatsapp(this)) exec.submit(()->{try{WhatsAppSender.send(this,"⚡ OddsWatch anomaly\n"+a.oneLine()+"\n"+a.detail);}catch(Exception ignored){}});
    }
    private Notification baseNotification(String text){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,CH).setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat).setContentTitle("OddsWatch scanner ON").setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setContentIntent(pi).setOngoing(true).build();}
    private void notifyLocal(MarketAlert a){String c="oddswatch_alerts"; if(Build.VERSION.SDK_INT>=26){NotificationChannel nc=new NotificationChannel(c,"Market anomaly alerts",NotificationManager.IMPORTANCE_HIGH);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(nc);} Notification n=new Notification.Builder(this,c).setSmallIcon(com.oddswatch.mobile.R.drawable.ic_stat).setContentTitle("Market anomaly • "+a.score+"/100").setContentText(a.oneLine()).setStyle(new Notification.BigTextStyle().bigText(a.oneLine()+"\n"+a.detail)).setAutoCancel(true).build();((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),n);}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CH,"OddsWatch background scanner",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    @Override public void onDestroy(){alive=false;exec.shutdownNow();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
