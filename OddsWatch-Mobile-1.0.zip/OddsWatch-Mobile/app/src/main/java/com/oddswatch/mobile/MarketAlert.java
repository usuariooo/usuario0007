package com.oddswatch.mobile;

public class MarketAlert {
    public String id, sport, event, market, selection, hardRockPrice, detail;
    public double evPct;
    public int score, peers;
    public boolean live;

    public String oneLine(){
        return (live?"LIVE":"PRE") + " • " + sport + " • " + event + " • " + selection + " " + hardRockPrice +
                " • anomaly " + score + "/100 • model edge " + String.format(java.util.Locale.US,"%.1f%%",evPct);
    }
}
