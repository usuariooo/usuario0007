package com.oddswatch.mobile;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String P = "oddswatch_prefs";
    public static SharedPreferences p(Context c){ return c.getSharedPreferences(P, Context.MODE_PRIVATE); }
    public static boolean running(Context c){ return p(c).getBoolean("running", false); }
    public static boolean demo(Context c){ return p(c).getBoolean("demo", true); }
    public static String apiKey(Context c){ return p(c).getString("api_key", ""); }
    public static int interval(Context c){ return p(c).getInt("interval_sec", 120); }
    public static int threshold(Context c){ return p(c).getInt("threshold", 70); }
    public static boolean whatsapp(Context c){ return p(c).getBoolean("whatsapp", false); }
    public static String waTo(Context c){ return p(c).getString("wa_to", "+17868513784"); }
    public static String twSid(Context c){ return p(c).getString("tw_sid", ""); }
    public static String twToken(Context c){ return p(c).getString("tw_token", ""); }
    public static String twFrom(Context c){ return p(c).getString("tw_from", "+14155238886"); }
    private Prefs(){}
}
