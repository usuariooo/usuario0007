package com.oddswatch.mobile;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;

public final class OddsAnalyzer {
    private static final String[] SPORTS = {
            "baseball_mlb","basketball_nba","basketball_wnba","americanfootball_nfl",
            "americanfootball_ncaaf","icehockey_nhl","soccer_epl","soccer_usa_mls"
    };
    private static final String BOOKS = "hardrockbet_fl,draftkings,fanduel,betmgm,williamhill_us,fanatics";

    public static List<MarketAlert> scan(Context c) throws Exception {
        if (Prefs.demo(c) || Prefs.apiKey(c).trim().isEmpty()) return demo();
        List<MarketAlert> out = new ArrayList<>();
        for (String sport: SPORTS) {
            try { out.addAll(fetchSport(c, sport)); } catch(Exception ignored) {}
        }
        out.sort((a,b)->Integer.compare(b.score,a.score));
        if(out.size()>40) return new ArrayList<>(out.subList(0,40));
        return out;
    }

    private static List<MarketAlert> fetchSport(Context c, String sport) throws Exception {
        String u = "https://api.the-odds-api.com/v4/sports/"+sport+"/odds?apiKey="+
                URLEncoder.encode(Prefs.apiKey(c),"UTF-8")+
                "&bookmakers="+BOOKS+"&markets=h2h,spreads,totals&oddsFormat=american&dateFormat=iso";
        JSONArray games = new JSONArray(get(u));
        List<MarketAlert> out = new ArrayList<>();
        long now=System.currentTimeMillis();
        for(int gi=0;gi<games.length();gi++){
            JSONObject g=games.getJSONObject(gi);
            long start=parseTime(g.optString("commence_time"));
            boolean live=start>0 && start<=now && now-start<8*60*60*1000L;
            String event=g.optString("away_team")+" @ "+g.optString("home_team");
            JSONArray books=g.optJSONArray("bookmakers"); if(books==null) continue;
            JSONObject hard=null; List<JSONObject> peers=new ArrayList<>();
            for(int bi=0;bi<books.length();bi++){
                JSONObject b=books.getJSONObject(bi);
                if("hardrockbet_fl".equals(b.optString("key"))) hard=b; else peers.add(b);
            }
            if(hard==null || peers.size()<2) continue;
            JSONArray hm=hard.optJSONArray("markets"); if(hm==null) continue;
            for(int mi=0;mi<hm.length();mi++){
                JSONObject market=hm.getJSONObject(mi); String mk=market.optString("key");
                JSONArray outcomes=market.optJSONArray("outcomes"); if(outcomes==null) continue;
                Map<String,Double> hardNoVig = noVig(outcomes);
                for(int oi=0;oi<outcomes.length();oi++){
                    JSONObject ho=outcomes.getJSONObject(oi);
                    String name=ho.optString("name"); double point=ho.has("point")?ho.optDouble("point",Double.NaN):Double.NaN;
                    int price=ho.optInt("price",0); if(price==0) continue;
                    List<Double> fairPs=new ArrayList<>(); List<Double> peerPoints=new ArrayList<>();
                    for(JSONObject pb:peers){
                        JSONObject pm=findMarket(pb,mk); if(pm==null) continue;
                        JSONArray po=pm.optJSONArray("outcomes"); if(po==null) continue;
                        JSONObject match=findOutcome(po,name,point);
                        if(match==null) continue;
                        Map<String,Double> nv=noVig(po); String key=outcomeKey(match);
                        if(nv.containsKey(key)) fairPs.add(nv.get(key));
                        if(match.has("point")) peerPoints.add(match.optDouble("point"));
                    }
                    if(fairPs.size()<2) continue;
                    double fair=median(fairPs), dec=americanToDecimal(price), ev=(fair*dec-1.0)*100.0;
                    double lineDiff=0;
                    if(!Double.isNaN(point)&&!peerPoints.isEmpty()) lineDiff=Math.abs(point-median(peerPoints));
                    int score=(int)Math.round(50 + Math.max(0,ev)*4 + Math.min(15,lineDiff*7) + Math.min(10,fairPs.size()*2));
                    score=Math.max(0,Math.min(99,score));
                    if(score<Prefs.threshold(c) || ev<1.5) continue;
                    MarketAlert a=new MarketAlert();
                    a.id=g.optString("id")+"|"+mk+"|"+name+"|"+point;
                    a.sport=g.optString("sport_title",sport); a.event=event; a.market=mk; a.selection=name+(Double.isNaN(point)?"":" "+fmtPoint(point));
                    a.hardRockPrice=formatAmerican(price); a.evPct=ev; a.score=score; a.peers=fairPs.size(); a.live=live;
                    a.detail="Consensus from "+fairPs.size()+" other books; fair probability ~"+String.format(Locale.US,"%.1f%%",fair*100)+
                            (lineDiff>0?"; line gap "+String.format(Locale.US,"%.1f",lineDiff):"")+". This is an anomaly signal, not a guaranteed outcome.";
                    out.add(a);
                }
            }
        }
        return out;
    }

    private static JSONObject findMarket(JSONObject book,String key){ JSONArray a=book.optJSONArray("markets"); if(a==null)return null; for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&key.equals(x.optString("key")))return x;} return null; }
    private static JSONObject findOutcome(JSONArray a,String name,double point){ for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null||!name.equals(x.optString("name")))continue; if(Double.isNaN(point)&&!x.has("point"))return x; if(!Double.isNaN(point)&&x.has("point")&&Math.abs(x.optDouble("point")-point)<0.001)return x;} return null; }
    private static String outcomeKey(JSONObject o){ return o.optString("name")+"|"+(o.has("point")?o.optDouble("point"):"-"); }
    private static Map<String,Double> noVig(JSONArray a){ Map<String,Double> raw=new HashMap<>(); double sum=0; for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;int p=o.optInt("price",0);if(p==0)continue;double q=implied(p);raw.put(outcomeKey(o),q);sum+=q;} if(sum>0){for(String k:new ArrayList<>(raw.keySet()))raw.put(k,raw.get(k)/sum);} return raw; }
    private static double implied(int a){ return a<0?(-a)/(double)((-a)+100):100.0/(a+100.0); }
    private static double americanToDecimal(int a){ return a>0?1+a/100.0:1+100.0/(-a); }
    private static String formatAmerican(int a){return a>0?"+"+a:String.valueOf(a);} private static String fmtPoint(double p){return (p>0?"+":"")+(Math.rint(p)==p?String.format(Locale.US,"%.0f",p):String.format(Locale.US,"%.1f",p));}
    private static double median(List<Double> x){Collections.sort(x);int n=x.size();return n%2==1?x.get(n/2):(x.get(n/2-1)+x.get(n/2))/2;}
    private static long parseTime(String s){try{return Instant.parse(s).toEpochMilli();}catch(Exception e){return 0;}}
    private static String get(String url) throws Exception { HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection(); h.setConnectTimeout(10000);h.setReadTimeout(15000);h.setRequestProperty("User-Agent","OddsWatch-Mobile/1.0"); int code=h.getResponseCode();InputStream in=(code>=200&&code<300)?h.getInputStream():h.getErrorStream();String text=read(in);if(code<200||code>=300)throw new IOException("HTTP "+code+": "+text);return text; }
    private static String read(InputStream in)throws Exception{if(in==null)return"";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] z=new byte[4096];int n;while((n=in.read(z))>0)b.write(z,0,n);return b.toString(StandardCharsets.UTF_8.name());}

    private static List<MarketAlert> demo(){
        String[][] d={{"MLB","New York @ Tampa Bay","Moneyline","Tampa Bay","+128","8.6","91","LIVE"},{"WNBA","Las Vegas @ Phoenix","Spread","Phoenix +5.5","-105","6.1","84","LIVE"},{"NFL","Buffalo @ Baltimore","Total","Under 47.5","-108","4.7","77","PRE"},{"MLS","Miami @ Orlando","Moneyline","Miami","+142","3.9","73","PRE"}};
        List<MarketAlert> r=new ArrayList<>();int i=0;for(String[] x:d){MarketAlert a=new MarketAlert();a.id="demo"+(i++);a.sport=x[0];a.event=x[1];a.market=x[2];a.selection=x[3];a.hardRockPrice=x[4];a.evPct=Double.parseDouble(x[5]);a.score=Integer.parseInt(x[6]);a.live="LIVE".equals(x[7]);a.peers=5;a.detail="Demo data. Shows how a real market anomaly will appear after you add an odds API key.";r.add(a);}return r;
    }
    private OddsAnalyzer(){}
}
