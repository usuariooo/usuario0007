package com.oddswatch.mobile;
import java.util.*;
public final class AppState { public static volatile List<MarketAlert> alerts=new ArrayList<>(); public static volatile String error=""; public static synchronized void set(List<MarketAlert>a){alerts=new ArrayList<>(a);error="";} private AppState(){} }
