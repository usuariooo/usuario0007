# OddsWatch Mobile 1.0

Native Android prototype for monitoring Hard Rock Bet Florida odds **without logging into or controlling a betting account**.

## What works
- Demo mode immediately, no keys required.
- Real odds mode with The Odds API.
- Hard Rock Bet Florida key: `hardrockbet_fl`.
- Compares Hard Rock FL against DraftKings, FanDuel, BetMGM, Caesars and Fanatics when returned by the feed.
- Moneyline, spread and total market anomaly detection.
- No-vig consensus probability, estimated price edge, line-gap contribution and anomaly score.
- Foreground scanner with Android notifications.
- LIVE/PRE classification based on event start time.
- Configurable scan interval and anomaly threshold.
- Optional WhatsApp alerts through Twilio.
- Recipient is prefilled in E.164 format; it can be edited in the app.

## Real data setup
Create an API key at The Odds API and paste it in the app. Turn Demo mode OFF. The free plan is limited; scanning many sports every few minutes can consume the quota quickly.

## WhatsApp setup
Automatic WhatsApp messages cannot be sent silently from a personal WhatsApp account. This app uses the official Twilio/WhatsApp API path instead. In the Twilio Sandbox, join the sandbox from your WhatsApp first, then enter:
- Account SID
- Auth Token
- WhatsApp sender (sandbox is commonly +14155238886)
- recipient in E.164 format

Twilio can require a pre-approved template when outside the customer-service messaging window. The included test button makes it easy to verify the connection.

### Security note
This test build stores API/Twilio credentials in app preferences on the phone. For a production release, move Twilio credentials to a backend/relay so the Auth Token is never shipped or stored client-side.

## Build an APK
Open this folder in Android Studio (JDK 17+), let Gradle sync, then Build > Build APK(s). The debug APK will be under `app/build/outputs/apk/debug/`.

The included GitHub Actions workflow can also build a debug APK after pushing the project to GitHub.

## Background behavior
The scanner runs as an Android foreground data-sync service, which keeps a visible notification. Recent Android versions can still impose OS-level background/foreground-service limits; no phone-only design can guarantee uninterrupted 24/7 execution. A small server is the robust option for true continuous monitoring.

## Scope
This application detects market discrepancies. It does not log into Hard Rock, place wagers, choose stakes, or click betslips.
