package com.oddswatch.mobile;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQ=901;
    // Tema visual: azul noche + petróleo + turquesa. Evita el negro puro y mantiene
    // contraste alto para leer rápido las señales durante sesiones largas.
    private final int BG=Color.rgb(9,25,43),CARD=Color.rgb(18,43,66),CARD2=Color.rgb(28,58,84),ACC=Color.rgb(67,221,190),GOLD=Color.rgb(255,198,96),RED=Color.rgb(255,111,132),TEXT=Color.rgb(246,249,253),MUTED=Color.rgb(166,188,208),BLUE=Color.rgb(133,157,255),BORDER=Color.rgb(45,78,104);
    private Store store;private LinearLayout root,content;private TextView status,sectionLabel;private String tab="home";private BroadcastReceiver receiver;private Handler ui=new Handler(Looper.getMainLooper());private boolean pendingNight=false;

    @Override public void onCreate(Bundle b){super.onCreate(b);store=new Store(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);build();String t=getIntent().getStringExtra("tab");if(t!=null)tab=t;render();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},22);receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){refresh();if(!"settings".equals(tab))render();}};IntentFilter f=new IntentFilter(CaptureService.ACTION_UPDATE);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);ui.post(clock);}
    @Override public void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){}ui.removeCallbacksAndMessages(null);super.onDestroy();}
    private final Runnable clock=new Runnable(){public void run(){refresh();if("detected".equals(tab)||"stats".equals(tab)||"home".equals(tab))render();ui.postDelayed(this,1500);}};

    private void build(){
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(8),dp(14),dp(8));
        GradientDrawable screenBg=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.rgb(10,30,50),BG,Color.rgb(7,21,37)});
        root.setBackground(screenBg);
        setContentView(root);

        // Barra superior limpia: menú ☰ a la izquierda y el dashboard principal intacto debajo.
        LinearLayout top=new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(4),dp(4),dp(4),dp(6));

        TextView menu=txt("☰",30,true,TEXT);
        menu.setGravity(Gravity.CENTER);
        menu.setBackground(round(CARD2,14));
        menu.setClickable(true);
        menu.setFocusable(true);
        menu.setOnClickListener(v->showSideMenu(menu));
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(50),dp(50));
        mp.setMargins(0,0,dp(12),0);
        top.addView(menu,mp);

        LinearLayout brand=new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.addView(txt("ODDSWATCH",25,true,TEXT));
        sectionLabel=txt("INICIO • NOCHE VIRTUAL",12,true,ACC);
        brand.addView(sectionLabel);
        top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));

        TextView dot=txt("●",18,true,ACC);
        dot.setGravity(Gravity.CENTER);
        top.addView(dot,new LinearLayout.LayoutParams(dp(34),dp(42)));
        root.addView(top);

        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(10),dp(8),dp(10),dp(8));
        info.setBackground(roundStroke(Color.rgb(14,37,59),16,BORDER));
        info.addView(txt("OCR local • Hard Rock visible • simulación $0 real",12,false,MUTED));
        status=txt("",14,true,ACC);
        status.setPadding(0,dp(5),0,0);
        info.addView(status);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);
        ip.setMargins(0,0,0,dp(8));
        root.addView(info,ip);

        ScrollView scroller=new ScrollView(this);
        scroller.setFillViewport(true);
        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroller.addView(content);
        root.addView(scroller,new LinearLayout.LayoutParams(-1,0,1));
        refresh();
    }

    private void showSideMenu(View anchor){
        final PopupWindow popup=new PopupWindow(this);
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14),dp(14),dp(14),dp(14));
        box.setBackground(roundStroke(Color.rgb(17,43,67),20,BORDER));

        box.addView(txt("ODDSWATCH",20,true,TEXT));
        TextView sub=txt("Navegación",11,true,MUTED);sub.setPadding(0,0,0,dp(10));box.addView(sub);

        menuItem(box,popup,"⌂  Inicio","home");
        menuItem(box,popup,"⌁  Señales detectadas","detected");
        menuItem(box,popup,"◷  Historial","history");
        menuItem(box,popup,"▥  Estadísticas","stats");
        menuItem(box,popup,"⚙  Ajustes","settings");

        View sep=new View(this);sep.setBackgroundColor(BORDER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(1));sp.setMargins(0,dp(8),0,dp(10));box.addView(sep,sp);
        TextView hint=txt(store.scannerOn()?"● Radar activo":"○ Radar apagado",12,true,store.scannerOn()?ACC:MUTED);box.addView(hint);

        popup.setContentView(box);
        popup.setWidth(dp(285));
        popup.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        popup.setFocusable(true);
        popup.setOutsideTouchable(true);
        popup.setBackgroundDrawable(round(Color.TRANSPARENT,1));
        popup.setElevation(dp(12));
        popup.showAsDropDown(anchor,0,dp(8));
    }

    private void menuItem(LinearLayout box,PopupWindow popup,String label,String key){
        TextView item=txt(label,16,true,key.equals(tab)?ACC:TEXT);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(12),dp(12),dp(12),dp(12));
        item.setBackground(round(key.equals(tab)?Color.rgb(24,64,82):Color.TRANSPARENT,13));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.setMargins(0,dp(2),0,dp(2));box.addView(item,p);
        item.setOnClickListener(v->{tab=key;popup.dismiss();updateSectionLabel();render();});
    }

    private void updateSectionLabel(){
        if(sectionLabel==null)return;
        String s="INICIO • NOCHE VIRTUAL";
        if("detected".equals(tab))s="SEÑALES DETECTADAS";
        else if("history".equals(tab))s="HISTORIAL";
        else if("stats".equals(tab))s="ESTADÍSTICAS";
        else if("settings".equals(tab))s="AJUSTES";
        sectionLabel.setText(s);
    }

    private void render(){updateSectionLabel();content.removeAllViews();switch(tab){case"detected":detected();break;case"history":history();break;case"stats":stats();break;case"settings":settings();break;default:home();}}

    private void home(){
        title("Prueba virtual de esta noche");LinearLayout n=card();
        n.addView(txt("🧪 $30 VIRTUALES • $3 POR SEÑAL",21,true,GOLD));
        n.addView(txt("No coloca apuestas reales. Cada señal queda registrada antes del resultado y usa un stake virtual fijo. El capital disponible limita cuántas jugadas pueden estar abiertas a la vez.",13,false,TEXT));
        n.addView(paperSummary(true));
        // INICIAR / DETENER: un solo control principal. REINICIAR es aparte y solo a demanda.
        if(store.paperActive()||store.scannerOn()){
            Button stop=button("DETENER",true);stop.setOnClickListener(v->stopRadarAndSimulation());n.addView(stop);
            Button reset=button("REINICIAR SESIÓN",false);reset.setOnClickListener(v->confirmResetSession());n.addView(reset);
        }else{
            Button start=button("INICIAR NOCHE VIRTUAL",true);start.setOnClickListener(v->startNight());n.addView(start);
            if(store.paperSessionId()!=null&&!store.paperSessionId().isEmpty()){
                Button reset=button("REINICIAR SESIÓN",false);reset.setOnClickListener(v->confirmResetSession());n.addView(reset);
            }
        }
        Signal lockedNow=store.trackingSignal();
        if(lockedNow!=null){Button release=button("LIBERAR SEÑAL BLOQUEADA",false);release.setOnClickListener(v->{store.releaseTrackingSignal("🔓 Señal liberada manualmente: queda PENDIENTE y el radar busca la siguiente.");Toast.makeText(this,"Señal liberada; sigue PENDIENTE",Toast.LENGTH_SHORT).show();render();});n.addView(release);}
        content.addView(n);

        title("Estado real");LinearLayout c=card();c.addView(kv("Captura",store.captureReady()?"ACTIVA":"INACTIVA"));c.addView(kv("Navegador automático",store.readerReady()?"ACTIVO":"INACTIVO"));c.addView(kv("Pantalla",prettyPackage(store.foregroundPackage())));c.addView(kv("OCR",store.lastOcr()==0?"Sin lectura":fmt(store.lastOcr())));c.addView(kv("Líneas visibles",String.valueOf(store.linesSeen())));c.addView(kv("Mercados completos",String.valueOf(store.marketsSeen())));c.addView(kv("Deporte",store.currentSport()));c.addView(kv("Última señal",store.lastSignalAt()==0?"Todavía ninguna":fmt(store.lastSignalAt())));if(!store.lastError().isEmpty())c.addView(txt("DIAGNÓSTICO: "+store.lastError(),13,true,RED));content.addView(c);

        LinearLayout d=card();d.addView(txt("QUÉ REGISTRA",12,true,MUTED));d.addView(txt("PARTIDO: Novak M. vs Kral P.",15,true,TEXT));d.addView(txt("MERCADO: Ganador del partido",15,true,TEXT));d.addView(txt("SELECCIÓN: Novak M.",18,true,GOLD));d.addView(txt("CUOTA: 1.83",18,true,ACC));d.addView(txt("STAKE VIRTUAL: $3.00",16,true,BLUE));d.addView(txt("La app ahora reconoce tanto cuotas americanas (-120/+135) como decimales (1.45/2.60).",12,false,MUTED));content.addView(d);
    }

    private View paperSummary(boolean compact){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(0,dp(10),0,dp(8));double bank=store.paperBankroll(),avail=store.paperAvailable(),pl=store.paperSettledProfit(),turn=store.paperTurnover();int w=store.paperWins(),l=store.paperLosses(),p=store.paperPushes(),pen=store.paperPending(),resolved=w+l;double wr=resolved==0?0:w*100.0/resolved,roi=turn<=0?0:pl/turn*100.0;box.addView(txt((store.paperActive()?"● SESIÓN ACTIVA":"○ SESIÓN DETENIDA")+" • inicio "+Models.money(store.paperInitial()),13,true,store.paperActive()?ACC:MUTED));LinearLayout r=new LinearLayout(this);r.addView(small(Models.money(bank),"BANKROLL",bank>=store.paperInitial()?ACC:RED),new LinearLayout.LayoutParams(0,-2,1));r.addView(small(Models.money(avail),"DISPONIBLE",BLUE),new LinearLayout.LayoutParams(0,-2,1));r.addView(small(String.format(Locale.US,"%+.2f",pl),"P/L $",pl>=0?ACC:RED),new LinearLayout.LayoutParams(0,-2,1));box.addView(r);LinearLayout r2=new LinearLayout(this);r2.addView(small(resolved+"","RESUELTAS",TEXT),new LinearLayout.LayoutParams(0,-2,1));r2.addView(small(pen+"","PENDIENTES",GOLD),new LinearLayout.LayoutParams(0,-2,1));r2.addView(small(String.format(Locale.US,"%.1f%%",wr),"ACIERTO",wr>=55?ACC:GOLD),new LinearLayout.LayoutParams(0,-2,1));box.addView(r2);Signal locked=store.trackingSignal();if(locked!=null){box.addView(txt("🔒 1 A LA VEZ • siguiendo hasta finalizar: "+locked.event+" • "+locked.market+" → "+locked.selection+" @ "+locked.odds,13,true,GOLD));}if(!compact){box.addView(txt(String.format(Locale.US,"ROI sobre stake resuelto: %+.1f%% • Push: %d • Omitidas por falta de bankroll: %d",roi,p,store.paperSkipped()),13,false,MUTED));box.addView(txt("Señales que no cuentan para bankroll: "+store.signalsNotCountingForBankroll(),13,true,GOLD));if(!store.paperActive())box.addView(txt("⚠️ NO HAY SESIÓN VIRTUAL ACTIVA: las nuevas señales del radar no afectarán el bankroll hasta iniciar Noche Virtual.",13,true,RED));box.addView(txt("Meta visual: $100. Esto NO significa que la app pueda garantizar llegar a esa cifra.",12,false,MUTED));}return box;}

    private void detected(){title("Señales virtuales");long now=System.currentTimeMillis();List<Signal>a=store.loadSignals();int n=0;for(Signal s:a)if("PENDIENTE".equals(s.status)&&now-s.updatedAt<3600000){signalCard(s,true);n++;}if(n==0){LinearLayout c=card();c.addView(txt("Aún no hay una señal completa.",17,true,TEXT));c.addView(txt("El radar necesita ver la misma selección cambiar de precio. La primera lectura crea el baseline; una lectura posterior que cruza el umbral genera la señal virtual.",13,false,MUTED));content.addView(c);}title("Mercados que OCR está leyendo ahora");int m=0;for(Signal s:store.loadObserved())if(now-s.updatedAt<120000){marketCard(s);if(++m>=40)break;}if(m==0)content.addView(txt("0 mercados completos. Comprueba que Hard Rock esté visible y que el OCR muestre líneas en INICIO.",15,true,RED));}
    private void marketCard(Signal s){LinearLayout c=card();c.addView(txt(s.sport,11,true,ACC));c.addView(txt(s.event,16,true,TEXT));c.addView(txt(s.market,13,false,MUTED));c.addView(txt("SELECCIÓN: "+s.selection+"   •   CUOTA "+s.odds,16,true,GOLD));c.addView(txt(String.format(Locale.US,"Probabilidad implícita: %.1f%%",s.implied*100),12,false,MUTED));content.addView(c);}
    private void signalCard(Signal s,boolean current){LinearLayout c=card();c.addView(txt((s.paper?"🧪 VIRTUAL • ":"🎯 ")+(s.live?"🔴 LIVE • ":"🗓️ PRE • ")+s.sport+" • "+Math.round(s.score)+"/99",13,true,ACC));c.addView(txt("PARTIDO",11,true,MUTED));c.addView(txt(s.event,19,true,TEXT));c.addView(txt("MERCADO",11,true,MUTED));c.addView(txt(s.market,16,true,TEXT));c.addView(txt("SELECCIÓN",11,true,MUTED));c.addView(txt(s.selection,21,true,GOLD));c.addView(txt("CUOTA  "+s.odds,21,true,ACC));if(s.paper)c.addView(txt("STAKE VIRTUAL "+Models.money(s.stake)+" • beneficio potencial "+Models.money(s.potentialProfit),14,true,BLUE));c.addView(txt(String.format(Locale.US,"Prob. implícita %.1f%% • movimiento +%.1f pp",s.implied*100,s.movement*100),13,false,TEXT));
        if(s.observations>0)c.addView(txt("BASE DE LA SEÑAL: "+s.observations+" lecturas consecutivas • "+(s.previousOdds.isEmpty()?"cuota previa registrada":s.previousOdds+" → "+s.odds),12,true,BLUE));if(!s.screenState.isEmpty())c.addView(txt("CONTEXTO VISIBLE: "+s.screenState+" (informativo; la señal actual se calcula por movimiento de cuota)",12,false,MUTED));
        c.addView(txt(s.reason,12,false,MUTED));if(s.screenshot!=null&&!s.screenshot.isEmpty()&&new File(s.screenshot).exists()){ImageView im=new ImageView(this);im.setAdjustViewBounds(true);im.setScaleType(ImageView.ScaleType.FIT_CENTER);im.setImageBitmap(BitmapFactory.decodeFile(s.screenshot));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(300));p.setMargins(0,dp(8),0,dp(8));c.addView(im,p);}if(!current){c.addView(txt("RESULTADO: "+s.status+("PENDIENTE".equals(s.status)?"":" • "+(s.resultSource.isEmpty()?"RESULTADO":s.resultSource)+" • P/L "+Models.money(s.simulatedProfit)),14,true,statusColor(s.status)));if("PENDIENTE".equals(s.status)){LinearLayout r=new LinearLayout(this);for(String x:new String[]{"GANADA","PERDIDA","PUSH"}){Button q=button(x,false);q.setOnClickListener(v->{store.setResult(s.id,x);render();});r.addView(q,new LinearLayout.LayoutParams(0,dp(44),1));}c.addView(r);}}content.addView(c);}
    private void history(){title("Historial de señales");List<Signal>a=store.loadSignals();if(a.isEmpty()){content.addView(txt("Sin señales todavía.",15,false,MUTED));return;}for(Signal s:a)signalCard(s,false);}
    private void stats(){title("Prueba virtual actual");LinearLayout c=card();c.addView(paperSummary(false));content.addView(c);title("Cómo leerla");LinearLayout e=card();e.addView(txt("• ACERTO usa solo GANADAS + PERDIDAS.",13,false,TEXT));e.addView(txt("• ROI = ganancia/pérdida neta ÷ stake total de apuestas ya resueltas.",13,false,TEXT));e.addView(txt("• Las pendientes todavía no cuentan como ganadas ni perdidas.",13,false,TEXT));e.addView(txt("• La resolución automática ahora sale de la rotación normal, vuelve al deporte de cada señal LIVE pendiente y busca el partido por nombre.",13,false,MUTED));
        e.addView(txt("Resolver AUTO: "+store.resultStatus(),13,true,ACC));content.addView(e);}

    private void settings(){title("Simulación");LinearLayout n=card();n.addView(txt("Capital virtual inicial",12,true,MUTED));EditText initial=input(String.format(Locale.US,"%.2f",store.paperInitial()));n.addView(initial);n.addView(txt("Stake virtual por señal",12,true,MUTED));EditText stake=input(String.format(Locale.US,"%.2f",store.paperStake()));n.addView(stake);Button savePaper=button("GUARDAR CAPITAL / STAKE",false);savePaper.setOnClickListener(v->{try{double a=Double.parseDouble(initial.getText().toString().replace(",",".")),b=Double.parseDouble(stake.getText().toString().replace(",","."));store.setPaperDefaults(a,b);Toast.makeText(this,"Guardado",Toast.LENGTH_SHORT).show();render();}catch(Exception ex){Toast.makeText(this,"Valores inválidos",Toast.LENGTH_SHORT).show();}});n.addView(savePaper);content.addView(n);
        title("Permisos");LinearLayout p=card();p.addView(kv("Accesibilidad",accessibilityEnabled()?"ACTIVA":"FALTA"));Button ac=button("ABRIR ACCESIBILIDAD",false);ac.setOnClickListener(v->openAccessibility());p.addView(ac);content.addView(p);
        title("Sensibilidad");LinearLayout s=card();s.addView(txt("Movimiento mínimo de probabilidad implícita para registrar una señal. En modo prueba usamos 0.25 pp y 2 lecturas estables para reaccionar antes.",13,false,MUTED));EditText e=input(String.format(Locale.US,"%.2f",store.movementThreshold()*100));s.addView(e);Button sv=button("GUARDAR UMBRAL",false);sv.setOnClickListener(v->{try{double x=Double.parseDouble(e.getText().toString().replace(",","."));store.setMovementThreshold(x/100.0);Toast.makeText(this,"Guardado",Toast.LENGTH_SHORT).show();}catch(Exception ex){Toast.makeText(this,"Número inválido",Toast.LENGTH_SHORT).show();}});s.addView(sv);content.addView(s);
        title("Alertas remotas opcionales");LinearLayout r=card();r.addView(txt("Puedes usar ntfy gratis en otro teléfono. No necesita key. Solo envía el texto de la señal virtual.",13,false,TEXT));Switch sw=new Switch(this);sw.setText("Enviar señales remotas");sw.setTextColor(TEXT);sw.setChecked(store.remoteEnabled());sw.setOnCheckedChangeListener((x,v)->store.setRemoteEnabled(v));r.addView(sw);r.addView(txt(store.topic(),15,true,ACC));Button cp=button("COPIAR TEMA",false);cp.setOnClickListener(v->copy(store.topic()));r.addView(cp);content.addView(r);
        Button clear=button("BORRAR HISTORIAL Y REINICIAR",false);clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Borrar historial").setMessage("Borra todas las señales y la sesión virtual actual.").setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(d,w)->{store.clearHistory();render();}).show());content.addView(clear);}

    private void confirmResetSession(){
        new AlertDialog.Builder(this)
            .setTitle("Reiniciar sesión virtual")
            .setMessage("Pone el bankroll otra vez en $30 y empieza una sesión nueva. Las señales de la sesión actual dejan de contar en el resumen. El historial no se borra.")
            .setNegativeButton("Cancelar",null)
            .setPositiveButton("Reiniciar",(d,w)->{
                boolean wasRunning=store.scannerOn()||store.paperActive();
                if(wasRunning){
                    stopService(new Intent(this,CaptureService.class));
                    store.setScannerOn(false);
                    store.setCaptureReady(false);
                }
                store.startPaperSession();
                if(wasRunning){
                    // Re-pedir captura para continuar la noche con sesión limpia.
                    pendingNight=true;
                    requestCapture();
                }else{
                    Toast.makeText(this,"Sesión reiniciada. Pulsa INICIAR cuando quieras arrancar.",Toast.LENGTH_LONG).show();
                    render();
                }
            }).show();
    }
    private void startNight(){if(!accessibilityEnabled()){Toast.makeText(this,"Activa primero OddsWatch en Accesibilidad.",Toast.LENGTH_LONG).show();openAccessibility();return;}pendingNight=true;requestCapture();}
    private void requestCapture(){if(!accessibilityEnabled()){Toast.makeText(this,"Activa primero OddsWatch en Accesibilidad.",Toast.LENGTH_LONG).show();openAccessibility();return;}store.setMode(Store.MODE_DEDICATED);MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),CAPTURE_REQ);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req!=CAPTURE_REQ)return;if(result!=RESULT_OK||data==null){pendingNight=false;Toast.makeText(this,"No se autorizó la captura",Toast.LENGTH_SHORT).show();return;}if(pendingNight){store.startPaperSession();pendingNight=false;}Intent i=new Intent(this,CaptureService.class);i.putExtra("resultCode",result);i.putExtra("resultData",data);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);store.setScannerOn(true);HardRockAccessibilityService.launchHardRock(this);Toast.makeText(this,"Noche virtual iniciada: $0 real, stake virtual "+Models.money(store.paperStake()),Toast.LENGTH_LONG).show();render();}
    private void stopRadarAndSimulation(){stopService(new Intent(this,CaptureService.class));store.stopPaperSession();store.setScannerOn(false);store.setCaptureReady(false);render();}
    private boolean accessibilityEnabled(){try{String x=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);return x!=null&&x.toLowerCase(Locale.US).contains("hardrockaccessibilityservice");}catch(Exception e){return false;}}
    private void openAccessibility(){startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}
    private void copy(String s){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("OddsWatch",s));Toast.makeText(this,"Copiado",Toast.LENGTH_SHORT).show();}
    private void refresh(){if(status==null)return;String x;if(!store.scannerOn())x="○ RADAR APAGADO";else x="● RADAR ACTIVO • 1 SEÑAL A LA VEZ • "+store.marketsSeen()+" mercados";status.setText(x);status.setTextColor(store.scannerOn()?ACC:MUTED);}

    private String prettyPackage(String p){if(p==null||p.isEmpty())return"—";if(p.equals("com.hardrockdigital.client"))return"Hard Rock Bet";if(p.startsWith(getPackageName()))return"OddsWatch";return"Otra app (OCR pausado)";}
    private String fmt(long t){return new SimpleDateFormat("h:mm:ss a",Locale.getDefault()).format(new Date(t));}
    private int statusColor(String s){if("GANADA".equals(s))return ACC;if("PERDIDA".equals(s))return RED;if("PUSH".equals(s))return GOLD;return MUTED;}
    private void title(String s){TextView t=txt(s,21,true,TEXT);t.setPadding(0,dp(14),0,dp(8));content.addView(t);}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(16),dp(14),dp(16),dp(14));c.setBackground(roundStroke(CARD,18,BORDER));c.setElevation(dp(2));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(10));c.setLayoutParams(p);return c;}
    private TextView txt(String s,int sp,boolean bold,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(0,1.07f);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private TextView kv(String a,String b){TextView t=txt(a+":  "+b,14,false,TEXT);t.setPadding(0,dp(3),0,dp(3));return t;}
    private Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(primary?Color.rgb(8,35,38):TEXT);b.setTextSize(12);b.setTypeface(null,Typeface.BOLD);b.setBackground(primary?round(ACC,14):roundStroke(CARD2,14,BORDER));return b;}
    private EditText input(String s){EditText e=new EditText(this);e.setText(s);e.setSingleLine(true);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(roundStroke(CARD2,12,BORDER));return e;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable roundStroke(int color,int radius,int strokeColor){GradientDrawable d=round(color,radius);d.setStroke(dp(1),strokeColor);return d;}
    private int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
    private View small(String v,String l,int c){LinearLayout x=new LinearLayout(this);x.setGravity(Gravity.CENTER);x.setOrientation(LinearLayout.VERTICAL);x.addView(txt(v,20,true,c));x.addView(txt(l,9,false,MUTED));return x;}
}
